<?php
// 数据库配置（安装后自动生成，如手动修改请保留此格式）
return [
    'host' => 'localhost',
    'port' => 3306,
    'dbname' => 'music_cms',
    'username' => 'root',
    'password' => '',
    'charset' => 'utf8mb4',
];
