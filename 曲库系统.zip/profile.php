<?php
require_once __DIR__ . '/includes/auth.php';
requireLogin();
$pageTitle = '个人中心 - 甜音曲库';

$pdo = Database::getConnection();
$user = currentUser();

$stmt = $pdo->prepare("SELECT m.*, a.name AS artist_name FROM music m
                       LEFT JOIN artists a ON m.artist_id = a.id
                       WHERE m.uploader_id = ? ORDER BY m.created_at DESC");
$stmt->execute([$_SESSION['user_id']]);
$myMusic = $stmt->fetchAll();

$musicCount = count($myMusic);
$totalSize = array_sum(array_column($myMusic, 'file_size'));
$totalPlays = array_sum(array_column($myMusic, 'play_count'));

include __DIR__ . '/includes/header.php';
?>

<div class="pb-24 max-w-2xl mx-auto">
    <!-- 用户头部 -->
    <div class="bg-gradient-to-br from-pink-400 via-rose-400 to-fuchsia-500 rounded-3xl p-6 text-white mb-5">
        <div class="flex items-center gap-4">
            <img src="<?php echo $user['avatar'] ? e($user['avatar']) : 'assets/images/default-avatar.svg'; ?>"
                 class="w-20 h-20 rounded-full border-4 border-white/40 shadow-xl">
            <div class="flex-1">
                <h2 class="text-2xl font-bold"><?php echo e(userDisplayName($user)); ?></h2>
                <p class="text-white/80 text-sm">账号：<?php echo e($user['username']); ?> · <?php echo e($user['email']); ?></p>
                <span class="inline-block mt-1 px-3 py-0.5 rounded-full text-xs bg-white/25">
                    <i class="<?php echo isAdmin() ? 'ri ri-vip-crown-line' : 'ri ri-user-line'; ?> mr-1"></i>
                    <?php echo isAdmin() ? '管理员' : '普通用户'; ?>
                </span>
            </div>
        </div>
        <!-- 统计 -->
        <div class="grid grid-cols-3 gap-3 mt-6">
            <div class="bg-white/20 rounded-2xl py-3 text-center">
                <div class="text-2xl font-bold"><?php echo $musicCount; ?></div>
                <div class="text-xs text-white/80">上传歌曲</div>
            </div>
            <div class="bg-white/20 rounded-2xl py-3 text-center">
                <div class="text-2xl font-bold"><?php echo formatSize($totalSize); ?></div>
                <div class="text-xs text-white/80">占用空间</div>
            </div>
            <div class="bg-white/20 rounded-2xl py-3 text-center">
                <div class="text-2xl font-bold"><?php echo $totalPlays; ?></div>
                <div class="text-xs text-white/80">总播放量</div>
            </div>
        </div>
    </div>

    <!-- 功能折叠下拉菜单 -->
    <div class="bg-white/60 backdrop-blur rounded-2xl overflow-hidden mb-5">
        <button onclick="document.getElementById('funcMenu').classList.toggle('hidden'); document.getElementById('menuArrow').classList.toggle('rotate-180')"
                class="w-full flex items-center justify-between px-4 py-3.5 hover:bg-pink-50/50 transition">
            <span class="flex items-center gap-2 font-medium text-gray-800">
                <i class="ri ri-menu-line text-pink-500"></i>功能菜单
            </span>
            <i id="menuArrow" class="ri ri-arrow-down-s-line text-gray-400 transition-transform"></i>
        </button>
        <div id="funcMenu" class="hidden border-t border-pink-100">
            <a href="upload.php" class="flex items-center gap-3 px-4 py-3 hover:bg-pink-50/50 transition">
                <div class="w-8 h-8 rounded-full bg-pink-100 flex items-center justify-center text-pink-500">
                    <i class="ri ri-upload-cloud-2-line"></i>
                </div>
                <span class="text-gray-700">上传音乐</span>
                <i class="ri ri-arrow-right-s-line text-gray-300 ml-auto"></i>
            </a>
            <a href="profile_edit.php" class="flex items-center gap-3 px-4 py-3 hover:bg-pink-50/50 transition">
                <div class="w-8 h-8 rounded-full bg-rose-100 flex items-center justify-center text-rose-500">
                    <i class="ri ri-edit-line"></i>
                </div>
                <span class="text-gray-700">资料编辑</span>
                <i class="ri ri-arrow-right-s-line text-gray-300 ml-auto"></i>
            </a>
            <a href="admin/index.php" class="flex items-center gap-3 px-4 py-3 hover:bg-pink-50/50 transition">
                <div class="w-8 h-8 rounded-full bg-purple-100 flex items-center justify-center text-purple-500">
                    <i class="ri ri-settings-line"></i>
                </div>
                <span class="text-gray-700"><?php echo isSuperAdmin() ? '管理后台' : '我的后台'; ?></span>
                <i class="ri ri-arrow-right-s-line text-gray-300 ml-auto"></i>
            </a>
            <a href="logout.php" class="flex items-center gap-3 px-4 py-3 hover:bg-red-50/50 transition">
                <div class="w-8 h-8 rounded-full bg-gray-100 flex items-center justify-center text-gray-500">
                    <i class="ri ri-logout-box-r-line"></i>
                </div>
                <span class="text-gray-700">退出登录</span>
                <i class="ri ri-arrow-right-s-line text-gray-300 ml-auto"></i>
            </a>
        </div>
    </div>

    <!-- 我上传的音乐 -->
    <div class="flex items-center justify-between mb-3 px-1">
        <h2 class="font-bold text-gray-800">我上传的音乐</h2>
        <span class="text-xs text-gray-400"><?php echo $musicCount; ?> 首</span>
    </div>

    <?php if (empty($myMusic)): ?>
        <div class="text-center py-16 text-gray-400">
            <i class="ri ri-upload-cloud-2-line text-5xl mb-3 text-pink-200"></i>
            <p>还没有上传音乐</p>
            <a href="upload.php" class="text-pink-500 text-sm mt-2 inline-block hover:underline">立即上传</a>
        </div>
    <?php else: ?>
        <div class="space-y-1">
            <?php foreach ($myMusic as $m): ?>
                <div class="flex items-center gap-3 p-2.5 rounded-xl hover:bg-pink-50/60 transition group">
                    <img src="<?php echo $m['cover'] ? e($m['cover']) : 'assets/images/default-cover.svg'; ?>"
                         class="w-11 h-11 rounded-lg object-cover flex-shrink-0">
                    <?php
                    $playArgs = htmlspecialchars(json_encode([
                        $m['id'],
                        $m['title'],
                        $m['artist_name'] ?: '未知歌手',
                        $m['file_path'],
                        $m['cover'] ?: 'assets/images/default-cover.svg'
                    ], JSON_UNESCAPED_UNICODE), ENT_QUOTES);
                    ?>
                    <div class="flex-1 min-w-0 cursor-pointer" onclick="playMusic(<?php echo $playArgs; ?>)">
                        <div class="font-medium text-gray-800 truncate"><?php echo e($m['title']); ?></div>
                        <div class="text-xs text-gray-400 truncate">
                            <?php echo e($m['artist_name'] ?: '未知歌手'); ?> · <?php echo formatSize($m['file_size']); ?> · <?php echo e($m['file_type']); ?>
                        </div>
                    </div>
                    <a href="admin/edit_music.php?id=<?php echo $m['id']; ?>&redirect=../profile.php"
                       class="w-8 h-8 flex items-center justify-center text-gray-300 hover:text-blue-500 transition"
                       title="到后台修改">
                        <i class="ri ri-edit-line text-sm"></i>
                    </a>
                    <a href="delete_music.php?id=<?php echo $m['id']; ?>&redirect=profile.php"
                       class="w-8 h-8 flex items-center justify-center text-gray-300 hover:text-red-500 transition">
                        <i class="ri ri-delete-bin-line text-sm"></i>
                    </a>
                </div>
            <?php endforeach; ?>
        </div>
    <?php endif; ?>
</div>

<!-- 底部导航栏 -->
<nav class="fixed bottom-0 left-0 right-0 z-50 bg-white/90 backdrop-blur-lg border-t border-pink-100 md:hidden">
    <div class="grid grid-cols-5 py-2">
        <a href="index.php" class="flex flex-col items-center gap-0.5 text-gray-400">
            <i class="ri ri-home-line text-lg"></i><span class="text-[10px]">首页</span>
        </a>
        <a href="#" class="flex flex-col items-center gap-0.5 text-gray-400">
            <i class="ri ri-video-line text-lg"></i><span class="text-[10px]">视频</span>
        </a>
        <a href="player.php" class="flex flex-col items-center gap-0.5">
            <div class="w-12 h-12 rounded-full bg-gradient-to-br from-pink-500 to-rose-500 flex items-center justify-center text-white -mt-4 shadow-lg">
                <i class="ri ri-play-line ml-0.5"></i>
            </div>
        </a>
        <a href="#" class="flex flex-col items-center gap-0.5 text-gray-400">
            <i class="ri ri-star-line text-lg"></i><span class="text-[10px]">星光</span>
        </a>
        <a href="profile.php" class="flex flex-col items-center gap-0.5 text-pink-500">
            <i class="ri ri-user-line text-lg"></i><span class="text-[10px]">我的</span>
        </a>
    </div>
</nav>

<?php include __DIR__ . '/includes/footer.php'; ?>
