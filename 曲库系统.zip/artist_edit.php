<?php
require_once __DIR__ . '/includes/auth.php';
requireLogin();
$pageTitle = '新建歌手 - 甜音曲库';

$pdo = Database::getConnection();
$error = '';
$success = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $name = trim($_POST['name'] ?? '');
    $bio = trim($_POST['bio'] ?? '');
    $avatar = null;

    if (empty($name)) {
        $error = '歌手名不能为空';
    } else {
        $username = $user['username'];
        // 处理头像上传 - 存入用户专属文件夹（同名覆盖）
        if (!empty($_FILES['avatar']['name']) && $_FILES['avatar']['error'] === UPLOAD_ERR_OK) {
            $allowed = ['jpg', 'jpeg', 'png', 'gif', 'webp'];
            $ext = strtolower(pathinfo($_FILES['avatar']['name'], PATHINFO_EXTENSION));
            if (in_array($ext, $allowed)) {
                $avatarRelDir = userSubDir($username, 'avatars');
                $avatarDir = __DIR__ . '/' . $avatarRelDir;
                $avatar = saveUploadedFile($_FILES['avatar'], $avatarDir, $avatarRelDir);
            } else {
                $error = '头像仅支持 JPG/PNG/GIF/WebP 格式';
            }
        }

        if (!$error) {
            $stmt = $pdo->prepare("INSERT INTO artists (name, avatar, bio, created_by) VALUES (?, ?, ?, ?)");
            $stmt->execute([$name, $avatar, $bio, $_SESSION['user_id']]);
            $newId = $pdo->lastInsertId();
            $success = '歌手创建成功！';
            redirect('artists.php?id=' . $newId);
        }
    }
}

include __DIR__ . '/includes/header.php';
?>
<div class="max-w-2xl mx-auto pb-24">
    <div class="flex items-center gap-3 mb-5">
        <a href="artists.php" class="w-9 h-9 rounded-full bg-white/70 flex items-center justify-center text-gray-500">
            <i class="ri ri-arrow-left-s-line text-sm"></i>
        </a>
        <h1 class="text-xl font-bold text-gray-800">新建歌手</h1>
    </div>

    <div class="bg-white/60 backdrop-blur rounded-3xl p-6">
        <?php if ($error): ?>
            <div class="bg-red-50 text-red-600 px-4 py-3 rounded-xl mb-4 text-sm">
                <i class="ri ri-information-line mr-2"></i><?php echo e($error); ?>
            </div>
        <?php endif; ?>

        <form method="post" enctype="multipart/form-data" class="space-y-4">
            <div>
                <label class="block text-sm font-medium text-gray-700 mb-1">歌手名 <span class="text-red-400">*</span></label>
                <input type="text" name="name" required class="input-field" placeholder="请输入歌手名">
            </div>
            <div>
                <label class="block text-sm font-medium text-gray-700 mb-1">歌手头像</label>
                <div class="flex items-center gap-4">
                    <div id="avatarPreview" class="w-20 h-20 rounded-full bg-pink-50 flex items-center justify-center overflow-hidden">
                        <i class="ri ri-camera-line text-pink-300 text-2xl"></i>
                    </div>
                    <input type="file" name="avatar" accept="image/*" id="avatarInput" class="text-sm">
                </div>
            </div>
            <div>
                <label class="block text-sm font-medium text-gray-700 mb-1">歌手简介</label>
                <textarea name="bio" rows="4" class="input-field" placeholder="简单介绍一下这位歌手..."></textarea>
            </div>
            <button type="submit" class="btn-primary w-full py-3 rounded-xl font-semibold">
                <i class="ri ri-save-line mr-2"></i>创建歌手
            </button>
        </form>
    </div>
</div>

<!-- 底部导航栏 -->
<nav class="fixed bottom-0 left-0 right-0 z-50 bg-white/90 backdrop-blur-lg border-t border-pink-100 md:hidden">
    <div class="grid grid-cols-5 py-2">
        <a href="index.php" class="flex flex-col items-center gap-0.5 text-gray-400">
            <i class="ri ri-home-line text-lg"></i><span class="text-[10px]">首页</span>
        </a>
        <a href="#" class="flex flex-col items-center gap-0.5 text-gray-400">
            <i class="ri ri-video-line text-lg"></i><span class="text-[10px]">视频</span>
        </a>
        <a href="player.php" class="flex flex-col items-center gap-0.5">
            <div class="w-12 h-12 rounded-full bg-gradient-to-br from-pink-500 to-rose-500 flex items-center justify-center text-white -mt-4 shadow-lg">
                <i class="ri ri-play-line ml-0.5"></i>
            </div>
        </a>
        <a href="#" class="flex flex-col items-center gap-0.5 text-gray-400">
            <i class="ri ri-star-line text-lg"></i><span class="text-[10px]">星光</span>
        </a>
        <a href="profile.php" class="flex flex-col items-center gap-0.5 text-gray-400">
            <i class="ri ri-user-line text-lg"></i><span class="text-[10px]">我的</span>
        </a>
    </div>
</nav>

<script>
document.getElementById('avatarInput').addEventListener('change', function(e) {
    const file = e.target.files[0];
    if (file) {
        const reader = new FileReader();
        reader.onload = function(ev) {
            document.getElementById('avatarPreview').innerHTML = '<img src="' + ev.target.result + '" class="w-full h-full object-cover">';
        };
        reader.readAsDataURL(file);
    }
});
</script>
<?php include __DIR__ . '/includes/footer.php'; ?>
