<?php
require_once __DIR__ . '/includes/auth.php';

if (isLoggedIn()) redirect('index.php');

$error = '';
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $username = trim($_POST['username'] ?? '');
    $nickname = trim($_POST['nickname'] ?? '');
    $email = trim($_POST['email'] ?? '');
    $password = $_POST['password'] ?? '';
    $confirm = $_POST['confirm'] ?? '';

    if (strlen($username) < 3) {
        $error = '用户名至少3个字符';
    } elseif (!preg_match('/^[\w\x{4e00}-\x{9fa5}]+$/u', $username)) {
        $error = '用户名只能包含字母、数字、下划线和中文';
    } elseif ($nickname !== '' && mb_strlen($nickname) > 20) {
        $error = '昵称不能超过20个字符';
    } elseif (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
        $error = '邮箱格式不正确';
    } elseif (strlen($password) < 6) {
        $error = '密码至少6位';
    } elseif ($password !== $confirm) {
        $error = '两次密码不一致';
    } else {
        $pdo = Database::getConnection();
        // 检查重复
        $stmt = $pdo->prepare("SELECT id FROM users WHERE username = ? OR email = ?");
        $stmt->execute([$username, $email]);
        if ($stmt->fetch()) {
            $error = '用户名或邮箱已被注册';
        } else {
            $hash = password_hash($password, PASSWORD_DEFAULT);
            $stmt = $pdo->prepare("INSERT INTO users (username, nickname, email, password, role) VALUES (?, ?, ?, ?, 'user')");
            $stmt->execute([$username, $nickname ?: null, $email, $hash]);
            $userId = $pdo->lastInsertId();
            // 注册即创建歌手记录（用户即歌手），歌手名使用昵称，无昵称则用用户名
            $artistName = $nickname ?: $username;
            $stmt = $pdo->prepare("INSERT INTO artists (name, bio, created_by) VALUES (?, ?, ?)");
            $stmt->execute([$artistName, '这个人很懒，什么都没留下~', $userId]);
            // 创建用户专属文件夹
            createUserDir($username);
            $_SESSION['user_id'] = $userId;
            redirect('index.php');
        }
    }
}
?>
<!DOCTYPE html>
<html lang="zh-CN">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>注册 - 甜音曲库</title>
    <script src="https://cdn.tailwindcss.com"></script>
    <link rel="stylesheet" href="https://cdn.bootcdn.net/ajax/libs/remixicon/4.2.0/remixicon.css">
    <link rel="stylesheet" href="assets/css/style.css">
</head>
<body class="auth-bg min-h-screen flex items-center justify-center p-3 sm:p-4">
    <div class="glass-card w-full max-w-md p-5 sm:p-8">
        <div class="text-center mb-8">
            <div class="inline-flex items-center justify-center w-16 h-16 rounded-full bg-gradient-to-br from-pink-400 to-rose-500 mb-4 shadow-lg">
                <i class="ri ri-user-add-line text-white text-2xl"></i>
            </div>
            <h1 class="text-xl sm:text-2xl font-bold text-gray-800">加入甜音</h1>
            <p class="text-gray-500 text-xs sm:text-sm mt-1">创建账号，上传你的音乐</p>
        </div>

        <?php if ($error): ?>
            <div class="bg-red-50 border border-red-200 text-red-600 px-4 py-3 rounded-xl mb-4 text-sm">
                <i class="ri ri-information-line mr-2"></i><?php echo e($error); ?>
            </div>
        <?php endif; ?>

        <form method="post" class="space-y-3 sm:space-y-4">
            <div>
                <label class="block text-xs sm:text-sm font-medium text-gray-700 mb-1">用户名 <span class="text-xs text-gray-400 font-normal">（仅用于登录）</span></label>
                <div class="relative">
                    <i class="ri ri-user-line absolute left-4 top-1/2 -translate-y-1/2 text-pink-400"></i>
                    <input type="text" name="username" required minlength="3" class="input-field pl-11" placeholder="字母、数字、下划线或中文">
                </div>
            </div>
            <div>
                <label class="block text-xs sm:text-sm font-medium text-gray-700 mb-1">昵称 <span class="text-xs text-gray-400 font-normal">（用于显示及歌手名，可选）</span></label>
                <div class="relative">
                    <i class="ri ri-emotion-happy-line absolute left-4 top-1/2 -translate-y-1/2 text-pink-400"></i>
                    <input type="text" name="nickname" maxlength="20" class="input-field pl-11" placeholder="留空则使用用户名">
                </div>
            </div>
            <div>
                <label class="block text-xs sm:text-sm font-medium text-gray-700 mb-1">邮箱</label>
                <div class="relative">
                    <i class="ri ri-mail-line absolute left-4 top-1/2 -translate-y-1/2 text-pink-400"></i>
                    <input type="email" name="email" required class="input-field pl-11" placeholder="your@email.com">
                </div>
            </div>
            <div>
                <label class="block text-xs sm:text-sm font-medium text-gray-700 mb-1">密码</label>
                <div class="relative">
                    <i class="ri ri-lock-line absolute left-4 top-1/2 -translate-y-1/2 text-pink-400"></i>
                    <input type="password" name="password" required minlength="6" class="input-field pl-11" placeholder="至少6位">
                </div>
            </div>
            <div>
                <label class="block text-xs sm:text-sm font-medium text-gray-700 mb-1">确认密码</label>
                <div class="relative">
                    <i class="ri ri-lock-line absolute left-4 top-1/2 -translate-y-1/2 text-pink-400"></i>
                    <input type="password" name="confirm" required class="input-field pl-11" placeholder="再次输入密码">
                </div>
            </div>
            <button type="submit" class="btn-primary w-full py-2.5 sm:py-3 rounded-xl font-semibold text-sm sm:text-base">
                <i class="ri ri-checkbox-circle-line mr-1 sm:mr-2"></i>注册
            </button>
        </form>

        <p class="text-center text-gray-500 text-xs sm:text-sm mt-5 sm:mt-6">
            已有账号？<a href="login.php" class="text-pink-500 font-medium hover:underline">去登录</a>
        </p>
        <p class="text-center text-gray-400 text-xs mt-2 sm:mt-3">
            <a href="index.php" class="hover:text-pink-500"><i class="ri ri-arrow-left-line mr-1"></i>返回首页</a>
        </p>
    </div>
</body>
</html>
