<?php
/**
 * 根据用户名/邮箱获取头像
 */
require_once __DIR__ . '/includes/db.php';

header('Content-Type: application/json');

$username = trim($_GET['username'] ?? '');
if (empty($username)) {
    echo json_encode(['found' => false]);
    exit;
}

$pdo = Database::getConnection();
$stmt = $pdo->prepare("SELECT avatar, username FROM users WHERE username = ? OR email = ? LIMIT 1");
$stmt->execute([$username, $username]);
$user = $stmt->fetch();

if ($user) {
    echo json_encode([
        'found' => true,
        'avatar' => $user['avatar'] ?: null,
        'username' => $user['username']
    ]);
} else {
    echo json_encode(['found' => false]);
}
