-- 音乐曲库系统数据库结构
-- MySQL 5.7+ / 8.0+

SET NAMES utf8mb4;
SET FOREIGN_KEY_CHECKS = 0;

-- ----------------------------
-- 用户表
-- ----------------------------
DROP TABLE IF EXISTS `users`;
CREATE TABLE `users` (
  `id` int unsigned NOT NULL AUTO_INCREMENT,
  `username` varchar(50) NOT NULL COMMENT '用户名（仅用于登录）',
  `nickname` varchar(50) DEFAULT NULL COMMENT '昵称（用于显示及歌手名）',
  `email` varchar(100) NOT NULL COMMENT '邮箱',
  `password` varchar(255) NOT NULL COMMENT '密码哈希',
  `avatar` varchar(255) DEFAULT NULL COMMENT '头像',
  `role` enum('user','admin') NOT NULL DEFAULT 'user' COMMENT '角色',
  `created_at` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY `uk_username` (`username`),
  UNIQUE KEY `uk_email` (`email`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci COMMENT='用户表';

-- ----------------------------
-- 歌手表
-- ----------------------------
DROP TABLE IF EXISTS `artists`;
CREATE TABLE `artists` (
  `id` int unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(100) NOT NULL COMMENT '歌手名',
  `avatar` varchar(255) DEFAULT NULL COMMENT '歌手头像',
  `bio` text COMMENT '简介',
  `created_by` int unsigned DEFAULT NULL COMMENT '创建者用户ID',
  `created_at` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  KEY `idx_name` (`name`),
  KEY `fk_artist_creator` (`created_by`),
  CONSTRAINT `fk_artist_creator` FOREIGN KEY (`created_by`) REFERENCES `users` (`id`) ON DELETE SET NULL ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci COMMENT='歌手表';

-- ----------------------------
-- 音乐表
-- ----------------------------
DROP TABLE IF EXISTS `music`;
CREATE TABLE `music` (
  `id` int unsigned NOT NULL AUTO_INCREMENT,
  `title` varchar(200) NOT NULL COMMENT '歌曲名',
  `artist_id` int unsigned DEFAULT NULL COMMENT '歌手ID',
  `album` varchar(150) DEFAULT NULL COMMENT '专辑名',
  `cover` varchar(255) DEFAULT NULL COMMENT '歌曲封面图路径',
  `album_cover` varchar(255) DEFAULT NULL COMMENT '专辑封面图路径',
  `file_path` varchar(255) NOT NULL COMMENT '音乐文件路径',
  `file_type` varchar(20) DEFAULT NULL COMMENT '文件类型/格式',
  `duration` int unsigned DEFAULT '0' COMMENT '时长(秒)',
  `file_size` bigint unsigned DEFAULT '0' COMMENT '文件大小(字节)',
  `uploader_id` int unsigned DEFAULT NULL COMMENT '上传者ID',
  `play_count` int unsigned DEFAULT '0' COMMENT '播放次数',
  `created_at` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  KEY `idx_title` (`title`),
  KEY `idx_artist` (`artist_id`),
  KEY `idx_uploader` (`uploader_id`),
  CONSTRAINT `fk_music_artist` FOREIGN KEY (`artist_id`) REFERENCES `artists` (`id`) ON DELETE SET NULL ON UPDATE CASCADE,
  CONSTRAINT `fk_music_uploader` FOREIGN KEY (`uploader_id`) REFERENCES `users` (`id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci COMMENT='音乐表';

-- ----------------------------
-- 播放列表/收藏表
-- ----------------------------
DROP TABLE IF EXISTS `playlists`;
CREATE TABLE `playlists` (
  `id` int unsigned NOT NULL AUTO_INCREMENT,
  `user_id` int unsigned NOT NULL COMMENT '用户ID',
  `music_id` int unsigned NOT NULL COMMENT '音乐ID',
  `created_at` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY `uk_user_music` (`user_id`,`music_id`),
  KEY `idx_user` (`user_id`),
  KEY `idx_music` (`music_id`),
  CONSTRAINT `fk_pl_user` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `fk_pl_music` FOREIGN KEY (`music_id`) REFERENCES `music` (`id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci COMMENT='收藏/播放列表';

SET FOREIGN_KEY_CHECKS = 1;
