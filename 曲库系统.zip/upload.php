<?php
require_once __DIR__ . '/includes/auth.php';
requireLogin();
$user = currentUser();
$pageTitle = '上传音乐 - 甜音曲库';

$pdo = Database::getConnection();
$error = '';
$success = '';

// 检查上传目录是否可写
$uploadRoot = __DIR__ . '/uploads';
if (!is_dir($uploadRoot)) {
    @mkdir($uploadRoot, 0777, true);
}
$dirWritable = is_writable($uploadRoot);
$phpMaxUpload = ini_get('upload_max_filesize');
$phpMaxPost = ini_get('post_max_size');

// 数据库迁移：确保字段存在（兼容旧版安装）
try {
    $coverCheck = $pdo->query("SHOW COLUMNS FROM music LIKE 'cover'");
    $coverRow = $coverCheck->fetch();
    if ($coverRow && strpos($coverRow['Type'], 'varchar') !== false) {
        $pdo->exec("ALTER TABLE music MODIFY COLUMN cover varchar(255) DEFAULT NULL");
    }
    $acCheck = $pdo->query("SHOW COLUMNS FROM artists LIKE 'created_by'");
    if (!$acCheck->fetch()) {
        $pdo->exec("ALTER TABLE artists ADD COLUMN created_by int unsigned DEFAULT NULL COMMENT '创建者用户ID'");
    }
} catch (Exception $e) {
    // 迁移失败不阻塞，继续执行
}

// 获取当前用户的歌手记录（用户即歌手）
$stmt = $pdo->prepare("SELECT id FROM artists WHERE created_by = ? LIMIT 1");
$stmt->execute([$_SESSION['user_id']]);
$myArtist = $stmt->fetch();
if (!$myArtist) {
    // 兼容老用户：自动创建歌手记录（歌手名用昵称，无昵称则用用户名）
    $stmt = $pdo->prepare("INSERT INTO artists (name, bio, created_by) VALUES (?, ?, ?)");
    $stmt->execute([userDisplayName($user), '这个人很懒，什么都没留下~', $_SESSION['user_id']]);
    $artistId = $pdo->lastInsertId();
} else {
    $artistId = $myArtist['id'];
}

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $title = trim($_POST['title'] ?? '');
    $cover = null;
    $musicFile = null;

    // 调试：检查文件上传状态
    $uploadErr = $_FILES['music_file']['error'] ?? UPLOAD_ERR_NO_FILE;
    $phpMaxUpload = ini_get('upload_max_filesize');
    $phpMaxPost = ini_get('post_max_size');

    if (empty($title)) {
        $error = '歌曲名不能为空';
    } elseif ($uploadErr !== UPLOAD_ERR_OK) {
        $errMap = [
            UPLOAD_ERR_INI_SIZE => '文件超过 PHP 限制（upload_max_filesize=' . $phpMaxUpload . '）',
            UPLOAD_ERR_FORM_SIZE => '文件超过表单限制',
            UPLOAD_ERR_PARTIAL => '文件上传不完整',
            UPLOAD_ERR_NO_FILE => '请选择音乐文件',
            UPLOAD_ERR_NO_TMP_DIR => '服务器缺少临时目录',
            UPLOAD_ERR_CANT_WRITE => '服务器写入失败',
        ];
        $error = $errMap[$uploadErr] ?? '上传失败（错误码：' . $uploadErr . '）';
    } elseif ($_FILES['music_file']['size'] > 20 * 1024 * 1024) {
        $error = '音乐文件不能超过 20MB（当前 PHP 限制 upload_max_filesize=' . $phpMaxUpload . '，post_max_size=' . $phpMaxPost . '）';
    } else {
        // 允许的音乐格式
        $allowedMusic = ['mp3', 'wav', 'flac', 'aac', 'ogg', 'm4a', 'wma', 'ape', 'opus', 'mid'];
        $musicExt = strtolower(pathinfo($_FILES['music_file']['name'], PATHINFO_EXTENSION));

        if (!in_array($musicExt, $allowedMusic)) {
            $error = '不支持的音乐格式：' . $musicExt . '。支持：' . implode(', ', $allowedMusic);
        } else {
            $username = $user['username'];
            $coverRelDir = userSubDir($username, 'covers');
            $musicRelDir = userSubDir($username, 'music');
            $coverDir = __DIR__ . '/' . $coverRelDir;
            $musicDir = __DIR__ . '/' . $musicRelDir;

            // 处理歌曲封面（同名覆盖）
            if (!empty($_FILES['cover']['name']) && $_FILES['cover']['error'] === UPLOAD_ERR_OK) {
                if ($_FILES['cover']['size'] > 5 * 1024 * 1024) {
                    $error = '封面图片不能超过 5MB';
                } else {
                    $allowedImg = ['jpg', 'jpeg', 'png', 'gif', 'webp'];
                    $imgExt = strtolower(pathinfo($_FILES['cover']['name'], PATHINFO_EXTENSION));
                    if (in_array($imgExt, $allowedImg)) {
                        $cover = saveUploadedFile($_FILES['cover'], $coverDir, $coverRelDir);
                        if (!$cover) $error = '封面保存失败，目录：' . $coverDir;
                    } else {
                        $error = '封面仅支持 JPG/PNG/GIF/WebP';
                    }
                }
            }

            if (!$error) {
                // 保存音乐文件（同名覆盖）
                $musicFile = saveUploadedFile($_FILES['music_file'], $musicDir, $musicRelDir);
                if ($musicFile) {
                    $fileSize = $_FILES['music_file']['size'];
                    $duration = 0;

                    $stmt = $pdo->prepare("INSERT INTO music (title, artist_id, cover, file_path, file_type, duration, file_size, uploader_id)
                                           VALUES (?, ?, ?, ?, ?, ?, ?, ?)");
                    $stmt->execute([
                        $title, $artistId, $cover ?: '', $musicFile,
                        strtoupper($musicExt), $duration, $fileSize, $_SESSION['user_id']
                    ]);
                    $success = '音乐上传成功！';
                    redirect('index.php');
                } else {
                    $error = '音乐文件保存失败！目录：' . $musicDir . '（请检查目录权限）';
                }
            }
        }
    }
}

include __DIR__ . '/includes/header.php';
?>
<div class="max-w-2xl mx-auto pb-24">
    <div class="flex items-center gap-3 mb-5">
        <a href="index.php" class="w-9 h-9 rounded-full bg-white/70 flex items-center justify-center text-gray-500">
            <i class="ri ri-arrow-left-s-line text-sm"></i>
        </a>
        <h1 class="text-xl font-bold text-gray-800">上传音乐</h1>
    </div>

    <div class="bg-white/60 backdrop-blur rounded-3xl p-6">
        <?php if ($error): ?>
            <div class="bg-red-50 text-red-600 px-4 py-3 rounded-xl mb-4 text-sm">
                <i class="ri ri-information-line mr-2"></i><?php echo e($error); ?>
            </div>
        <?php endif; ?>

        <?php if (!$dirWritable): ?>
            <div class="bg-amber-50 text-amber-700 px-4 py-3 rounded-xl mb-4 text-sm">
                <i class="ri ri-error-warning-line mr-2"></i>上传目录不可写：<?php echo e($uploadRoot); ?>，请检查目录权限
            </div>
        <?php endif; ?>

        <div class="text-xs text-gray-400 mb-4">
            <i class="ri ri-information-line mr-1"></i>
            PHP限制：upload_max_filesize=<?php echo $phpMaxUpload; ?>，post_max_size=<?php echo $phpMaxPost; ?>
            <?php if (!$dirWritable): ?> · <span class="text-red-400">目录不可写</span><?php endif; ?>
        </div>

        <form method="post" enctype="multipart/form-data" class="space-y-4">
            <div>
                <label class="block text-sm font-medium text-gray-700 mb-1">歌曲名 <span class="text-red-400">*</span></label>
                <input type="text" name="title" required class="input-field" placeholder="请输入歌曲名">
            </div>

            <div>
                <label class="block text-sm font-medium text-gray-700 mb-1">歌手</label>
                <div class="input-field bg-pink-50/50 text-gray-500">
                    <i class="ri ri-mic-line text-pink-400 mr-2"></i><?php echo e(userDisplayName($user)); ?>（我）
                </div>
            </div>

            <!-- 歌曲封面 -->
            <div>
                <label class="block text-sm font-medium text-gray-700 mb-1">歌曲封面</label>
                <div class="flex items-center gap-4">
                    <div id="coverPreview" class="w-24 h-24 rounded-2xl bg-pink-50 border-2 border-dashed border-pink-200 flex items-center justify-center overflow-hidden cursor-pointer" onclick="document.getElementById('coverInput').click()">
                        <i class="ri ri-image-line text-pink-300 text-2xl"></i>
                    </div>
                    <div>
                        <input type="file" name="cover" accept="image/*" id="coverInput" class="hidden" onchange="previewCover(this, 'coverPreview')">
                        <button type="button" onclick="document.getElementById('coverInput').click()" class="text-sm text-pink-500 hover:underline">
                            <i class="ri ri-camera-line mr-1"></i>选择封面
                        </button>
                        <p class="text-xs text-gray-400 mt-1">建议方形，最大5MB</p>
                    </div>
                </div>
            </div>

            <div>
                <label class="block text-sm font-medium text-gray-700 mb-1">音乐文件 <span class="text-red-400">*</span></label>
                <div class="upload-area" id="dropArea">
                    <i class="ri ri-music-line text-4xl text-pink-300 mb-2"></i>
                    <p class="text-gray-500">点击或拖拽音乐文件到此处</p>
                    <p class="text-xs text-gray-400 mt-1">支持 MP3 / WAV / FLAC / AAC / OGG / M4A / WMA / APE / OPUS / MID · 最大 20MB</p>
                    <input type="file" name="music_file" id="musicInput" accept=".mp3,.wav,.flac,.aac,.ogg,.m4a,.wma,.ape,.opus,.mid,audio/*" class="hidden">
                </div>
                <div id="fileInfo" class="hidden mt-2 text-sm text-gray-600">
                    <i class="ri ri-music-2-line text-pink-500 mr-1"></i><span id="fileName"></span>
                    <span class="text-gray-400 ml-2" id="fileSize"></span>
                </div>
            </div>

            <button type="submit" class="btn-primary w-full py-3 rounded-xl font-semibold">
                <i class="ri ri-upload-cloud-2-line mr-2"></i>开始上传
            </button>
        </form>
    </div>
</div>

<!-- 底部导航栏 -->
<nav class="fixed bottom-0 left-0 right-0 z-50 bg-white/90 backdrop-blur-lg border-t border-pink-100 md:hidden">
    <div class="grid grid-cols-5 py-2">
        <a href="index.php" class="flex flex-col items-center gap-0.5 text-gray-400">
            <i class="ri ri-home-line text-lg"></i><span class="text-[10px]">首页</span>
        </a>
        <a href="#" class="flex flex-col items-center gap-0.5 text-gray-400">
            <i class="ri ri-video-line text-lg"></i><span class="text-[10px]">视频</span>
        </a>
        <a href="player.php" class="flex flex-col items-center gap-0.5">
            <div class="w-12 h-12 rounded-full bg-gradient-to-br from-pink-500 to-rose-500 flex items-center justify-center text-white -mt-4 shadow-lg">
                <i class="ri ri-play-line ml-0.5"></i>
            </div>
        </a>
        <a href="#" class="flex flex-col items-center gap-0.5 text-gray-400">
            <i class="ri ri-star-line text-lg"></i><span class="text-[10px]">星光</span>
        </a>
        <a href="profile.php" class="flex flex-col items-center gap-0.5 text-gray-400">
            <i class="ri ri-user-line text-lg"></i><span class="text-[10px]">我的</span>
        </a>
    </div>
</nav>

<script>
const musicInput = document.getElementById('musicInput');
const dropArea = document.getElementById('dropArea');
const fileInfo = document.getElementById('fileInfo');
const fileName = document.getElementById('fileName');
const fileSize = document.getElementById('fileSize');

dropArea.addEventListener('click', () => musicInput.click());
dropArea.addEventListener('dragover', e => { e.preventDefault(); dropArea.classList.add('dragover'); });
dropArea.addEventListener('dragleave', () => dropArea.classList.remove('dragover'));
dropArea.addEventListener('drop', e => {
    e.preventDefault();
    dropArea.classList.remove('dragover');
    if (e.dataTransfer.files.length) {
        const f = e.dataTransfer.files[0];
        if (f.size > 20 * 1024 * 1024) { alert('文件不能超过 20MB'); return; }
        musicInput.files = e.dataTransfer.files;
        showFile(f);
    }
});
musicInput.addEventListener('change', e => {
    if (e.target.files.length) {
        const f = e.target.files[0];
        if (f.size > 20 * 1024 * 1024) { alert('文件不能超过 20MB'); e.target.value = ''; return; }
        showFile(f);
    }
});

function showFile(file) {
    fileName.textContent = file.name;
    fileSize.textContent = (file.size / 1048576).toFixed(2) + ' MB';
    fileInfo.classList.remove('hidden');
}

function previewCover(input, previewId) {
    const file = input.files[0];
    if (file) {
        if (file.size > 5 * 1024 * 1024) { alert('图片不能超过 5MB'); input.value = ''; return; }
        const reader = new FileReader();
        reader.onload = ev => {
            document.getElementById(previewId).innerHTML = '<img src="' + ev.target.result + '" class="w-full h-full object-cover">';
        };
        reader.readAsDataURL(file);
    }
}
</script>
<?php include __DIR__ . '/includes/footer.php'; ?>
