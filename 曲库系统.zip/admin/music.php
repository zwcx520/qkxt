<?php
$adminTitle = '音乐管理';
require_once __DIR__ . '/header.php';

$isSuper = isSuperAdmin();
$uid = $adminUser['id'];

$keyword = trim($_GET['q'] ?? '');
$sql = "SELECT m.*, a.name AS artist_name, COALESCE(NULLIF(u.nickname,''), u.username) AS uploader_name
        FROM music m LEFT JOIN artists a ON m.artist_id = a.id
        LEFT JOIN users u ON m.uploader_id = u.id WHERE 1=1";
$params = [];
// 普通用户只能看自己的音乐
if (!$isSuper) {
    $sql .= " AND m.uploader_id = ?";
    $params[] = $uid;
}
if ($keyword) {
    $sql .= " AND (m.title LIKE ? OR a.name LIKE ?" . ($isSuper ? " OR u.username LIKE ? OR u.nickname LIKE ?" : "") . ")";
    $kw = "%{$keyword}%";
    if ($isSuper) {
        $params = array_merge($params, [$kw, $kw, $kw, $kw]);
    } else {
        $params = array_merge($params, [$kw, $kw]);
    }
}
$sql .= " ORDER BY m.created_at DESC LIMIT 200";
$stmt = $pdo->prepare($sql);
$stmt->execute($params);
$musicList = $stmt->fetchAll();
?>
<h1 class="text-2xl font-bold text-gray-800 mb-6">
    <i class="ri ri-music-line text-pink-500 mr-2"></i>音乐管理
    <?php if (!$isSuper): ?><span class="text-sm text-pink-400 font-normal ml-2">（仅我的音乐）</span><?php endif; ?>
</h1>

<form method="get" class="mb-6 max-w-md">
    <div class="relative">
        <i class="ri ri-search-line absolute left-4 top-1/2 -translate-y-1/2 text-pink-400"></i>
        <input type="text" name="q" value="<?php echo e($keyword); ?>" placeholder="搜索歌曲、歌手<?php echo $isSuper ? '、上传者' : ''; ?>..."
               class="w-full pl-11 pr-4 py-2.5 rounded-xl border-2 border-pink-200 bg-white focus:border-pink-400">
    </div>
</form>

<div class="bg-white/70 backdrop-blur rounded-2xl overflow-hidden">
    <div class="overflow-x-auto">
        <table class="w-full text-sm">
            <thead class="bg-gradient-to-r from-pink-50 to-rose-50 text-gray-600">
                <tr>
                    <th class="px-4 py-3 text-left">封面</th>
                    <th class="px-4 py-3 text-left">歌曲名</th>
                    <th class="px-4 py-3 text-left">歌手</th>
                    <?php if ($isSuper): ?><th class="px-4 py-3 text-left hidden md:table-cell">上传者</th><?php endif; ?>
                    <th class="px-4 py-3 text-left hidden sm:table-cell">大小</th>
                    <th class="px-4 py-3 text-left hidden sm:table-cell">播放</th>
                    <th class="px-4 py-3 text-center">操作</th>
                </tr>
            </thead>
            <tbody class="divide-y divide-pink-50">
                <?php if (empty($musicList)): ?>
                    <tr><td colspan="<?php echo $isSuper ? 7 : 6; ?>" class="text-center py-12 text-gray-400">暂无音乐</td></tr>
                <?php else: ?>
                    <?php foreach ($musicList as $m): ?>
                        <tr class="hover:bg-pink-50/50">
                            <td class="px-4 py-2">
                                <img src="<?php echo $m['cover'] ? '../' . e($m['cover']) : '../assets/images/default-cover.svg'; ?>"
                                     class="w-10 h-10 rounded-lg object-cover">
                            </td>
                            <td class="px-4 py-2">
                                <div class="font-medium text-gray-800"><?php echo e($m['title']); ?></div>
                                <div class="text-xs text-gray-400"><?php echo e($m['album'] ?: '-'); ?> · <?php echo e($m['file_type']); ?></div>
                            </td>
                            <td class="px-4 py-2 text-gray-600"><?php echo e($m['artist_name'] ?: '-'); ?></td>
                            <?php if ($isSuper): ?><td class="px-4 py-2 text-gray-600 hidden md:table-cell"><?php echo e($m['uploader_name'] ?: '已删除'); ?></td><?php endif; ?>
                            <td class="px-4 py-2 text-gray-500 hidden sm:table-cell"><?php echo formatSize($m['file_size']); ?></td>
                            <td class="px-4 py-2 text-gray-500 hidden sm:table-cell"><?php echo $m['play_count']; ?></td>
                            <td class="px-4 py-2 text-center">
                                <div class="flex items-center justify-center gap-1">
                                    <a href="edit_music.php?id=<?php echo $m['id']; ?>&redirect=music.php"
                                       class="text-blue-400 hover:text-blue-600 px-1.5" title="编辑">
                                        <i class="ri ri-edit-line"></i>
                                    </a>
                                    <a href="../delete_music.php?id=<?php echo $m['id']; ?>&redirect=admin/music.php"
                                       class="text-red-400 hover:text-red-600 px-1.5" title="删除（含文件）">
                                        <i class="ri ri-delete-bin-line"></i>
                                    </a>
                                </div>
                            </td>
                        </tr>
                    <?php endforeach; ?>
                <?php endif; ?>
            </tbody>
        </table>
    </div>
</div>

<?php require_once __DIR__ . '/footer.php'; ?>
