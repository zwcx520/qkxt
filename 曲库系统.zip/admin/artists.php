<?php
$adminTitle = '歌手管理';
require_once __DIR__ . '/header.php';

$isSuper = isSuperAdmin();
$uid = $adminUser['id'];

if ($isSuper) {
    $artists = $pdo->query("SELECT a.*, COALESCE(NULLIF(a.avatar,''), u.avatar) AS display_avatar,
                            COUNT(m.id) AS music_count FROM artists a
                            LEFT JOIN music m ON a.id = m.artist_id
                            LEFT JOIN users u ON a.created_by = u.id
                            GROUP BY a.id ORDER BY a.id DESC")->fetchAll();
} else {
    // 普通用户只能看自己创建的歌手
    $stmt = $pdo->prepare("SELECT a.*, COALESCE(NULLIF(a.avatar,''), u.avatar) AS display_avatar,
                           COUNT(m.id) AS music_count FROM artists a
                           LEFT JOIN music m ON a.id = m.artist_id
                           LEFT JOIN users u ON a.created_by = u.id
                           WHERE a.created_by = ?
                           GROUP BY a.id ORDER BY a.id DESC");
    $stmt->execute([$uid]);
    $artists = $stmt->fetchAll();
}
?>
<h1 class="text-2xl font-bold text-gray-800 mb-6">
    <i class="ri ri-mic-line text-pink-500 mr-2"></i>歌手管理
    <?php if (!$isSuper): ?><span class="text-sm text-pink-400 font-normal ml-2">（仅我创建的歌手）</span><?php endif; ?>
</h1>

<div class="bg-white/70 backdrop-blur rounded-2xl overflow-hidden">
    <div class="overflow-x-auto">
        <table class="w-full text-sm">
            <thead class="bg-gradient-to-r from-pink-50 to-rose-50 text-gray-600">
                <tr>
                    <th class="px-4 py-3 text-left">头像</th>
                    <th class="px-4 py-3 text-left">歌手名</th>
                    <th class="px-4 py-3 text-left">歌曲数</th>
                    <th class="px-4 py-3 text-left hidden md:table-cell">简介</th>
                    <th class="px-4 py-3 text-center">操作</th>
                </tr>
            </thead>
            <tbody class="divide-y divide-pink-50">
                <?php if (empty($artists)): ?>
                    <tr><td colspan="5" class="text-center py-12 text-gray-400">暂无歌手</td></tr>
                <?php else: ?>
                    <?php foreach ($artists as $a): ?>
                        <tr class="hover:bg-pink-50/50">
                            <td class="px-4 py-2">
                                <img src="<?php echo $a['display_avatar'] ? '../' . e($a['display_avatar']) : '../assets/images/default-artist.svg'; ?>"
                                     class="w-10 h-10 rounded-full object-cover border-2 border-pink-100">
                            </td>
                            <td class="px-4 py-2 font-medium text-gray-800"><?php echo e($a['name']); ?></td>
                            <td class="px-4 py-2 text-gray-600"><?php echo $a['music_count']; ?></td>
                            <td class="px-4 py-2 text-gray-500 hidden md:table-cell max-w-xs truncate"><?php echo e($a['bio'] ?: '-'); ?></td>
                            <td class="px-4 py-2 text-center">
                                <a href="delete_artist.php?id=<?php echo $a['id']; ?>&redirect=artists.php"
                                   class="text-red-400 hover:text-red-600 px-2" title="删除歌手">
                                    <i class="ri ri-delete-bin-line"></i>
                                </a>
                            </td>
                        </tr>
                    <?php endforeach; ?>
                <?php endif; ?>
            </tbody>
        </table>
    </div>
</div>

<?php require_once __DIR__ . '/footer.php'; ?>
