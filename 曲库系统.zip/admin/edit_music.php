<?php
/**
 * 编辑音乐（后台页面式操作）
 * GET: 显示编辑表单
 * POST: 保存修改
 */
require_once __DIR__ . '/../includes/auth.php';
requireLogin();

$pdo = Database::getConnection();
$error = '';
$success = '';

$musicId = (int)($_GET['id'] ?? $_POST['id'] ?? 0);
$redirect = $_GET['redirect'] ?? $_POST['redirect'] ?? 'admin/music.php';

if ($musicId <= 0) {
    http_response_code(404);
    exit('音乐不存在');
}

// 查询音乐
$stmt = $pdo->prepare("SELECT * FROM music WHERE id = ?");
$stmt->execute([$musicId]);
$music = $stmt->fetch();

if (!$music) {
    http_response_code(404);
    exit('音乐不存在');
}

// 权限检查：上传者本人或管理员
$currentUser = currentUser();
if ($music['uploader_id'] != $_SESSION['user_id'] && !isAdmin()) {
    http_response_code(403);
    exit('无权修改此音乐');
}

// 获取可选歌手列表（普通用户只能选自己的歌手，管理员可选全部）
if (isSuperAdmin()) {
    $artists = $pdo->query("SELECT * FROM artists ORDER BY name ASC")->fetchAll();
} else {
    $stmt = $pdo->prepare("SELECT * FROM artists WHERE created_by = ? ORDER BY name ASC");
    $stmt->execute([$_SESSION['user_id']]);
    $artists = $stmt->fetchAll();
}

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $title = trim($_POST['title'] ?? '');
    $artistId = (int)($_POST['artist_id'] ?? 0);
    $cover = $music['cover'];

    if (empty($title)) {
        $error = '歌曲名不能为空';
    } else {
        // 处理封面上传（同名覆盖）
        if (!empty($_FILES['cover']['name']) && $_FILES['cover']['error'] === UPLOAD_ERR_OK) {
            if ($_FILES['cover']['size'] > 5 * 1024 * 1024) {
                $error = '封面图片不能超过 5MB';
            } else {
                $allowedImg = ['jpg', 'jpeg', 'png', 'gif', 'webp'];
                $imgExt = strtolower(pathinfo($_FILES['cover']['name'], PATHINFO_EXTENSION));
                if (in_array($imgExt, $allowedImg)) {
                    // 找到上传者用户名
                    $stmt = $pdo->prepare("SELECT username FROM users WHERE id = ?");
                    $stmt->execute([$music['uploader_id']]);
                    $uploader = $stmt->fetch();
                    $username = $uploader['username'];

                    $coverRelDir = userSubDir($username, 'covers');
                    $coverDir = __DIR__ . '/../' . $coverRelDir;
                    $newCover = saveUploadedFile($_FILES['cover'], $coverDir, $coverRelDir);
                    if ($newCover) {
                        // 删除旧封面（如果不同名）
                        if ($music['cover'] && $music['cover'] !== $newCover && file_exists(__DIR__ . '/../' . $music['cover'])) {
                            @unlink(__DIR__ . '/../' . $music['cover']);
                        }
                        $cover = $newCover;
                    } else {
                        $error = '封面保存失败';
                    }
                } else {
                    $error = '封面仅支持 JPG/PNG/GIF/WebP';
                }
            }
        }

        if (!$error) {
            try {
                $stmt = $pdo->prepare("UPDATE music SET title = ?, artist_id = ?, cover = ? WHERE id = ?");
                $stmt->execute([$title, $artistId ?: null, $cover, $musicId]);
                $success = '修改成功';
                // 重新查询
                $stmt = $pdo->prepare("SELECT * FROM music WHERE id = ?");
                $stmt->execute([$musicId]);
                $music = $stmt->fetch();
            } catch (Exception $e) {
                $error = '修改失败：' . $e->getMessage();
            }
        }
    }
}

$pageTitle = '编辑音乐 - 甜音曲库';
$adminTitle = '编辑音乐';
include __DIR__ . '/header.php';
?>
<div class="max-w-2xl mx-auto">
    <div class="flex items-center gap-3 mb-6">
        <a href="<?php echo e($redirect); ?>" class="w-9 h-9 rounded-full bg-white/70 flex items-center justify-center text-gray-500 hover:bg-white">
            <i class="ri ri-arrow-left-s-line text-sm"></i>
        </a>
        <h1 class="text-xl font-bold text-gray-800">编辑音乐</h1>
    </div>

    <div class="bg-white/60 backdrop-blur rounded-3xl p-6">
        <?php if ($error): ?>
            <div class="bg-red-50 text-red-600 px-4 py-3 rounded-xl mb-4 text-sm">
                <i class="ri ri-information-line mr-2"></i><?php echo e($error); ?>
            </div>
        <?php endif; ?>
        <?php if ($success): ?>
            <div class="bg-green-50 text-green-600 px-4 py-3 rounded-xl mb-4 text-sm">
                <i class="ri ri-checkbox-circle-line mr-2"></i><?php echo e($success); ?>
            </div>
        <?php endif; ?>

        <form method="post" enctype="multipart/form-data" class="space-y-4">
            <input type="hidden" name="id" value="<?php echo $musicId; ?>">
            <input type="hidden" name="redirect" value="<?php echo e($redirect); ?>">

            <!-- 当前音乐文件信息 -->
            <div class="bg-white/40 rounded-xl p-4 text-sm text-gray-500">
                <div class="flex items-center gap-3">
                    <i class="ri ri-file-music-line text-pink-400 text-xl"></i>
                    <div>
                        <p>文件名：<?php echo e(basename($music['file_path'])); ?></p>
                        <p>格式：<?php echo e($music['file_type'] ?: '未知'); ?> · 大小：<?php echo formatSize($music['file_size']); ?></p>
                    </div>
                </div>
                <p class="text-xs text-gray-400 mt-2">提示：音乐文件本身不可修改，如需更换请删除后重新上传</p>
            </div>

            <!-- 歌曲名 -->
            <div>
                <label class="block text-sm font-medium text-gray-700 mb-1">歌曲名 <span class="text-red-400">*</span></label>
                <input type="text" name="title" required value="<?php echo e($music['title']); ?>"
                       class="w-full px-4 py-2.5 rounded-xl bg-white/70 border border-pink-100 focus:outline-none focus:ring-2 focus:ring-pink-300">
            </div>

            <!-- 歌手 -->
            <div>
                <label class="block text-sm font-medium text-gray-700 mb-1">歌手</label>
                <select name="artist_id" class="w-full px-4 py-2.5 rounded-xl bg-white/70 border border-pink-100 focus:outline-none focus:ring-2 focus:ring-pink-300">
                    <option value="">— 选择歌手 —</option>
                    <?php foreach ($artists as $a): ?>
                        <option value="<?php echo $a['id']; ?>" <?php echo $music['artist_id'] == $a['id'] ? 'selected' : ''; ?>>
                            <?php echo e($a['name']); ?>
                        </option>
                    <?php endforeach; ?>
                </select>
            </div>

            <!-- 封面 -->
            <div>
                <label class="block text-sm font-medium text-gray-700 mb-1">歌曲封面</label>
                <div class="flex items-center gap-4">
                    <div id="coverPreview" class="w-20 h-20 rounded-xl bg-pink-50 flex items-center justify-center overflow-hidden border-2 border-pink-100">
                        <?php if ($music['cover']): ?>
                            <img src="../<?php echo e($music['cover']); ?>" class="w-full h-full object-cover">
                        <?php else: ?>
                            <i class="ri ri-image-line text-pink-300 text-2xl"></i>
                        <?php endif; ?>
                    </div>
                    <div>
                        <input type="file" name="cover" accept="image/*" id="coverInput" class="text-sm">
                        <p class="text-xs text-gray-400 mt-1">不超过 5MB，留空则不修改</p>
                    </div>
                </div>
            </div>

            <div class="flex gap-3 pt-2">
                <a href="<?php echo e($redirect); ?>" class="flex-1 py-3 rounded-xl bg-gray-100 text-gray-600 text-center font-medium hover:bg-gray-200 transition">
                    取消
                </a>
                <button type="submit" class="flex-1 py-3 rounded-xl bg-gradient-to-r from-pink-500 to-rose-500 text-white font-semibold hover:opacity-90 transition">
                    <i class="ri ri-save-line mr-1"></i>保存修改
                </button>
            </div>
        </form>
    </div>
</div>

<script>
document.getElementById('coverInput').addEventListener('change', function(e) {
    const file = e.target.files[0];
    if (file) {
        if (file.size > 5 * 1024 * 1024) {
            alert('封面不能超过 5MB');
            e.target.value = '';
            return;
        }
        const reader = new FileReader();
        reader.onload = function(ev) {
            document.getElementById('coverPreview').innerHTML = '<img src="' + ev.target.result + '" class="w-full h-full object-cover">';
        };
        reader.readAsDataURL(file);
    }
});
</script>
<?php include __DIR__ . '/footer.php'; ?>
