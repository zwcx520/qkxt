<?php
/**
 * 删除用户（页面式操作，仅限超级管理员）
 * GET: 显示确认页
 * POST: 执行删除（连同所有音乐文件、封面、用户文件夹）
 */
require_once __DIR__ . '/../includes/auth.php';
requireSuperAdmin();

$pdo = Database::getConnection();
$error = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $userId = (int)($_POST['id'] ?? 0);
    $redirect = $_POST['redirect'] ?? 'admin/users.php';

    if ($userId <= 0) {
        $error = '无效的用户ID';
    } elseif ($userId == $_SESSION['user_id']) {
        $error = '不能删除当前登录账号';
    } else {
        $stmt = $pdo->prepare("SELECT * FROM users WHERE id = ?");
        $stmt->execute([$userId]);
        $user = $stmt->fetch();

        if (!$user) {
            $error = '用户不存在';
        } elseif ($user['role'] === 'admin') {
            $adminCount = $pdo->query("SELECT COUNT(*) FROM users WHERE role = 'admin'")->fetchColumn();
            if ($adminCount <= 1) {
                $error = '不能删除最后一个管理员';
            }
        }

        if (!$error) {
            try {
                $pdo->beginTransaction();

                // 查询该用户上传的所有音乐
                $stmt = $pdo->prepare("SELECT * FROM music WHERE uploader_id = ?");
                $stmt->execute([$userId]);
                $musicList = $stmt->fetchAll();

                // 删除所有音乐文件和封面
                foreach ($musicList as $m) {
                    if ($m['file_path'] && file_exists(__DIR__ . '/../' . $m['file_path'])) {
                        @unlink(__DIR__ . '/../' . $m['file_path']);
                    }
                    if ($m['cover'] && file_exists(__DIR__ . '/../' . $m['cover'])) {
                        @unlink(__DIR__ . '/../' . $m['cover']);
                    }
                    if (!empty($m['album_cover']) && file_exists(__DIR__ . '/../' . $m['album_cover'])) {
                        @unlink(__DIR__ . '/../' . $m['album_cover']);
                    }
                }

                // 删除该用户创建的歌手头像
                $stmt = $pdo->prepare("SELECT avatar FROM artists WHERE created_by = ?");
                $stmt->execute([$userId]);
                foreach ($stmt->fetchAll(PDO::FETCH_COLUMN) as $avatar) {
                    if ($avatar && file_exists(__DIR__ . '/../' . $avatar)) {
                        @unlink(__DIR__ . '/../' . $avatar);
                    }
                }

                // 删除用户头像
                if ($user['avatar'] && file_exists(__DIR__ . '/../' . $user['avatar'])) {
                    @unlink(__DIR__ . '/../' . $user['avatar']);
                }

                // 删除用户记录（外键 CASCADE 清理关联数据）
                $stmt = $pdo->prepare("DELETE FROM users WHERE id = ?");
                $stmt->execute([$userId]);

                $pdo->commit();

                // 递归删除用户专属文件夹
                removeDirectory(__DIR__ . '/../' . userDir($user['username']));
            } catch (Exception $e) {
                $pdo->rollBack();
                $error = '删除失败：' . $e->getMessage();
            }
        }
    }

    if (!$error) {
        header('Location: ' . $redirect . '?msg=' . urlencode('用户及相关数据已全部删除'));
        exit;
    }
}

// GET 或 POST 出错：显示确认页
$userId = (int)($_GET['id'] ?? $_POST['id'] ?? 0);
$redirect = $_GET['redirect'] ?? $_POST['redirect'] ?? 'admin/users.php';
$user = null;
$stats = ['music' => 0, 'artists' => 0];
if ($userId > 0) {
    $stmt = $pdo->prepare("SELECT * FROM users WHERE id = ?");
    $stmt->execute([$userId]);
    $user = $stmt->fetch();
    if ($user) {
        $stmt = $pdo->prepare("SELECT COUNT(*) FROM music WHERE uploader_id = ?");
        $stmt->execute([$userId]);
        $stats['music'] = (int)$stmt->fetchColumn();
        $stmt = $pdo->prepare("SELECT COUNT(*) FROM artists WHERE created_by = ?");
        $stmt->execute([$userId]);
        $stats['artists'] = (int)$stmt->fetchColumn();
    }
}

$pageTitle = '删除用户 - 甜音曲库';
$adminTitle = '删除用户';
include __DIR__ . '/header.php';
?>
<div class="max-w-2xl mx-auto">
    <div class="bg-white/60 backdrop-blur rounded-3xl p-8 text-center">
        <div class="w-16 h-16 mx-auto rounded-full bg-red-100 flex items-center justify-center mb-4">
            <i class="ri ri-error-warning-line text-red-500 text-3xl"></i>
        </div>
        <h1 class="text-xl font-bold text-gray-800 mb-2">确认删除用户</h1>

        <?php if ($error): ?>
            <div class="bg-red-50 text-red-600 px-4 py-3 rounded-xl mb-4 text-sm"><?php echo e($error); ?></div>
        <?php endif; ?>

        <?php if ($user): ?>
            <div class="bg-white/50 rounded-2xl p-4 mb-6">
                <div class="flex items-center gap-3 justify-center">
                    <?php if ($user['avatar']): ?>
                        <img src="<?php echo e($user['avatar']); ?>" class="w-14 h-14 rounded-full object-cover">
                    <?php else: ?>
                        <div class="w-14 h-14 rounded-full bg-pink-100 flex items-center justify-center">
                            <i class="ri ri-user-line text-pink-400 text-xl"></i>
                        </div>
                    <?php endif; ?>
                    <div class="text-left">
                        <p class="font-semibold text-gray-800"><?php echo e(userDisplayName($user)); ?></p>
                        <p class="text-sm text-gray-500">@<?php echo e($user['username']); ?> · <?php echo $user['role'] === 'admin' ? '管理员' : '普通用户'; ?></p>
                    </div>
                </div>
                <div class="flex justify-center gap-6 mt-4 text-sm">
                    <div><span class="font-bold text-pink-500"><?php echo $stats['music']; ?></span> 首音乐</div>
                    <div><span class="font-bold text-pink-500"><?php echo $stats['artists']; ?></span> 个歌手</div>
                </div>
            </div>
            <p class="text-gray-500 text-sm mb-6">
                将删除该用户的<strong class="text-red-500">所有音乐文件、封面图片、歌手头像、用户头像</strong>及<strong class="text-red-500">整个用户文件夹</strong>，此操作不可恢复！
            </p>
            <form method="post">
                <input type="hidden" name="id" value="<?php echo $userId; ?>">
                <input type="hidden" name="redirect" value="<?php echo e($redirect); ?>">
                <div class="flex gap-3">
                    <a href="<?php echo e($redirect); ?>" class="flex-1 py-3 rounded-xl bg-gray-100 text-gray-600 font-medium hover:bg-gray-200 transition">
                        取消
                    </a>
                    <button type="submit" class="flex-1 py-3 rounded-xl bg-gradient-to-r from-red-500 to-rose-500 text-white font-semibold hover:opacity-90 transition">
                        <i class="ri ri-delete-bin-line mr-1"></i>确认删除
                    </button>
                </div>
            </form>
        <?php else: ?>
            <p class="text-gray-500 mb-6">用户不存在或已被删除</p>
            <a href="<?php echo e($redirect); ?>" class="inline-block px-6 py-3 rounded-xl bg-pink-500 text-white font-medium">返回</a>
        <?php endif; ?>
    </div>
</div>
<?php include __DIR__ . '/footer.php'; ?>
