<?php
$adminTitle = '用户管理';
require_once __DIR__ . '/header.php';
requireSuperAdmin();

$keyword = trim($_GET['q'] ?? '');
$sql = "SELECT u.*, COUNT(m.id) AS music_count, COALESCE(SUM(m.file_size),0) AS total_size
        FROM users u LEFT JOIN music m ON u.id = m.uploader_id
        WHERE 1=1";
$params = [];
if ($keyword) {
    $sql .= " AND (u.username LIKE ? OR u.nickname LIKE ? OR u.email LIKE ?)";
    $kw = "%{$keyword}%";
    $params = [$kw, $kw, $kw];
}
$sql .= " GROUP BY u.id ORDER BY u.created_at DESC";
$stmt = $pdo->prepare($sql);
$stmt->execute($params);
$users = $stmt->fetchAll();
?>
<h1 class="text-2xl font-bold text-gray-800 mb-6"><i class="ri ri-team-line text-pink-500 mr-2"></i>用户管理</h1>

<form method="get" class="mb-6 max-w-md">
    <div class="relative">
        <i class="ri ri-search-line absolute left-4 top-1/2 -translate-y-1/2 text-pink-400"></i>
        <input type="text" name="q" value="<?php echo e($keyword); ?>" placeholder="搜索用户名或邮箱..."
               class="w-full pl-11 pr-4 py-2.5 rounded-xl border-2 border-pink-200 bg-white focus:border-pink-400">
    </div>
</form>

<div class="bg-white/70 backdrop-blur rounded-2xl overflow-hidden">
    <div class="overflow-x-auto">
        <table class="w-full text-sm">
            <thead class="bg-gradient-to-r from-pink-50 to-rose-50 text-gray-600">
                <tr>
                    <th class="px-4 py-3 text-left">用户</th>
                    <th class="px-4 py-3 text-left">邮箱</th>
                    <th class="px-4 py-3 text-left hidden sm:table-cell">角色</th>
                    <th class="px-4 py-3 text-left hidden md:table-cell">上传歌曲</th>
                    <th class="px-4 py-3 text-left hidden md:table-cell">占用空间</th>
                    <th class="px-4 py-3 text-left hidden lg:table-cell">注册时间</th>
                    <th class="px-4 py-3 text-center">操作</th>
                </tr>
            </thead>
            <tbody class="divide-y divide-pink-50">
                <?php foreach ($users as $u): ?>
                    <tr class="hover:bg-pink-50/50">
                        <td class="px-4 py-2">
                            <div class="flex items-center gap-2">
                                <img src="../assets/images/default-avatar.svg"
                                     class="w-9 h-9 rounded-full border-2 border-pink-100">
                                <div>
                                    <div class="font-medium text-gray-800"><?php echo e(userDisplayName($u)); ?></div>
                                    <div class="text-xs text-gray-400">账号：<?php echo e($u['username']); ?></div>
                                </div>
                            </div>
                        </td>
                        <td class="px-4 py-2 text-gray-600"><?php echo e($u['email']); ?></td>
                        <td class="px-4 py-2 hidden sm:table-cell">
                            <span class="px-2 py-1 rounded-full text-xs
                                <?php echo $u['role']==='admin'?'bg-purple-100 text-purple-600':'bg-pink-100 text-pink-600'; ?>">
                                <?php echo $u['role']==='admin'?'管理员':'用户'; ?>
                            </span>
                        </td>
                        <td class="px-4 py-2 text-gray-600 hidden md:table-cell"><?php echo $u['music_count']; ?></td>
                        <td class="px-4 py-2 text-gray-600 hidden md:table-cell"><?php echo formatSize($u['total_size']); ?></td>
                        <td class="px-4 py-2 text-gray-500 hidden lg:table-cell"><?php echo date('Y-m-d', strtotime($u['created_at'])); ?></td>
                        <td class="px-4 py-2 text-center">
                            <div class="flex items-center justify-center gap-1">
                                <?php if ($u['id'] != $_SESSION['user_id']): ?>
                                    <a href="reset_password.php?id=<?php echo $u['id']; ?>&redirect=users.php"
                                       class="text-blue-400 hover:text-blue-600 px-1.5 py-1" title="重置密码">
                                        <i class="ri ri-lock-password-line"></i>
                                    </a>
                                    <a href="toggle_role.php?id=<?php echo $u['id']; ?>&redirect=users.php"
                                       class="text-purple-400 hover:text-purple-600 px-1.5 py-1" title="切换角色">
                                        <i class="ri ri-shield-user-line"></i>
                                    </a>
                                    <a href="delete_user.php?id=<?php echo $u['id']; ?>&redirect=users.php"
                                       class="text-red-400 hover:text-red-600 px-1.5 py-1" title="删除用户及全部数据">
                                        <i class="ri ri-delete-bin-line"></i>
                                    </a>
                                <?php else: ?>
                                    <span class="text-gray-300 text-xs">当前账号</span>
                                <?php endif; ?>
                            </div>
                        </td>
                    </tr>
                <?php endforeach; ?>
            </tbody>
        </table>
    </div>
</div>

<?php require_once __DIR__ . '/footer.php'; ?>
