<?php
/**
 * 切换用户角色（页面式操作，仅限超级管理员）
 * GET: 显示确认页
 * POST: 执行切换
 */
require_once __DIR__ . '/../includes/auth.php';
requireSuperAdmin();

$pdo = Database::getConnection();
$error = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $userId = (int)($_POST['id'] ?? 0);
    $redirect = $_POST['redirect'] ?? 'admin/users.php';

    if ($userId <= 0) {
        $error = '无效的用户ID';
    } elseif ($userId == $_SESSION['user_id']) {
        $error = '不能修改当前登录账号的角色';
    } else {
        $stmt = $pdo->prepare("SELECT role FROM users WHERE id = ?");
        $stmt->execute([$userId]);
        $user = $stmt->fetch();

        if (!$user) {
            $error = '用户不存在';
        } elseif ($user['role'] === 'admin') {
            $adminCount = $pdo->query("SELECT COUNT(*) FROM users WHERE role = 'admin'")->fetchColumn();
            if ($adminCount <= 1) {
                $error = '不能降级最后一个管理员';
            }
        }

        if (!$error) {
            try {
                $newRole = $user['role'] === 'admin' ? 'user' : 'admin';
                $stmt = $pdo->prepare("UPDATE users SET role = ? WHERE id = ?");
                $stmt->execute([$newRole, $userId]);
                header('Location: ' . $redirect . '?msg=' . urlencode('角色已更新为' . ($newRole === 'admin' ? '管理员' : '普通用户')));
                exit;
            } catch (Exception $e) {
                $error = '操作失败：' . $e->getMessage();
            }
        }
    }
}

// GET 或 POST 出错：显示确认页
$userId = (int)($_GET['id'] ?? $_POST['id'] ?? 0);
$redirect = $_GET['redirect'] ?? $_POST['redirect'] ?? 'admin/users.php';
$user = null;
if ($userId > 0) {
    $stmt = $pdo->prepare("SELECT * FROM users WHERE id = ?");
    $stmt->execute([$userId]);
    $user = $stmt->fetch();
}

$pageTitle = '切换角色 - 甜音曲库';
$adminTitle = '切换角色';
include __DIR__ . '/header.php';
?>
<div class="max-w-md mx-auto">
    <div class="bg-white/60 backdrop-blur rounded-3xl p-8 text-center">
        <div class="w-16 h-16 mx-auto rounded-full bg-purple-100 flex items-center justify-center mb-4">
            <i class="ri ri-shield-user-line text-purple-500 text-3xl"></i>
        </div>
        <h1 class="text-xl font-bold text-gray-800 mb-2">切换用户角色</h1>

        <?php if ($error): ?>
            <div class="bg-red-50 text-red-600 px-4 py-3 rounded-xl mb-4 text-sm"><?php echo e($error); ?></div>
        <?php endif; ?>

        <?php if ($user): ?>
            <?php
            $currentRole = $user['role'] === 'admin' ? '管理员' : '普通用户';
            $newRole = $user['role'] === 'admin' ? '普通用户' : '管理员';
            ?>
            <div class="bg-white/50 rounded-2xl p-4 mb-6">
                <?php if ($user['avatar']): ?>
                    <img src="<?php echo e($user['avatar']); ?>" class="w-16 h-16 rounded-full object-cover mx-auto mb-2">
                <?php endif; ?>
                <p class="font-semibold text-gray-800"><?php echo e(userDisplayName($user)); ?></p>
                <p class="text-sm text-gray-500">@<?php echo e($user['username']); ?></p>
                <div class="flex items-center justify-center gap-3 mt-3">
                    <span class="px-3 py-1 rounded-full bg-gray-200 text-gray-600 text-sm"><?php echo $currentRole; ?></span>
                    <i class="ri ri-arrow-right-line text-pink-400"></i>
                    <span class="px-3 py-1 rounded-full bg-pink-100 text-pink-600 text-sm"><?php echo $newRole; ?></span>
                </div>
            </div>
            <p class="text-gray-500 text-sm mb-6">确定将该用户角色从「<?php echo $currentRole; ?>」改为「<?php echo $newRole; ?>」吗？</p>
            <form method="post">
                <input type="hidden" name="id" value="<?php echo $userId; ?>">
                <input type="hidden" name="redirect" value="<?php echo e($redirect); ?>">
                <div class="flex gap-3">
                    <a href="<?php echo e($redirect); ?>" class="flex-1 py-3 rounded-xl bg-gray-100 text-gray-600 font-medium hover:bg-gray-200 transition">
                        取消
                    </a>
                    <button type="submit" class="flex-1 py-3 rounded-xl bg-gradient-to-r from-purple-500 to-indigo-500 text-white font-semibold hover:opacity-90 transition">
                        <i class="ri ri-check-line mr-1"></i>确认切换
                    </button>
                </div>
            </form>
        <?php else: ?>
            <p class="text-gray-500 mb-6">用户不存在</p>
            <a href="<?php echo e($redirect); ?>" class="inline-block px-6 py-3 rounded-xl bg-pink-500 text-white font-medium">返回</a>
        <?php endif; ?>
    </div>
</div>
<?php include __DIR__ . '/footer.php'; ?>
