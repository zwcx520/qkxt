<?php
require_once __DIR__ . '/../includes/auth.php';
requireAdmin();
$pdo = Database::getConnection();
$adminUser = currentUser();
?>
<!DOCTYPE html>
<html lang="zh-CN">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?php echo $adminTitle ?? '管理后台'; ?> - 甜音曲库</title>
    <script src="https://cdn.tailwindcss.com"></script>
    <link rel="stylesheet" href="https://cdn.bootcdn.net/ajax/libs/remixicon/4.2.0/remixicon.css">
    <link rel="stylesheet" href="../assets/css/style.css">
</head>
<body class="bg-gradient-to-br from-slate-50 to-pink-50 min-h-screen">
    <div class="flex min-h-screen">
        <!-- 侧边栏 -->
        <aside class="w-60 bg-gradient-to-b from-pink-500 to-rose-600 text-white fixed h-full overflow-y-auto hidden md:block">
            <div class="p-6 text-center border-b border-white/20">
                <div class="w-12 h-12 mx-auto rounded-full bg-white/20 flex items-center justify-center mb-2">
                    <i class="ri ri-music-line text-xl"></i>
                </div>
                <h1 class="font-bold text-lg">甜音曲库</h1>
                <p class="text-xs text-pink-100"><?php echo isSuperAdmin() ? '管理后台' : '我的后台'; ?></p>
            </div>
            <nav class="p-4 space-y-1">
                <a href="index.php" class="block px-4 py-2.5 rounded-xl hover:bg-white/20 transition <?php echo basename($_SERVER['PHP_SELF'])==='index.php'?'bg-white/20':''; ?>">
                    <i class="ri ri-dashboard-line mr-2"></i>仪表盘
                </a>
                <a href="music.php" class="block px-4 py-2.5 rounded-xl hover:bg-white/20 transition <?php echo basename($_SERVER['PHP_SELF'])==='music.php'?'bg-white/20':''; ?>">
                    <i class="ri ri-music-line mr-2"></i>音乐管理
                </a>
                <a href="artists.php" class="block px-4 py-2.5 rounded-xl hover:bg-white/20 transition <?php echo basename($_SERVER['PHP_SELF'])==='artists.php'?'bg-white/20':''; ?>">
                    <i class="ri ri-mic-line mr-2"></i>歌手管理
                </a>
                <?php if (isSuperAdmin()): ?>
                <a href="users.php" class="block px-4 py-2.5 rounded-xl hover:bg-white/20 transition <?php echo basename($_SERVER['PHP_SELF'])==='users.php'?'bg-white/20':''; ?>">
                    <i class="ri ri-team-line mr-2"></i>用户管理
                </a>
                <?php endif; ?>
                <a href="../index.php" class="block px-4 py-2.5 rounded-xl hover:bg-white/20 transition">
                    <i class="ri ri-external-link-line mr-2"></i>返回前台
                </a>
            </nav>
            <div class="absolute bottom-0 left-0 right-0 p-4 border-t border-white/20">
                <a href="../logout.php" class="block px-4 py-2.5 rounded-xl hover:bg-white/20 transition text-center">
                    <i class="ri ri-logout-box-r-line mr-2"></i>退出
                </a>
            </div>
        </aside>

        <!-- 移动端顶栏 -->
        <div class="md:hidden fixed top-0 left-0 right-0 bg-gradient-to-r from-pink-500 to-rose-600 text-white p-3 flex items-center justify-between z-50">
            <button onclick="document.getElementById('mobileSidebar').classList.toggle('hidden')">
                <i class="ri ri-menu-line text-xl"></i>
            </button>
            <span class="font-bold">管理后台</span>
            <a href="../logout.php"><i class="ri ri-logout-box-r-line"></i></a>
        </div>
        <div id="mobileSidebar" class="hidden md:hidden fixed top-12 left-0 right-0 bg-gradient-to-b from-pink-500 to-rose-600 text-white z-40 p-4 space-y-1">
            <a href="index.php" class="block px-4 py-2.5 rounded-xl hover:bg-white/20"><i class="ri ri-dashboard-line mr-2"></i>仪表盘</a>
            <a href="music.php" class="block px-4 py-2.5 rounded-xl hover:bg-white/20"><i class="ri ri-music-line mr-2"></i>音乐管理</a>
            <a href="artists.php" class="block px-4 py-2.5 rounded-xl hover:bg-white/20"><i class="ri ri-mic-line mr-2"></i>歌手管理</a>
            <?php if (isSuperAdmin()): ?>
            <a href="users.php" class="block px-4 py-2.5 rounded-xl hover:bg-white/20"><i class="ri ri-team-line mr-2"></i>用户管理</a>
            <?php endif; ?>
            <a href="../index.php" class="block px-4 py-2.5 rounded-xl hover:bg-white/20"><i class="ri ri-external-link-line mr-2"></i>返回前台</a>
        </div>

        <!-- 主内容 -->
        <main class="flex-1 md:ml-60 mt-12 md:mt-0 p-6">
            <?php if (!empty($_GET['msg'])): ?>
                <div class="mb-4 px-4 py-3 rounded-xl bg-green-50 text-green-600 text-sm flex items-center gap-2">
                    <i class="ri ri-checkbox-circle-line"></i><?php echo e($_GET['msg']); ?>
                </div>
            <?php endif; ?>
