<?php
/**
 * 重置用户密码（页面式操作，仅限超级管理员）
 * GET: 显示密码输入表单
 * POST: 执行重置
 */
require_once __DIR__ . '/../includes/auth.php';
requireSuperAdmin();

$pdo = Database::getConnection();
$error = '';
$success = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $userId = (int)($_POST['id'] ?? 0);
    $newPassword = trim($_POST['password'] ?? '');
    $redirect = $_POST['redirect'] ?? 'admin/users.php';

    if ($userId <= 0) {
        $error = '无效的用户ID';
    } elseif (strlen($newPassword) < 6) {
        $error = '密码至少6位';
    } elseif ($userId == $_SESSION['user_id']) {
        $error = '不能重置当前登录账号的密码，请前往资料修改页修改';
    } else {
        $stmt = $pdo->prepare("SELECT username FROM users WHERE id = ?");
        $stmt->execute([$userId]);
        $user = $stmt->fetch();

        if (!$user) {
            $error = '用户不存在';
        } else {
            try {
                $hash = password_hash($newPassword, PASSWORD_DEFAULT);
                $stmt = $pdo->prepare("UPDATE users SET password = ? WHERE id = ?");
                $stmt->execute([$hash, $userId]);
                $success = '密码已重置为：' . $newPassword;
            } catch (Exception $e) {
                $error = '重置失败：' . $e->getMessage();
            }
        }
    }
}

// GET 或显示表单
$userId = (int)($_GET['id'] ?? $_POST['id'] ?? 0);
$redirect = $_GET['redirect'] ?? $_POST['redirect'] ?? 'admin/users.php';
$user = null;
if ($userId > 0) {
    $stmt = $pdo->prepare("SELECT * FROM users WHERE id = ?");
    $stmt->execute([$userId]);
    $user = $stmt->fetch();
}

$pageTitle = '重置密码 - 甜音曲库';
$adminTitle = '重置密码';
include __DIR__ . '/header.php';
?>
<div class="max-w-md mx-auto">
    <div class="bg-white/60 backdrop-blur rounded-3xl p-8">
        <div class="text-center mb-6">
            <div class="w-16 h-16 mx-auto rounded-full bg-blue-100 flex items-center justify-center mb-3">
                <i class="ri ri-lock-password-line text-blue-500 text-3xl"></i>
            </div>
            <h1 class="text-xl font-bold text-gray-800">重置密码</h1>
        </div>

        <?php if ($error): ?>
            <div class="bg-red-50 text-red-600 px-4 py-3 rounded-xl mb-4 text-sm">
                <i class="ri ri-information-line mr-2"></i><?php echo e($error); ?>
            </div>
        <?php endif; ?>
        <?php if ($success): ?>
            <div class="bg-green-50 text-green-600 px-4 py-3 rounded-xl mb-4 text-sm">
                <i class="ri ri-checkbox-circle-line mr-2"></i><?php echo e($success); ?>
            </div>
            <a href="<?php echo e($redirect); ?>" class="block w-full py-3 rounded-xl bg-pink-500 text-white text-center font-semibold">
                返回
            </a>
        <?php elseif ($user): ?>
            <div class="bg-white/50 rounded-2xl p-4 mb-6 text-center">
                <?php if ($user['avatar']): ?>
                    <img src="<?php echo e($user['avatar']); ?>" class="w-16 h-16 rounded-full object-cover mx-auto mb-2">
                <?php endif; ?>
                <p class="font-semibold text-gray-800"><?php echo e(userDisplayName($user)); ?></p>
                <p class="text-sm text-gray-500">@<?php echo e($user['username']); ?></p>
            </div>

            <form method="post" class="space-y-4">
                <input type="hidden" name="id" value="<?php echo $userId; ?>">
                <input type="hidden" name="redirect" value="<?php echo e($redirect); ?>">
                <div>
                    <label class="block text-sm font-medium text-gray-700 mb-1">新密码</label>
                    <input type="text" name="password" required minlength="6" class="w-full px-4 py-2.5 rounded-xl bg-white/70 border border-pink-100 focus:outline-none focus:ring-2 focus:ring-pink-300" placeholder="至少6位">
                </div>
                <div class="flex gap-3">
                    <a href="<?php echo e($redirect); ?>" class="flex-1 py-3 rounded-xl bg-gray-100 text-gray-600 text-center font-medium hover:bg-gray-200 transition">
                        取消
                    </a>
                    <button type="submit" class="flex-1 py-3 rounded-xl bg-gradient-to-r from-blue-500 to-indigo-500 text-white font-semibold hover:opacity-90 transition">
                        <i class="ri ri-save-line mr-1"></i>重置密码
                    </button>
                </div>
            </form>
        <?php else: ?>
            <p class="text-gray-500 text-center mb-6">用户不存在</p>
            <a href="<?php echo e($redirect); ?>" class="block w-full py-3 rounded-xl bg-pink-500 text-white text-center font-semibold">返回</a>
        <?php endif; ?>
    </div>
</div>
<?php include __DIR__ . '/footer.php'; ?>
