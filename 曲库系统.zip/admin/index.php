<?php
$adminTitle = '仪表盘';
require_once __DIR__ . '/header.php';

$isSuper = isSuperAdmin();
$uid = $adminUser['id'];

if ($isSuper) {
    $stats = [
        'music' => $pdo->query("SELECT COUNT(*) FROM music")->fetchColumn(),
        'artists' => $pdo->query("SELECT COUNT(*) FROM artists")->fetchColumn(),
        'users' => $pdo->query("SELECT COUNT(*) FROM users")->fetchColumn(),
        'plays' => $pdo->query("SELECT COALESCE(SUM(play_count),0) FROM music")->fetchColumn(),
        'storage' => $pdo->query("SELECT COALESCE(SUM(file_size),0) FROM music")->fetchColumn(),
    ];
    // 最近上传
    $recent = $pdo->query("SELECT m.*, a.name AS artist_name, COALESCE(NULLIF(u.nickname,''), u.username) AS uploader_name
                           FROM music m LEFT JOIN artists a ON m.artist_id = a.id
                           LEFT JOIN users u ON m.uploader_id = u.id
                           ORDER BY m.created_at DESC LIMIT 10")->fetchAll();
    // 最近注册用户
    $recentUsers = $pdo->query("SELECT * FROM users ORDER BY created_at DESC LIMIT 5")->fetchAll();
    // 热门歌曲排行（按播放量）
    $hotMusic = $pdo->query("SELECT m.*, a.name AS artist_name FROM music m
                             LEFT JOIN artists a ON m.artist_id = a.id
                             ORDER BY m.play_count DESC LIMIT 8")->fetchAll();
} else {
    // 普通用户：只统计自己的数据
    $stats = [
        'music' => $pdo->prepare("SELECT COUNT(*) FROM music WHERE uploader_id = ?"),
        'artists' => $pdo->prepare("SELECT COUNT(*) FROM artists WHERE created_by = ?"),
        'users' => 1,
        'plays' => $pdo->prepare("SELECT COALESCE(SUM(play_count),0) FROM music WHERE uploader_id = ?"),
        'storage' => $pdo->prepare("SELECT COALESCE(SUM(file_size),0) FROM music WHERE uploader_id = ?"),
    ];
    foreach (['music', 'artists', 'plays', 'storage'] as $k) {
        $stats[$k]->execute([$uid]);
        $stats[$k] = $stats[$k]->fetchColumn();
    }
    // 自己最近上传
    $stmt = $pdo->prepare("SELECT m.*, a.name AS artist_name, COALESCE(NULLIF(u.nickname,''), u.username) AS uploader_name
                           FROM music m LEFT JOIN artists a ON m.artist_id = a.id
                           LEFT JOIN users u ON m.uploader_id = u.id
                           WHERE m.uploader_id = ?
                           ORDER BY m.created_at DESC LIMIT 10");
    $stmt->execute([$uid]);
    $recent = $stmt->fetchAll();
    $recentUsers = [];
    // 自己的热门歌曲
    $stmt = $pdo->prepare("SELECT m.*, a.name AS artist_name FROM music m
                           LEFT JOIN artists a ON m.artist_id = a.id
                           WHERE m.uploader_id = ?
                           ORDER BY m.play_count DESC LIMIT 8");
    $stmt->execute([$uid]);
    $hotMusic = $stmt->fetchAll();
}
?>
<h1 class="text-2xl font-bold text-gray-800 mb-6">
    <i class="ri ri-dashboard-line text-pink-500 mr-2"></i>
    仪表盘
    <?php if (!$isSuper): ?>
        <span class="text-sm text-pink-400 font-normal ml-2">（仅显示我的数据）</span>
    <?php endif; ?>
</h1>

<!-- 统计卡片 -->
<div class="grid grid-cols-2 lg:grid-cols-5 gap-4 mb-6">
    <div class="stat-card">
        <div class="w-12 h-12 rounded-xl bg-pink-100 flex items-center justify-center mb-3">
            <i class="ri ri-music-line text-pink-500 text-xl"></i>
        </div>
        <div class="text-2xl font-bold text-gray-800"><?php echo $stats['music']; ?></div>
        <div class="text-sm text-gray-500">音乐总数</div>
    </div>
    <div class="stat-card">
        <div class="w-12 h-12 rounded-xl bg-rose-100 flex items-center justify-center mb-3">
            <i class="ri ri-mic-line text-rose-500 text-xl"></i>
        </div>
        <div class="text-2xl font-bold text-gray-800"><?php echo $stats['artists']; ?></div>
        <div class="text-sm text-gray-500">歌手总数</div>
    </div>
    <?php if ($isSuper): ?>
    <div class="stat-card">
        <div class="w-12 h-12 rounded-xl bg-fuchsia-100 flex items-center justify-center mb-3">
            <i class="ri ri-team-line text-fuchsia-500 text-xl"></i>
        </div>
        <div class="text-2xl font-bold text-gray-800"><?php echo $stats['users']; ?></div>
        <div class="text-sm text-gray-500">用户总数</div>
    </div>
    <?php endif; ?>
    <div class="stat-card">
        <div class="w-12 h-12 rounded-xl bg-purple-100 flex items-center justify-center mb-3">
            <i class="ri ri-headphone-line text-purple-500 text-xl"></i>
        </div>
        <div class="text-2xl font-bold text-gray-800"><?php echo $stats['plays']; ?></div>
        <div class="text-sm text-gray-500">总播放量</div>
    </div>
    <div class="stat-card">
        <div class="w-12 h-12 rounded-xl bg-amber-100 flex items-center justify-center mb-3">
            <i class="ri ri-database-2-line text-amber-500 text-xl"></i>
        </div>
        <div class="text-2xl font-bold text-gray-800"><?php echo formatSize($stats['storage']); ?></div>
        <div class="text-sm text-gray-500">存储占用</div>
    </div>
</div>

<!-- 快捷操作 -->
<div class="bg-white/70 backdrop-blur rounded-2xl p-5 mb-6">
    <h2 class="font-bold text-gray-800 mb-4"><i class="ri ri-apps-line text-pink-500 mr-2"></i>快捷操作</h2>
    <div class="grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-5 gap-3">
        <a href="../upload.php" class="quick-action">
            <i class="ri ri-upload-cloud-2-line text-pink-500"></i>
            <span>上传音乐</span>
        </a>
        <a href="music.php" class="quick-action">
            <i class="ri ri-music-line text-rose-500"></i>
            <span>音乐管理</span>
        </a>
        <a href="artists.php" class="quick-action">
            <i class="ri ri-mic-line text-fuchsia-500"></i>
            <span>歌手管理</span>
        </a>
        <?php if ($isSuper): ?>
        <a href="users.php" class="quick-action">
            <i class="ri ri-team-line text-purple-500"></i>
            <span>用户管理</span>
        </a>
        <?php endif; ?>
        <a href="../index.php" class="quick-action">
            <i class="ri ri-home-line text-amber-500"></i>
            <span>返回前台</span>
        </a>
    </div>
</div>

<div class="grid lg:grid-cols-3 gap-6">
    <!-- 最近上传 -->
    <div class="lg:col-span-<?php echo $isSuper ? '2' : '3'; ?> bg-white/70 backdrop-blur rounded-2xl overflow-hidden">
        <div class="px-6 py-4 border-b border-pink-50 bg-gradient-to-r from-pink-50 to-rose-50 flex items-center justify-between">
            <h2 class="font-bold text-gray-800"><i class="ri ri-time-line text-pink-500 mr-2"></i><?php echo $isSuper ? '最近上传' : '我的上传'; ?></h2>
            <a href="music.php" class="text-xs text-pink-500 hover:underline">查看全部 <i class="ri ri-arrow-right-s-line align-middle"></i></a>
        </div>
        <div class="divide-y divide-pink-50">
            <?php if (empty($recent)): ?>
                <div class="p-8 text-center text-gray-400">暂无数据</div>
            <?php else: ?>
                <?php foreach ($recent as $m): ?>
                    <a href="music.php" class="flex items-center gap-3 px-6 py-3 hover:bg-pink-50/50">
                        <img src="<?php echo $m['cover'] ? '../' . e($m['cover']) : '../assets/images/default-cover.svg'; ?>"
                             class="w-10 h-10 rounded-lg object-cover">
                        <div class="flex-1 min-w-0">
                            <div class="font-medium text-gray-800 truncate"><?php echo e($m['title']); ?></div>
                            <div class="text-xs text-gray-400"><?php echo e($m['artist_name'] ?: '未知'); ?> · <?php echo $isSuper ? e($m['uploader_name'] ?: '已删除') : '我'; ?></div>
                        </div>
                        <span class="text-xs text-gray-400"><?php echo date('m-d H:i', strtotime($m['created_at'])); ?></span>
                    </a>
                <?php endforeach; ?>
            <?php endif; ?>
        </div>
    </div>

    <?php if ($isSuper): ?>
    <!-- 最近注册用户 -->
    <div class="bg-white/70 backdrop-blur rounded-2xl overflow-hidden">
        <div class="px-6 py-4 border-b border-pink-50 bg-gradient-to-r from-pink-50 to-rose-50 flex items-center justify-between">
            <h2 class="font-bold text-gray-800"><i class="ri ri-user-add-line text-pink-500 mr-2"></i>新用户</h2>
            <a href="users.php" class="text-xs text-pink-500 hover:underline">查看全部 <i class="ri ri-arrow-right-s-line align-middle"></i></a>
        </div>
        <div class="divide-y divide-pink-50">
            <?php foreach ($recentUsers as $u): ?>
                <a href="users.php" class="flex items-center gap-3 px-6 py-3 hover:bg-pink-50/50">
                    <img src="../assets/images/default-avatar.svg"
                         class="w-9 h-9 rounded-full border-2 border-pink-100">
                    <div class="flex-1 min-w-0">
                        <div class="text-sm font-medium text-gray-800 truncate"><?php echo e(userDisplayName($u)); ?></div>
                        <div class="text-xs text-gray-400 truncate">账号：<?php echo e($u['username']); ?> · <?php echo e($u['email']); ?></div>
                    </div>
                    <span class="text-xs <?php echo $u['role']==='admin'?'text-purple-500':'text-pink-400'; ?>"><?php echo $u['role']==='admin'?'管理员':'用户'; ?></span>
                </a>
            <?php endforeach; ?>
        </div>
    </div>
    <?php endif; ?>
</div>

<!-- 热门歌曲排行 -->
<div class="bg-white/70 backdrop-blur rounded-2xl overflow-hidden mt-6">
    <div class="px-6 py-4 border-b border-pink-50 bg-gradient-to-r from-pink-50 to-rose-50">
        <h2 class="font-bold text-gray-800"><i class="ri ri-fire-line text-pink-500 mr-2"></i><?php echo $isSuper ? '热门歌曲排行' : '我的热门歌曲'; ?></h2>
    </div>
    <div class="divide-y divide-pink-50">
        <?php if (empty($hotMusic)): ?>
            <div class="p-8 text-center text-gray-400">暂无数据</div>
        <?php else: ?>
            <?php $rank = 1; foreach ($hotMusic as $m): ?>
                <a href="music.php" class="flex items-center gap-3 px-6 py-3 hover:bg-pink-50/50">
                    <span class="w-6 text-center text-sm font-bold <?php echo $rank<=3 ? 'text-pink-500' : 'text-gray-400'; ?>"><?php echo $rank; ?></span>
                    <img src="<?php echo $m['cover'] ? '../' . e($m['cover']) : '../assets/images/default-cover.svg'; ?>"
                         class="w-10 h-10 rounded-lg object-cover">
                    <div class="flex-1 min-w-0">
                        <div class="font-medium text-gray-800 truncate"><?php echo e($m['title']); ?></div>
                        <div class="text-xs text-gray-400"><?php echo e($m['artist_name'] ?: '未知'); ?></div>
                    </div>
                    <div class="flex items-center gap-1 text-xs text-purple-500">
                        <i class="ri ri-play-circle-line"></i>
                        <span><?php echo (int)$m['play_count']; ?></span>
                    </div>
                </a>
            <?php $rank++; endforeach; ?>
        <?php endif; ?>
    </div>
</div>

<?php require_once __DIR__ . '/footer.php'; ?>
