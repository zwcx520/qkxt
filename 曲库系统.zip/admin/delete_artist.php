<?php
/**
 * 删除歌手（页面式操作）
 * GET: 显示确认页
 * POST: 执行删除（连同该歌手所有音乐文件和封面）
 */
require_once __DIR__ . '/../includes/auth.php';
requireLogin();

$pdo = Database::getConnection();
$error = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $artistId = (int)($_POST['id'] ?? 0);
    $redirect = $_POST['redirect'] ?? 'admin/artists.php';

    if ($artistId <= 0) {
        $error = '无效的歌手ID';
    } else {
        $stmt = $pdo->prepare("SELECT * FROM artists WHERE id = ?");
        $stmt->execute([$artistId]);
        $artist = $stmt->fetch();

        if (!$artist) {
            $error = '歌手不存在';
        } elseif ($artist['created_by'] != $_SESSION['user_id'] && !isSuperAdmin()) {
            $error = '无权删除此歌手';
        } else {
            try {
                $pdo->beginTransaction();

                // 查询该歌手下的所有音乐
                $stmt = $pdo->prepare("SELECT * FROM music WHERE artist_id = ?");
                $stmt->execute([$artistId]);
                $musicList = $stmt->fetchAll();

                // 删除所有音乐文件和封面
                foreach ($musicList as $m) {
                    if ($m['file_path'] && file_exists(__DIR__ . '/../' . $m['file_path'])) {
                        @unlink(__DIR__ . '/../' . $m['file_path']);
                    }
                    if ($m['cover'] && file_exists(__DIR__ . '/../' . $m['cover'])) {
                        @unlink(__DIR__ . '/../' . $m['cover']);
                    }
                    if (!empty($m['album_cover']) && file_exists(__DIR__ . '/../' . $m['album_cover'])) {
                        @unlink(__DIR__ . '/../' . $m['album_cover']);
                    }
                }

                // 删除该歌手的所有音乐记录
                $stmt = $pdo->prepare("DELETE FROM music WHERE artist_id = ?");
                $stmt->execute([$artistId]);

                // 删除歌手头像
                if ($artist['avatar'] && file_exists(__DIR__ . '/../' . $artist['avatar'])) {
                    @unlink(__DIR__ . '/../' . $artist['avatar']);
                }

                // 删除歌手记录
                $stmt = $pdo->prepare("DELETE FROM artists WHERE id = ?");
                $stmt->execute([$artistId]);

                $pdo->commit();
            } catch (Exception $e) {
                $pdo->rollBack();
                $error = '删除失败：' . $e->getMessage();
            }
        }
    }

    if (!$error) {
        header('Location: ' . $redirect . '?msg=' . urlencode('歌手及音乐文件已全部删除'));
        exit;
    }
}

// GET 或 POST 出错：显示确认页
$artistId = (int)($_GET['id'] ?? $_POST['id'] ?? 0);
$redirect = $_GET['redirect'] ?? $_POST['redirect'] ?? 'admin/artists.php';
$artist = null;
$musicCount = 0;
if ($artistId > 0) {
    $stmt = $pdo->prepare("SELECT * FROM artists WHERE id = ?");
    $stmt->execute([$artistId]);
    $artist = $stmt->fetch();
    if ($artist) {
        $stmt = $pdo->prepare("SELECT COUNT(*) FROM music WHERE artist_id = ?");
        $stmt->execute([$artistId]);
        $musicCount = (int)$stmt->fetchColumn();
    }
}

$pageTitle = '删除歌手 - 甜音曲库';
$adminTitle = '删除歌手';
include __DIR__ . '/header.php';
?>
<div class="max-w-2xl mx-auto">
    <div class="bg-white/60 backdrop-blur rounded-3xl p-8 text-center">
        <div class="w-16 h-16 mx-auto rounded-full bg-red-100 flex items-center justify-center mb-4">
            <i class="ri ri-error-warning-line text-red-500 text-3xl"></i>
        </div>
        <h1 class="text-xl font-bold text-gray-800 mb-2">确认删除歌手</h1>

        <?php if ($error): ?>
            <div class="bg-red-50 text-red-600 px-4 py-3 rounded-xl mb-4 text-sm"><?php echo e($error); ?></div>
        <?php endif; ?>

        <?php if ($artist): ?>
            <div class="bg-white/50 rounded-2xl p-4 mb-6">
                <div class="flex items-center gap-3 justify-center">
                    <?php if ($artist['avatar']): ?>
                        <img src="<?php echo e($artist['avatar']); ?>" class="w-14 h-14 rounded-full object-cover">
                    <?php else: ?>
                        <div class="w-14 h-14 rounded-full bg-pink-100 flex items-center justify-center">
                            <i class="ri ri-mic-line text-pink-400 text-xl"></i>
                        </div>
                    <?php endif; ?>
                    <div class="text-left">
                        <p class="font-semibold text-gray-800"><?php echo e($artist['name']); ?></p>
                        <p class="text-sm text-gray-500">共 <?php echo $musicCount; ?> 首音乐</p>
                    </div>
                </div>
            </div>
            <p class="text-gray-500 text-sm mb-6">
                将删除该歌手的<strong class="text-red-500">头像</strong>，以及该歌手下<strong class="text-red-500">所有音乐文件和封面图片</strong>，此操作不可恢复！
            </p>
            <form method="post">
                <input type="hidden" name="id" value="<?php echo $artistId; ?>">
                <input type="hidden" name="redirect" value="<?php echo e($redirect); ?>">
                <div class="flex gap-3">
                    <a href="<?php echo e($redirect); ?>" class="flex-1 py-3 rounded-xl bg-gray-100 text-gray-600 font-medium hover:bg-gray-200 transition">
                        取消
                    </a>
                    <button type="submit" class="flex-1 py-3 rounded-xl bg-gradient-to-r from-red-500 to-rose-500 text-white font-semibold hover:opacity-90 transition">
                        <i class="ri ri-delete-bin-line mr-1"></i>确认删除
                    </button>
                </div>
            </form>
        <?php else: ?>
            <p class="text-gray-500 mb-6">歌手不存在或已被删除</p>
            <a href="<?php echo e($redirect); ?>" class="inline-block px-6 py-3 rounded-xl bg-pink-500 text-white font-medium">返回</a>
        <?php endif; ?>
    </div>
</div>
<?php include __DIR__ . '/footer.php'; ?>
