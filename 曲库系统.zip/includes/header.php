<?php
require_once __DIR__ . '/auth.php';
$currentPage = basename($_SERVER['PHP_SELF']);
$user = currentUser();
?>
<!DOCTYPE html>
<html lang="zh-CN">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?php echo $pageTitle ?? '音乐曲库'; ?></title>
    <script src="https://cdn.tailwindcss.com"></script>
    <link rel="stylesheet" href="https://cdn.bootcdn.net/ajax/libs/remixicon/4.2.0/remixicon.css">
    <link rel="stylesheet" href="assets/css/style.css">
</head>
<body class="bg-gradient-to-br from-pink-50 via-rose-50 to-fuchsia-50 min-h-screen">
    <!-- 顶部导航 -->
    <nav class="fixed top-0 left-0 right-0 z-50 glass-nav">
        <div class="max-w-7xl mx-auto px-4 py-3 flex items-center justify-between">
            <a href="index.php" class="flex items-center gap-2">
                <div class="w-10 h-10 rounded-full bg-gradient-to-br from-pink-400 to-rose-500 flex items-center justify-center shadow-lg">
                    <i class="ri ri-music-line text-white"></i>
                </div>
                <span class="text-xl font-bold bg-gradient-to-r from-pink-500 to-rose-500 bg-clip-text text-transparent">
                    甜音曲库
                </span>
            </a>

            <!-- 桌面导航 -->
            <div class="hidden md:flex items-center gap-6">
                <a href="index.php" class="nav-link <?php echo $currentPage==='index.php'?'active':''; ?>">
                    <i class="ri ri-home-line mr-1"></i>首页
                </a>
                <a href="artists.php" class="nav-link <?php echo $currentPage==='artists.php'?'active':''; ?>">
                    <i class="ri ri-mic-line mr-1"></i>歌手
                </a>
                <a href="player.php" class="nav-link <?php echo $currentPage==='player.php'?'active':''; ?>">
                    <i class="ri ri-play-line mr-1"></i>播放器
                </a>
                <?php if (isLoggedIn()): ?>
                    <a href="admin/index.php" class="nav-link">
                        <i class="ri ri-settings-line mr-1"></i><?php echo isSuperAdmin() ? '管理' : '后台'; ?>
                    </a>
                <?php endif; ?>
            </div>

            <!-- 用户区 -->
            <div class="flex items-center gap-3">
                <?php if ($user): ?>
                    <div class="relative" id="userMenu">
                        <button onclick="toggleUserMenu()" class="flex items-center gap-2 px-3 py-1.5 rounded-full hover:bg-pink-100 transition">
                            <img src="<?php echo $user['avatar'] ? e($user['avatar']) : 'assets/images/default-avatar.svg'; ?>"
                                 class="w-8 h-8 rounded-full object-cover border-2 border-pink-200">
                            <span class="hidden sm:inline text-sm font-medium text-gray-700"><?php echo e(userDisplayName($user)); ?></span>
                            <i class="ri ri-arrow-down-s-line text-xs text-gray-400"></i>
                        </button>
                        <div id="userDropdown" class="hidden absolute right-0 mt-2 w-48 bg-white rounded-xl shadow-xl overflow-hidden">
                            <a href="profile.php" class="block px-4 py-2 hover:bg-pink-50 text-sm text-gray-700">
                                <i class="ri ri-user-line mr-2 text-pink-400"></i>个人中心
                            </a>
                            <a href="upload.php" class="block px-4 py-2 hover:bg-pink-50 text-sm text-gray-700">
                                <i class="ri ri-upload-cloud-2-line mr-2 text-pink-400"></i>上传音乐
                            </a>
                            <a href="admin/index.php" class="block px-4 py-2 hover:bg-pink-50 text-sm text-gray-700">
                                <i class="ri ri-settings-line mr-2 text-pink-400"></i><?php echo isSuperAdmin() ? '管理后台' : '我的后台'; ?>
                            </a>
                            <a href="logout.php" class="block px-4 py-2 hover:bg-red-50 text-sm text-red-500">
                                <i class="ri ri-logout-box-r-line mr-2"></i>退出登录
                            </a>
                        </div>
                    </div>
                <?php else: ?>
                    <a href="login.php" class="px-4 py-1.5 rounded-full bg-gradient-to-r from-pink-500 to-rose-500 text-white text-sm font-medium shadow hover:shadow-lg transition">
                        登录
                    </a>
                <?php endif; ?>
                <button onclick="toggleMobileMenu()" class="md:hidden text-gray-600 text-xl">
                    <i class="ri ri-menu-line"></i>
                </button>
            </div>
        </div>

        <!-- 移动端菜单 -->
        <div id="mobileMenu" class="hidden md:hidden px-4 pb-3 space-y-2">
            <a href="index.php" class="block px-4 py-2 rounded-lg hover:bg-pink-100 text-gray-700"><i class="ri ri-home-line mr-2"></i>首页</a>
            <a href="artists.php" class="block px-4 py-2 rounded-lg hover:bg-pink-100 text-gray-700"><i class="ri ri-mic-line mr-2"></i>歌手</a>
            <a href="player.php" class="block px-4 py-2 rounded-lg hover:bg-pink-100 text-gray-700"><i class="ri ri-play-line mr-2"></i>播放器</a>
            <?php if (isLoggedIn()): ?>
                <a href="admin/index.php" class="block px-4 py-2 rounded-lg hover:bg-pink-100 text-gray-700"><i class="ri ri-settings-line mr-2"></i><?php echo isSuperAdmin() ? '管理' : '后台'; ?></a>
            <?php endif; ?>
        </div>
    </nav>

    <main class="max-w-7xl mx-auto px-4 py-6 pt-20 pb-28 md:pb-24">
    <?php if (!empty($_GET['msg'])): ?>
        <div class="mb-4 px-4 py-3 rounded-xl bg-green-50 text-green-600 text-sm flex items-center gap-2">
            <i class="ri ri-checkbox-circle-line"></i><?php echo e($_GET['msg']); ?>
        </div>
    <?php endif; ?>
<script>
function toggleUserMenu() {
    document.getElementById('userDropdown').classList.toggle('hidden');
}
function toggleMobileMenu() {
    document.getElementById('mobileMenu').classList.toggle('hidden');
}
document.addEventListener('click', function(e) {
    const menu = document.getElementById('userMenu');
    if (menu && !menu.contains(e.target)) {
        document.getElementById('userDropdown').classList.add('hidden');
    }
});

// ===== 全局音频播放器 =====
const MiniPlayer = {
    audio: null,
    current: null,
    progressTimer: null,

    init() {
        this.audio = new Audio();
        this.audio.addEventListener('timeupdate', () => this.updateProgress());
        this.audio.addEventListener('ended', () => this.onEnded());
        // 恢复上次播放
        const saved = sessionStorage.getItem('mini_current');
        if (saved) {
            try {
                this.current = JSON.parse(saved);
                const pos = parseFloat(sessionStorage.getItem('mini_position') || '0');
                this.audio.src = this.current.file;
                this.audio.currentTime = pos;
                this.audio.play().catch(() => {});
                this.showBar();
            } catch(e) {}
        }
    },

    play(song) {
        if (!this.audio) {
            this.audio = new Audio();
            this.audio.addEventListener('timeupdate', () => this.updateProgress());
            this.audio.addEventListener('ended', () => this.onEnded());
        }
        this.current = song;
        sessionStorage.setItem('mini_current', JSON.stringify(song));
        this.audio.src = song.file;
        this.audio.play().then(() => {
            this.showBar();
        }).catch(() => {
            // 自动播放被阻止，显示但不播放
            this.showBar();
        });
    },

    toggle() {
        if (!this.audio) return;
        if (this.audio.paused) {
            this.audio.play();
        } else {
            this.audio.pause();
        }
        this.updatePlayIcon();
    },

    updatePlayIcon() {
        const btn = document.getElementById('miniPlayBtn');
        if (btn) {
            btn.className = 'ri ' + (this.audio.paused ? 'ri-play-fill' : 'ri-pause-fill');
        }
    },

    showBar() {
        const bar = document.getElementById('miniPlayer');
        if (!bar || !this.current) return;
        bar.classList.remove('hidden');
        document.getElementById('miniCover').src = this.current.cover || 'assets/images/default-cover.svg';
        document.getElementById('miniTitle').textContent = this.current.title;
        document.getElementById('miniArtist').textContent = this.current.artist || '';
        this.updatePlayIcon();
    },

    updateProgress() {
        const bar = document.getElementById('miniProgress');
        if (bar && this.audio.duration) {
            const pct = (this.audio.currentTime / this.audio.duration) * 100;
            bar.style.width = pct + '%';
        }
        sessionStorage.setItem('mini_position', this.audio.currentTime);
    },

    onEnded() {
        this.updatePlayIcon();
    },

    seek(e) {
        const bar = document.getElementById('miniProgressBar');
        if (!bar || !this.audio.duration) return;
        const rect = bar.getBoundingClientRect();
        const pct = (e.clientX - rect.left) / rect.width;
        this.audio.currentTime = Math.max(0, Math.min(1, pct)) * this.audio.duration;
    },

    goPlayer() {
        if (this.current) {
            window.location.href = 'player.php?id=' + this.current.id;
        }
    }
};

// 全局播放函数：启动迷你播放器
function playMusic(id, title, artist, file, cover) {
    // 兼容数组形式调用 playMusic([id, title, artist, file, cover])
    if (Array.isArray(id)) {
        var arr = id;
        id = arr[0];
        title = arr[1];
        artist = arr[2];
        file = arr[3];
        cover = arr[4];
    }
    MiniPlayer.play({
        id: id,
        title: title || '未知歌曲',
        artist: artist || '',
        file: file,
        cover: cover || 'assets/images/default-cover.svg'
    });
}

document.addEventListener('DOMContentLoaded', () => MiniPlayer.init());
</script>
