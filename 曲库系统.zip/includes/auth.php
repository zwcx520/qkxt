<?php
/**
 * 认证与工具函数
 */
session_start();
require_once __DIR__ . '/db.php';

/**
 * 数据库自动迁移：确保新增字段存在
 * 兼容旧版安装
 */
function ensureSchemaMigrations(): void
{
    static $checked = false;
    if ($checked) return;
    $checked = true;
    try {
        $pdo = Database::getConnection();

        // 1. users.nickname 字段
        $col = $pdo->query("SHOW COLUMNS FROM users LIKE 'nickname'");
        if (!$col->fetch()) {
            $pdo->exec("ALTER TABLE users ADD COLUMN nickname varchar(50) DEFAULT NULL COMMENT '昵称（用于显示及歌手名）' AFTER username");
        }

        // 2. artists.created_by 字段
        $col = $pdo->query("SHOW COLUMNS FROM artists LIKE 'created_by'");
        if (!$col->fetch()) {
            $pdo->exec("ALTER TABLE artists ADD COLUMN created_by int unsigned DEFAULT NULL COMMENT '创建者用户ID'");
        }

        // 3. music.cover 字段允许 NULL
        $col = $pdo->query("SHOW COLUMNS FROM music LIKE 'cover'");
        $row = $col->fetch();
        if ($row && strpos($row['Type'], 'varchar') !== false && strpos($row['Null'], 'NO') !== false) {
            $pdo->exec("ALTER TABLE music MODIFY COLUMN cover varchar(255) DEFAULT NULL");
        }
    } catch (Exception $e) {
        // 迁移失败不阻塞
    }
}
ensureSchemaMigrations();

function isLoggedIn(): bool
{
    return isset($_SESSION['user_id']);
}

/**
 * 获取用户显示名称：优先昵称，其次用户名
 */
function userDisplayName(?array $user): string
{
    if (!$user) return '';
    return !empty($user['nickname']) ? $user['nickname'] : ($user['username'] ?? '');
}

function currentUser(): ?array
{
    if (!isLoggedIn()) return null;
    // 实时查询，确保头像等信息即时更新
    $stmt = Database::getConnection()->prepare("SELECT * FROM users WHERE id = ?");
    $stmt->execute([$_SESSION['user_id']]);
    return $stmt->fetch() ?: null;
}

function isAdmin(): bool
{
    $u = currentUser();
    return $u && $u['role'] === 'admin';
}

function isSuperAdmin(): bool
{
    return isAdmin();
}

function requireLogin(): void
{
    if (!isLoggedIn()) {
        header('Location: login.php');
        exit;
    }
}

/**
 * 后台访问权限：所有登录用户均可进入后台
 * 普通用户只能管理自己的数据，超级管理员可管理全部
 */
function requireAdmin(): void
{
    requireLogin();
}

/**
 * 仅超级管理员可访问的页面
 */
function requireSuperAdmin(): void
{
    requireLogin();
    if (!isSuperAdmin()) {
        http_response_code(403);
        exit('无权限访问，该功能仅限超级管理员');
    }
}

function e($value): string
{
    return htmlspecialchars((string)$value, ENT_QUOTES, 'UTF-8');
}

/**
 * 清理文件名，保留原始名称，替换特殊字符
 * 用于"替换原文件"模式：同名文件直接覆盖
 */
function sanitizeFilename(string $filename): string
{
    $ext = strtolower(pathinfo($filename, PATHINFO_EXTENSION));
    $name = pathinfo($filename, PATHINFO_FILENAME);
    // 移除路径分隔符和危险字符，保留中文、字母、数字、下划线、横线、空格
    $name = preg_replace('/[\/\\\:\*\?"\<\>\|]/u', '_', $name);
    $name = trim($name);
    if (empty($name)) $name = 'file';
    return $name . '.' . $ext;
}

/**
 * 保存上传文件（同名覆盖）
 * @return string|false 成功返回相对路径，失败返回 false
 */
function saveUploadedFile(array $file, string $destDir, string $destRelDir)
{
    if (!is_dir($destDir)) mkdir($destDir, 0777, true);
    $filename = sanitizeFilename($file['name']);
    $destPath = $destDir . '/' . $filename;
    // move_uploaded_file 会自动覆盖同名文件
    if (move_uploaded_file($file['tmp_name'], $destPath)) {
        return $destRelDir . '/' . $filename;
    }
    return false;
}

function redirect($url): void
{
    header("Location: {$url}");
    exit;
}

function formatDuration(int $seconds): string
{
    if ($seconds <= 0) return '00:00';
    $m = floor($seconds / 60);
    $s = $seconds % 60;
    return sprintf('%02d:%02d', $m, $s);
}

function formatSize($bytes): string
{
    $bytes = (int)$bytes;
    if ($bytes < 1024) return $bytes . ' B';
    if ($bytes < 1048576) return round($bytes / 1024, 1) . ' KB';
    if ($bytes < 1073741824) return round($bytes / 1048576, 1) . ' MB';
    return round($bytes / 1073741824, 2) . ' GB';
}

/**
 * 递归删除目录
 */
function removeDirectory($dir): void
{
    if (!is_dir($dir)) return;
    $items = scandir($dir);
    foreach ($items as $item) {
        if ($item === '.' || $item === '..') continue;
        $path = $dir . DIRECTORY_SEPARATOR . $item;
        if (is_dir($path)) {
            removeDirectory($path);
        } else {
            @unlink($path);
        }
    }
    @rmdir($dir);
}

/**
 * 获取用户专属目录的相对路径（基于项目根目录）
 * 结构: uploads/users/{username}/
 */
function userDir(string $username): string
{
    return 'uploads/users/' . $username;
}

/**
 * 创建用户专属目录结构
 * uploads/users/{username}/music, covers, avatars
 */
function createUserDir(string $username): bool
{
    $base = __DIR__ . '/../' . userDir($username);
    $subdirs = ['music', 'covers', 'avatars'];
    foreach ($subdirs as $sub) {
        $dir = $base . '/' . $sub;
        if (!is_dir($dir) && !mkdir($dir, 0777, true)) {
            return false;
        }
    }
    return true;
}

/**
 * 获取用户子目录的相对路径
 */
function userSubDir(string $username, string $type): string
{
    return userDir($username) . '/' . $type;
}

