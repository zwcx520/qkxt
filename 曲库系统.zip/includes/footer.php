    </main>

    <!-- 迷你播放器（底部导航上方） -->
    <div id="miniPlayer" class="hidden fixed left-0 right-0 z-40 bottom-14 md:bottom-0">
        <div class="mx-2 bg-white/95 backdrop-blur-lg rounded-2xl shadow-lg overflow-hidden">
            <div class="flex items-center gap-3 px-3 py-2" onclick="MiniPlayer.goPlayer()">
                <img id="miniCover" src="" class="w-11 h-11 rounded-lg object-cover flex-shrink-0">
                <div class="flex-1 min-w-0">
                    <div id="miniTitle" class="text-sm font-medium text-gray-800 truncate"></div>
                    <div id="miniArtist" class="text-xs text-gray-400 truncate"></div>
                </div>
                <button onclick="event.stopPropagation(); MiniPlayer.toggle()" class="w-10 h-10 rounded-full bg-gradient-to-br from-pink-500 to-rose-500 flex items-center justify-center text-white flex-shrink-0 shadow">
                    <i id="miniPlayBtn" class="ri ri-play-fill text-lg ml-0.5"></i>
                </button>
            </div>
            <!-- 进度条 -->
            <div id="miniProgressBar" class="h-1 bg-pink-100 cursor-pointer" onclick="event.stopPropagation(); MiniPlayer.seek(event)">
                <div id="miniProgress" class="h-full bg-gradient-to-r from-pink-500 to-rose-500 transition-all" style="width: 0%"></div>
            </div>
        </div>
    </div>

    <!-- 底部 
    <footer class="mt-12 py-8 pb-20 md:pb-8 text-center text-gray-400 text-sm border-t border-pink-100">
        <p><i class="ri ri-heart-fill text-pink-400"></i> 甜音曲库 · 浪漫唯美音乐体验</p>
        <p class="mt-1">© <?php echo date('Y'); ?> Music Library CMS</p>
    </footer>
	-->
</body>
</html>
