<?php
/**
 * 删除音乐（页面式操作）
 * GET: 显示确认页
 * POST: 执行删除
 */
require_once __DIR__ . '/includes/auth.php';
requireLogin();

$pdo = Database::getConnection();
$error = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $musicId = (int)($_POST['id'] ?? 0);
    $redirect = $_POST['redirect'] ?? 'admin/music.php';

    if ($musicId <= 0) {
        $error = '无效的音乐ID';
    } else {
        $stmt = $pdo->prepare("SELECT * FROM music WHERE id = ?");
        $stmt->execute([$musicId]);
        $music = $stmt->fetch();

        if (!$music) {
            $error = '音乐不存在';
        } elseif ($music['uploader_id'] != $_SESSION['user_id'] && !isAdmin()) {
            $error = '无权删除此音乐';
        } else {
            try {
                $pdo->beginTransaction();
                $stmt = $pdo->prepare("DELETE FROM music WHERE id = ?");
                $stmt->execute([$musicId]);

                if ($music['file_path'] && file_exists(__DIR__ . '/' . $music['file_path'])) {
                    @unlink(__DIR__ . '/' . $music['file_path']);
                }
                if ($music['cover'] && file_exists(__DIR__ . '/' . $music['cover'])) {
                    @unlink(__DIR__ . '/' . $music['cover']);
                }
                if (!empty($music['album_cover']) && file_exists(__DIR__ . '/' . $music['album_cover'])) {
                    @unlink(__DIR__ . '/' . $music['album_cover']);
                }
                $pdo->commit();
            } catch (Exception $e) {
                $pdo->rollBack();
                $error = '删除失败：' . $e->getMessage();
            }
        }
    }

    if (!$error) {
        header('Location: ' . $redirect . '?msg=' . urlencode('删除成功'));
        exit;
    }
}

// GET 或 POST 出错：显示确认页
$musicId = (int)($_GET['id'] ?? $_POST['id'] ?? 0);
$redirect = $_GET['redirect'] ?? $_POST['redirect'] ?? 'admin/music.php';
$music = null;
if ($musicId > 0) {
    $stmt = $pdo->prepare("SELECT m.*, a.name as artist_name FROM music m LEFT JOIN artists a ON m.artist_id = a.id WHERE m.id = ?");
    $stmt->execute([$musicId]);
    $music = $stmt->fetch();
}

$pageTitle = '删除确认 - 甜音曲库';
include __DIR__ . '/admin/header.php';
?>
<div class="max-w-2xl mx-auto">
    <div class="bg-white/60 backdrop-blur rounded-3xl p-8 text-center">
        <div class="w-16 h-16 mx-auto rounded-full bg-red-100 flex items-center justify-center mb-4">
            <i class="ri ri-error-warning-line text-red-500 text-3xl"></i>
        </div>
        <h1 class="text-xl font-bold text-gray-800 mb-2">确认删除</h1>

        <?php if ($error): ?>
            <div class="bg-red-50 text-red-600 px-4 py-3 rounded-xl mb-4 text-sm"><?php echo e($error); ?></div>
        <?php endif; ?>

        <?php if ($music): ?>
            <div class="bg-white/50 rounded-2xl p-4 mb-6 text-left">
                <div class="flex items-center gap-3">
                    <?php if ($music['cover']): ?>
                        <img src="<?php echo e($music['cover']); ?>" class="w-14 h-14 rounded-lg object-cover">
                    <?php else: ?>
                        <div class="w-14 h-14 rounded-lg bg-pink-100 flex items-center justify-center">
                            <i class="ri ri-music-line text-pink-400 text-xl"></i>
                        </div>
                    <?php endif; ?>
                    <div>
                        <p class="font-semibold text-gray-800"><?php echo e($music['title']); ?></p>
                        <p class="text-sm text-gray-500"><?php echo e($music['artist_name'] ?: '未知歌手'); ?></p>
                    </div>
                </div>
            </div>
            <p class="text-gray-500 text-sm mb-6">
                将删除该音乐的<strong class="text-red-500">音乐文件</strong>和<strong class="text-red-500">封面图片</strong>，此操作不可恢复！
            </p>
            <form method="post">
                <input type="hidden" name="id" value="<?php echo $musicId; ?>">
                <input type="hidden" name="redirect" value="<?php echo e($redirect); ?>">
                <div class="flex gap-3">
                    <a href="<?php echo e($redirect); ?>" class="flex-1 py-3 rounded-xl bg-gray-100 text-gray-600 font-medium hover:bg-gray-200 transition">
                        取消
                    </a>
                    <button type="submit" class="flex-1 py-3 rounded-xl bg-gradient-to-r from-red-500 to-rose-500 text-white font-semibold hover:opacity-90 transition">
                        <i class="ri ri-delete-bin-line mr-1"></i>确认删除
                    </button>
                </div>
            </form>
        <?php else: ?>
            <p class="text-gray-500 mb-6">音乐不存在或已被删除</p>
            <a href="<?php echo e($redirect); ?>" class="inline-block px-6 py-3 rounded-xl bg-pink-500 text-white font-medium">返回</a>
        <?php endif; ?>
    </div>
</div>
<?php include __DIR__ . '/admin/footer.php'; ?>
