<?php
/**
 * 音乐曲库系统 - 安装向导
 */
session_start();
error_reporting(E_ALL);
ini_set('display_errors', 1);

$step = isset($_GET['step']) ? (int)$_GET['step'] : 1;
$error = '';
$success = '';

// 检查是否已安装
$lockFile = __DIR__ . '/installed.lock';
if (file_exists($lockFile) && $step < 4) {
    $step = 4;
}

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    if ($step === 2) {
        // 环境检测
        $requirements = checkRequirements();
        if ($requirements['allPassed']) {
            $step = 3;
        } else {
            $error = '环境检测未通过，请修正后重试。';
        }
    } elseif ($step === 3) {
        // 数据库配置 + 安装
        $dbHost = trim($_POST['db_host'] ?? 'localhost');
        $dbName = trim($_POST['db_name'] ?? '');
        $dbUser = trim($_POST['db_user'] ?? '');
        $dbPass = $_POST['db_pass'] ?? '';
        $dbPort = (int)($_POST['db_port'] ?? 3306);

        $adminUser = trim($_POST['admin_user'] ?? 'admin');
        $adminNickname = trim($_POST['admin_nickname'] ?? '');
        $adminPass = $_POST['admin_pass'] ?? '';
        $adminEmail = trim($_POST['admin_email'] ?? '');

        if (empty($dbName) || empty($dbUser) || empty($adminUser) || empty($adminPass) || empty($adminEmail)) {
            $error = '请填写所有必填项。';
        } else {
            try {
                $dsn = "mysql:host={$dbHost};port={$dbPort};charset=utf8mb4";
                $pdo = new PDO($dsn, $dbUser, $dbPass, [
                    PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION,
                    PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC,
                ]);

                // 创建数据库
                $pdo->exec("CREATE DATABASE IF NOT EXISTS `{$dbName}` DEFAULT CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci");
                $pdo->exec("USE `{$dbName}`");

                // 执行SQL
                $sql = file_get_contents(__DIR__ . '/../sql/schema.sql');
                $pdo->exec($sql);

                // 创建管理员
                $hash = password_hash($adminPass, PASSWORD_DEFAULT);
                $stmt = $pdo->prepare("INSERT INTO users (username, nickname, email, password, role) VALUES (?, ?, ?, ?, 'admin')");
                $stmt->execute([$adminUser, $adminNickname ?: null, $adminEmail, $hash]);
                $adminId = $pdo->lastInsertId();
                // 为管理员创建歌手记录（歌手名用昵称，无昵称则用用户名）
                $adminArtistName = $adminNickname ?: $adminUser;
                $stmt = $pdo->prepare("INSERT INTO artists (name, bio, created_by) VALUES (?, ?, ?)");
                $stmt->execute([$adminArtistName, '系统管理员', $adminId]);

                // 写入配置文件
                $configContent = "<?php\nreturn [\n";
                $configContent .= "    'host' => '{$dbHost}',\n";
                $configContent .= "    'port' => {$dbPort},\n";
                $configContent .= "    'dbname' => '{$dbName}',\n";
                $configContent .= "    'username' => '{$dbUser}',\n";
                $configContent .= "    'password' => '{$dbPass}',\n";
                $configContent .= "    'charset' => 'utf8mb4',\n";
                $configContent .= "];\n";

                $configDir = __DIR__ . '/../config';
                if (!is_dir($configDir)) mkdir($configDir, 0755, true);
                file_put_contents($configDir . '/database.php', $configContent);

                // 创建上传目录
                $uploadDirs = [
                    __DIR__ . '/../uploads/music',
                    __DIR__ . '/../uploads/covers',
                    __DIR__ . '/../uploads/avatars',
                    __DIR__ . '/../uploads/users',
                ];
                foreach ($uploadDirs as $dir) {
                    if (!is_dir($dir)) mkdir($dir, 0777, true);
                }

                // 创建管理员专属文件夹
                $adminBase = __DIR__ . '/../uploads/users/' . $adminUser;
                foreach (['music', 'covers', 'avatars'] as $sub) {
                    $d = $adminBase . '/' . $sub;
                    if (!is_dir($d)) mkdir($d, 0777, true);
                }

                // 写入安装锁
                file_put_contents($lockFile, date('Y-m-d H:i:s'));

                $step = 4;
                $success = '安装成功！';
            } catch (Exception $e) {
                $error = '安装失败：' . $e->getMessage();
            }
        }
    }
}

function checkRequirements() {
    $req = [];
    $req['php_version'] = version_compare(PHP_VERSION, '8.0.0', '>=');
    $req['pdo_mysql'] = extension_loaded('pdo_mysql');
    $req['mbstring'] = extension_loaded('mbstring');
    $req['file_uploads'] = ini_get('file_uploads') == 1;
    $req['writable_config'] = is_writable(__DIR__ . '/..') || is_writable(__DIR__ . '/../config');
    $req['allPassed'] = $req['php_version'] && $req['pdo_mysql'] && $req['mbstring'] && $req['file_uploads'];
    return $req;
}
?>
<!DOCTYPE html>
<html lang="zh-CN">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>音乐曲库系统 - 安装向导</title>
    <script src="https://cdn.tailwindcss.com"></script>
    <link rel="stylesheet" href="https://cdn.bootcdn.net/ajax/libs/remixicon/4.2.0/remixicon.css">
    <style>
        body {
            background: linear-gradient(135deg, #fce7f3 0%, #fbcfe8 50%, #f9a8d4 100%);
            min-height: 100vh;
            font-family: 'Segoe UI', 'PingFang SC', 'Microsoft YaHei', sans-serif;
        }
        .glass {
            background: rgba(255, 255, 255, 0.85);
            backdrop-filter: blur(20px);
            -webkit-backdrop-filter: blur(20px);
            border: 1px solid rgba(255, 255, 255, 0.5);
        }
        .step-active { background: linear-gradient(135deg, #ec4899, #f472b6); color: white; }
        .step-done { background: #10b981; color: white; }
        .step-pending { background: #e5e7eb; color: #9ca3af; }
        .btn-primary {
            background: linear-gradient(135deg, #ec4899, #f472b6);
            color: white;
            transition: all 0.3s;
        }
        .btn-primary:hover { transform: translateY(-2px); box-shadow: 0 10px 25px rgba(236,72,153,0.3); }
        input:focus { outline: none; border-color: #ec4899; box-shadow: 0 0 0 3px rgba(236,72,153,0.1); }
    </style>
</head>
<body class="flex items-center justify-center p-4">
    <div class="glass rounded-3xl shadow-2xl w-full max-w-3xl p-8 md:p-12">
        <div class="text-center mb-8">
            <div class="inline-flex items-center justify-center w-20 h-20 rounded-full bg-gradient-to-br from-pink-400 to-rose-500 mb-4 shadow-lg">
                <i class="ri ri-music-line text-white text-3xl"></i>
            </div>
            <h1 class="text-3xl font-bold text-gray-800">音乐曲库系统</h1>
            <p class="text-gray-500 mt-2">安装向导 · 浪漫唯美</p>
        </div>

        <!-- 步骤指示器 -->
        <div class="flex items-center justify-center mb-8">
            <?php for ($i = 1; $i <= 4; $i++): ?>
                <div class="flex items-center">
                    <div class="w-10 h-10 rounded-full flex items-center justify-center font-bold text-sm
                        <?php echo $step > $i ? 'step-done' : ($step == $i ? 'step-active' : 'step-pending'); ?>">
                        <?php echo $step > $i ? '<i class="ri ri-check-line"></i>' : $i; ?>
                    </div>
                    <?php if ($i < 4): ?>
                        <div class="w-12 md:w-20 h-1 mx-2 <?php echo $step > $i ? 'bg-green-500' : 'bg-gray-200'; ?>"></div>
                    <?php endif; ?>
                </div>
            <?php endfor; ?>
        </div>

        <?php if ($error): ?>
            <div class="bg-red-50 border border-red-200 text-red-700 px-4 py-3 rounded-xl mb-4">
                <i class="ri ri-information-line mr-2"></i><?php echo htmlspecialchars($error); ?>
            </div>
        <?php endif; ?>

        <?php if ($step === 1): ?>
            <div class="space-y-6">
                <h2 class="text-2xl font-bold text-gray-800">欢迎使用</h2>
                <p class="text-gray-600 leading-relaxed">
                    感谢您选择音乐曲库系统！本系统基于 PHP 8.0+ 和 MySQL 构建，
                    提供浪漫唯美风格的音乐管理与播放体验，支持用户上传、管理音乐，
                    拥有完整的播放器与歌手库功能。
                </p>
                <div class="grid grid-cols-2 gap-4 text-sm">
                    <div class="bg-pink-50 p-4 rounded-xl"><i class="ri ri-team-line text-pink-500 mr-2"></i>用户与管理员双角色</div>
                    <div class="bg-rose-50 p-4 rounded-xl"><i class="ri ri-upload-cloud-2-line text-rose-500 mr-2"></i>多格式音乐上传</div>
                    <div class="bg-fuchsia-50 p-4 rounded-xl"><i class="ri ri-play-line text-fuchsia-500 mr-2"></i>精美播放器</div>
                    <div class="bg-purple-50 p-4 rounded-xl"><i class="ri ri-mic-line text-purple-500 mr-2"></i>歌手曲库管理</div>
                </div>
                <a href="?step=2" class="btn-primary inline-block w-full text-center py-3 rounded-xl font-semibold">
                    开始安装 <i class="ri ri-arrow-right-line ml-2"></i>
                </a>
            </div>

        <?php elseif ($step === 2): ?>
            <?php $req = checkRequirements(); ?>
            <div class="space-y-4">
                <h2 class="text-2xl font-bold text-gray-800">环境检测</h2>
                <div class="space-y-2">
                    <?php
                    $items = [
                        ['PHP >= 8.0', $req['php_version'], '当前版本: ' . PHP_VERSION],
                        ['PDO MySQL 扩展', $req['pdo_mysql'], '用于数据库连接'],
                        ['MBString 扩展', $req['mbstring'], '用于多字节字符串处理'],
                        ['允许文件上传', $req['file_uploads'], 'file_uploads=' . ini_get('file_uploads')],
                        ['目录可写', $req['writable_config'], 'config 与 uploads 目录'],
                    ];
                    foreach ($items as $item): ?>
                        <div class="flex items-center justify-between p-3 rounded-xl bg-white/60">
                            <div>
                                <div class="font-medium text-gray-800"><?php echo $item[0]; ?></div>
                                <div class="text-xs text-gray-500"><?php echo $item[2]; ?></div>
                            </div>
                            <span class="<?php echo $item[1] ? 'text-green-500' : 'text-red-500'; ?>">
                                <i class="<?php echo $item[1] ? 'ri ri-checkbox-circle-line' : 'ri ri-close-circle-line'; ?> text-xl"></i>
                            </span>
                        </div>
                    <?php endforeach; ?>
                </div>
                <form method="post" action="?step=2">
                    <a href="?step=1" class="inline-block px-6 py-3 rounded-xl border border-gray-300 text-gray-600 mr-2">上一步</a>
                    <button type="submit" class="btn-primary px-8 py-3 rounded-xl font-semibold" <?php echo $req['allPassed'] ? '' : 'disabled'; ?>>
                        下一步 <i class="ri ri-arrow-right-line ml-2"></i>
                    </button>
                </form>
            </div>

        <?php elseif ($step === 3): ?>
            <div class="space-y-4">
                <h2 class="text-2xl font-bold text-gray-800">数据库与管理员配置</h2>
                <form method="post" action="?step=3">
                    <div class="grid md:grid-cols-2 gap-4">
                        <div>
                            <label class="block text-sm font-medium text-gray-700 mb-1">数据库主机</label>
                            <input type="text" name="db_host" value="localhost" class="w-full px-4 py-2 rounded-xl border border-gray-200" required>
                        </div>
                        <div>
                            <label class="block text-sm font-medium text-gray-700 mb-1">端口</label>
                            <input type="number" name="db_port" value="3306" class="w-full px-4 py-2 rounded-xl border border-gray-200" required>
                        </div>
                        <div>
                            <label class="block text-sm font-medium text-gray-700 mb-1">数据库名</label>
                            <input type="text" name="db_name" value="music_cms" class="w-full px-4 py-2 rounded-xl border border-gray-200" required>
                        </div>
                        <div>
                            <label class="block text-sm font-medium text-gray-700 mb-1">数据库用户名</label>
                            <input type="text" name="db_user" value="root" class="w-full px-4 py-2 rounded-xl border border-gray-200" required>
                        </div>
                        <div class="md:col-span-2">
                            <label class="block text-sm font-medium text-gray-700 mb-1">数据库密码</label>
                            <input type="password" name="db_pass" class="w-full px-4 py-2 rounded-xl border border-gray-200">
                        </div>
                    </div>
                    <div class="border-t border-gray-200 my-6"></div>
                    <div class="grid md:grid-cols-2 gap-4">
                        <div>
                            <label class="block text-sm font-medium text-gray-700 mb-1">管理员用户名 <span class="text-xs text-gray-400">（仅用于登录）</span></label>
                            <input type="text" name="admin_user" value="admin" class="w-full px-4 py-2 rounded-xl border border-gray-200" required>
                        </div>
                        <div>
                            <label class="block text-sm font-medium text-gray-700 mb-1">管理员昵称 <span class="text-xs text-gray-400">（用于显示，可选）</span></label>
                            <input type="text" name="admin_nickname" class="w-full px-4 py-2 rounded-xl border border-gray-200" placeholder="留空则使用用户名">
                        </div>
                        <div>
                            <label class="block text-sm font-medium text-gray-700 mb-1">管理员邮箱</label>
                            <input type="email" name="admin_email" class="w-full px-4 py-2 rounded-xl border border-gray-200" required>
                        </div>
                        <div class="md:col-span-2">
                            <label class="block text-sm font-medium text-gray-700 mb-1">管理员密码</label>
                            <input type="password" name="admin_pass" class="w-full px-4 py-2 rounded-xl border border-gray-200" required>
                        </div>
                    </div>
                    <div class="flex justify-between mt-6">
                        <a href="?step=2" class="px-6 py-3 rounded-xl border border-gray-300 text-gray-600">上一步</a>
                        <button type="submit" class="btn-primary px-8 py-3 rounded-xl font-semibold">
                            <i class="ri ri-magic-line mr-2"></i>执行安装
                        </button>
                    </div>
                </form>
            </div>

        <?php elseif ($step === 4): ?>
            <div class="text-center py-8">
                <div class="inline-flex items-center justify-center w-24 h-24 rounded-full bg-green-500 mb-6 animate-bounce">
                    <i class="ri ri-check-line text-white text-5xl"></i>
                </div>
                <h2 class="text-3xl font-bold text-gray-800 mb-2">安装完成！</h2>
                <p class="text-gray-500 mb-8">恭喜您，音乐曲库系统已成功安装</p>
                <div class="bg-yellow-50 border border-yellow-200 rounded-xl p-4 text-left text-sm text-yellow-800 mb-8">
                    <i class="ri ri-error-warning-line mr-2"></i>
                    为了安全，请手动删除 <code class="bg-yellow-100 px-2 py-1 rounded">install/</code> 目录。
                </div>
                <a href="../index.php" class="btn-primary inline-block px-10 py-3 rounded-xl font-semibold">
                    <i class="ri ri-home-line mr-2"></i>进入首页
                </a>
            </div>
        <?php endif; ?>
    </div>
</body>
</html>
