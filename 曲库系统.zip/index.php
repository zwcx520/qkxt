<?php
require_once __DIR__ . '/includes/auth.php';
$pageTitle = '甜音曲库 - 首页';

$pdo = Database::getConnection();
$keyword = trim($_GET['q'] ?? '');
$artistId = isset($_GET['artist']) ? (int)$_GET['artist'] : 0;

// 统计
$musicCount = $pdo->query("SELECT COUNT(*) FROM music")->fetchColumn();
$artistCount = $pdo->query("SELECT COUNT(*) FROM artists")->fetchColumn();
$userCount = $pdo->query("SELECT COUNT(*) FROM users")->fetchColumn();

// 获取音乐列表
$sql = "SELECT m.*, a.name AS artist_name, u.username AS uploader_name
        FROM music m
        LEFT JOIN artists a ON m.artist_id = a.id
        LEFT JOIN users u ON m.uploader_id = u.id
        WHERE 1=1";
$params = [];
if ($keyword) {
    $sql .= " AND (m.title LIKE ? OR a.name LIKE ? OR m.album LIKE ?)";
    $kw = "%{$keyword}%";
    $params = [$kw, $kw, $kw];
}
if ($artistId > 0) {
    $sql .= " AND m.artist_id = ?";
    $params[] = $artistId;
}
$sql .= " ORDER BY m.created_at DESC LIMIT 100";
$stmt = $pdo->prepare($sql);
$stmt->execute($params);
$musicList = $stmt->fetchAll();

// 获取热门歌手
$artists = $pdo->query("SELECT a.*, COALESCE(NULLIF(a.avatar,''), u.avatar) AS display_avatar,
                        COUNT(m.id) AS music_count
                        FROM artists a
                        LEFT JOIN music m ON a.id = m.artist_id
                        LEFT JOIN users u ON a.created_by = u.id
                        GROUP BY a.id ORDER BY music_count DESC LIMIT 10")->fetchAll();

// 分类标签
$tabs = ['推荐', '刷歌', '乐馆', '听书', 'AI作歌', '金印', 'All'];

include __DIR__ . '/includes/header.php';
?>

<!-- 顶部搜索栏 -->
<div class="sticky top-[60px] z-40 bg-gradient-to-b from-pink-50/95 to-pink-50/80 backdrop-blur py-3 -mx-4 px-4 mb-2">
    <form method="get" class="flex items-center gap-3">
        <div class="relative flex-1">
            <i class="ri ri-search-line absolute left-4 top-1/2 -translate-y-1/2 text-pink-400"></i>
            <input type="text" name="q" value="<?php echo e($keyword); ?>" placeholder="搜索歌曲、歌手、专辑"
                   class="w-full pl-11 pr-4 py-2.5 rounded-full bg-white/70 text-sm focus:bg-white transition">
        </div>
        <?php if (isLoggedIn()): ?>
            <a href="upload.php" class="w-10 h-10 rounded-full bg-gradient-to-br from-pink-500 to-rose-500 flex items-center justify-center text-white shadow-lg flex-shrink-0">
                <i class="ri ri-add-line"></i>
            </a>
        <?php endif; ?>
    </form>

    <!-- 分类标签 -->
    <div class="flex gap-1 mt-3 overflow-x-auto pb-1 scrollbar-hide">
        <?php foreach ($tabs as $i => $tab): ?>
            <button class="px-4 py-1.5 rounded-full text-sm whitespace-nowrap transition
                <?php echo $i === 0 ? 'bg-gradient-to-r from-green-400 to-emerald-500 text-white font-medium' : 'text-gray-500 hover:text-pink-500'; ?>">
                <?php echo $tab; ?>
            </button>
        <?php endforeach; ?>
    </div>
</div>

<?php if ($keyword || $artistId): ?>
    <a href="index.php" class="inline-block mb-3 text-pink-500 text-sm hover:underline">
        <i class="ri ri-close-line mr-1"></i>清除筛选
    </a>
<?php endif; ?>

<!-- 推荐歌单卡片 横向滚动 -->
<?php if (!$keyword && !$artistId): ?>
<section class="mb-6 -mx-4 px-4">
    <div class="flex gap-4 overflow-x-auto pb-3 scrollbar-hide snap-x">
        <?php
        $playlists = [
            ['title' => '每日30首', 'subtitle' => '甜音Leto', 'color' => 'from-sky-400 to-blue-500', 'icon' => 'ri ri-sun-line'],
            ['title' => 'Songs Hunt', 'subtitle' => '月光·钢琴曲', 'color' => 'from-teal-400 to-cyan-500', 'icon' => 'ri ri-moon-line'],
            ['title' => '心动私藏', 'subtitle' => '浪漫时刻', 'color' => 'from-pink-400 to-rose-500', 'icon' => 'ri ri-heart-line'],
            ['title' => '华语精选', 'subtitle' => '经典回忆', 'color' => 'from-amber-400 to-orange-500', 'icon' => 'ri ri-star-line'],
        ];
        foreach ($playlists as $pl):
        ?>
            <div class="flex-shrink-0 w-64 snap-start rounded-2xl overflow-hidden bg-gradient-to-br <?php echo $pl['color']; ?> p-5 text-white shadow-lg">
                <div class="flex items-start justify-between">
                    <div>
                        <h3 class="text-xl font-bold"><?php echo $pl['title']; ?></h3>
                        <p class="text-sm text-white/80 mt-1"><?php echo $pl['subtitle']; ?></p>
                    </div>
                    <i class="<?php echo $pl['icon']; ?> text-2xl text-white/60"></i>
                </div>
                <div class="flex items-center justify-between mt-10">
                    <span class="text-xs text-white/70"><?php echo $musicCount; ?> 首歌曲</span>
                    <button class="w-10 h-10 rounded-full bg-white/90 text-pink-500 flex items-center justify-center shadow-lg hover:scale-110 transition">
                        <i class="ri ri-play-line ml-0.5"></i>
                    </button>
                </div>
            </div>
        <?php endforeach; ?>
    </div>
</section>
<?php endif; ?>

<!-- 推荐歌曲区块 -->
<section class="mb-6">
    <div class="flex items-center justify-between mb-3">
        <h2 class="text-lg font-bold text-gray-800">
            听「<?php echo !empty($musicList) ? e($musicList[0]['title']) : '好音乐'; ?>」也会喜欢
            <i class="ri ri-heart-fill text-pink-400 ml-1"></i>
        </h2>
        <a href="player.php" class="w-8 h-8 rounded-full bg-gradient-to-br from-pink-500 to-rose-500 text-white flex items-center justify-center shadow">
            <i class="ri ri-play-line text-xs ml-0.5"></i>
        </a>
    </div>

    <div class="space-y-2">
        <?php if (empty($musicList)): ?>
            <div class="text-center py-12 text-gray-400">
                <i class="ri ri-music-line text-4xl mb-3 text-pink-200"></i>
                <p>暂无音乐<?php echo $keyword ? '，换个关键词试试' : ''; ?></p>
            </div>
        <?php else: ?>
            <?php foreach (array_slice($musicList, 0, 6) as $m): ?>
                <div class="flex items-center gap-3 p-2 rounded-xl hover:bg-pink-50/60 transition group">
                    <img src="<?php echo $m['cover'] ? e($m['cover']) : 'assets/images/default-cover.svg'; ?>"
                         class="w-12 h-12 rounded-lg object-cover flex-shrink-0"
                         onerror="this.src='assets/images/default-cover.svg'">
                    <div class="flex-1 min-w-0">
                        <div class="font-medium text-gray-800 truncate"><?php echo e($m['title']); ?></div>
                        <div class="text-xs text-gray-400 truncate flex items-center gap-2">
                            <span><?php echo e($m['artist_name'] ?: '未知歌手'); ?></span>
                            <?php if ($m['album']): ?>
                                <span class="px-1.5 py-0.5 bg-pink-50 text-pink-400 rounded text-[10px]"><?php echo e($m['album']); ?></span>
                            <?php endif; ?>
                        </div>
                    </div>
                    <button onclick="toggleLike(this)" class="w-8 h-8 flex items-center justify-center text-gray-300 hover:text-pink-500 transition">
                        <i class="ri ri-heart-line"></i>
                    </button>
                </div>
            <?php endforeach; ?>
        <?php endif; ?>
    </div>
</section>

<!-- 热门歌手 -->
<section class="mb-6">
    <div class="flex items-center justify-between mb-3">
        <h2 class="text-lg font-bold text-gray-800">
            热门歌手
        </h2>
        <a href="artists.php" class="text-pink-500 text-xs hover:underline">更多 <i class="ri ri-arrow-right-s-line text-[10px]"></i></a>
    </div>
    <div class="flex gap-4 overflow-x-auto pb-2 scrollbar-hide">
        <?php foreach ($artists as $a): ?>
            <a href="artists.php?id=<?php echo $a['id']; ?>" class="flex-shrink-0 text-center group w-16">
                <div class="relative mx-auto w-16 h-16 rounded-full overflow-hidden border-2 border-pink-100 group-hover:border-pink-300 transition">
                    <img src="<?php echo $a['display_avatar'] ? e($a['display_avatar']) : 'assets/images/default-artist.svg'; ?>"
                         class="w-full h-full object-cover"
                         onerror="this.src='assets/images/default-artist.svg'">
                </div>
                <p class="mt-1.5 text-xs font-medium text-gray-700 truncate"><?php echo e($a['name']); ?></p>
            </a>
        <?php endforeach; ?>
    </div>
</section>

<!-- 全部歌曲列表 -->
<section class="mb-24">
    <div class="flex items-center justify-between mb-3">
        <h2 class="text-lg font-bold text-gray-800">全部歌曲</h2>
        <span class="text-xs text-gray-400"><?php echo count($musicList); ?> 首</span>
    </div>
    <div class="space-y-1">
        <?php foreach ($musicList as $i => $m): ?>
            <div class="flex items-center gap-3 p-2.5 rounded-xl hover:bg-pink-50/60 transition group">
                <span class="w-6 text-center text-sm text-gray-400 font-mono flex-shrink-0"><?php echo $i + 1; ?></span>
                <img src="<?php echo $m['cover'] ? e($m['cover']) : 'assets/images/default-cover.svg'; ?>"
                     class="w-11 h-11 rounded-lg object-cover flex-shrink-0"
                     onerror="this.src='assets/images/default-cover.svg'">
                <?php
                $playArgs = htmlspecialchars(json_encode([
                    $m['id'],
                    $m['title'],
                    $m['artist_name'] ?: '未知歌手',
                    $m['file_path'],
                    $m['cover'] ?: 'assets/images/default-cover.svg'
                ], JSON_UNESCAPED_UNICODE), ENT_QUOTES);
                ?>
                <div class="flex-1 min-w-0 cursor-pointer" onclick="playMusic(<?php echo $playArgs; ?>)">
                    <div class="font-medium text-gray-800 truncate"><?php echo e($m['title']); ?></div>
                    <div class="text-xs text-gray-400 truncate">
                        <?php echo e($m['artist_name'] ?: '未知歌手'); ?>
                        <?php if ($m['album']): ?> · <?php echo e($m['album']); ?><?php endif; ?>
                    </div>
                </div>
                <span class="text-xs text-gray-400 hidden sm:block"><?php echo e($m['file_type']); ?></span>
                <span class="text-xs text-gray-400 hidden md:block"><i class="ri ri-headphone-line mr-1"></i><?php echo $m['play_count']; ?></span>
                <button onclick="playMusic(<?php echo $playArgs; ?>)" class="w-8 h-8 flex items-center justify-center text-pink-400 opacity-0 group-hover:opacity-100 transition">
                    <i class="ri ri-play-line text-xs"></i>
                </button>
            </div>
        <?php endforeach; ?>
    </div>
</section>

<!-- 底部导航栏（APP风格） -->
<nav class="fixed bottom-0 left-0 right-0 z-50 bg-white/90 backdrop-blur-lg border-t border-pink-100 md:hidden">
    <div class="grid grid-cols-5 py-2">
        <a href="index.php" class="flex flex-col items-center gap-0.5 text-pink-500">
            <i class="ri ri-home-line text-lg"></i>
            <span class="text-[10px]">首页</span>
        </a>
        <a href="#" class="flex flex-col items-center gap-0.5 text-gray-400">
            <i class="ri ri-video-line text-lg"></i>
            <span class="text-[10px]">视频</span>
        </a>
        <a href="player.php" class="flex flex-col items-center gap-0.5 text-gray-400">
            <div class="w-12 h-12 rounded-full bg-gradient-to-br from-pink-500 to-rose-500 flex items-center justify-center text-white -mt-4 shadow-lg">
                <i class="ri ri-play-line ml-0.5"></i>
            </div>
        </a>
        <a href="#" class="flex flex-col items-center gap-0.5 text-gray-400">
            <i class="ri ri-star-line text-lg"></i>
            <span class="text-[10px]">星光</span>
        </a>
        <a href="<?php echo isLoggedIn() ? 'profile.php' : 'login.php'; ?>" class="flex flex-col items-center gap-0.5 text-gray-400">
            <i class="ri ri-user-line text-lg"></i>
            <span class="text-[10px]">我的</span>
        </a>
    </div>
</nav>

<script>
function toggleLike(btn) {
    const icon = btn.querySelector('i');
    if (icon.classList.contains('ri-heart-line')) {
        icon.classList.remove('ri-heart-line');
        icon.classList.add('ri-heart-fill');
        btn.classList.add('text-pink-500');
        btn.classList.remove('text-gray-300');
    } else {
        icon.classList.remove('ri-heart-fill');
        icon.classList.add('ri-heart-line');
        btn.classList.remove('text-pink-500');
        btn.classList.add('text-gray-300');
    }
}
</script>

<style>
.scrollbar-hide::-webkit-scrollbar { display: none; }
.scrollbar-hide { -ms-overflow-style: none; scrollbar-width: none; }
</style>

<?php include __DIR__ . '/includes/footer.php'; ?>
