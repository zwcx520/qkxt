<?php
require_once __DIR__ . '/includes/auth.php';
$pageTitle = '播放器 - 甜音曲库';

$pdo = Database::getConnection();
$musicId = isset($_GET['id']) ? (int)$_GET['id'] : 0;

// 获取播放列表
$stmt = $pdo->query("SELECT m.*, a.name AS artist_name FROM music m
                     LEFT JOIN artists a ON m.artist_id = a.id
                     ORDER BY m.created_at DESC LIMIT 50");
$playlist = $stmt->fetchAll();

$currentMusic = null;
if ($musicId > 0) {
    $stmt = $pdo->prepare("SELECT m.*, a.name AS artist_name,
                                  COALESCE(NULLIF(a.avatar,''), u.avatar) AS artist_avatar
                           FROM music m
                           LEFT JOIN artists a ON m.artist_id = a.id
                           LEFT JOIN users u ON a.created_by = u.id
                           WHERE m.id = ?");
    $stmt->execute([$musicId]);
    $currentMusic = $stmt->fetch();
    $pdo->prepare("UPDATE music SET play_count = play_count + 1 WHERE id = ?")->execute([$musicId]);
}

if (!$currentMusic && !empty($playlist)) {
    $currentMusic = $playlist[0];
}
?>
<!DOCTYPE html>
<html lang="zh-CN">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=no">
    <title><?php echo $pageTitle; ?></title>
    <link rel="stylesheet" href="https://cdn.bootcdn.net/ajax/libs/remixicon/4.2.0/remixicon.css">
    <script src="https://cdn.tailwindcss.com"></script>
    <link rel="stylesheet" href="assets/css/style.css">
</head>
<body class="bg-gradient-to-br from-purple-900 via-pink-800 to-rose-900 min-h-screen overflow-x-hidden">

<?php if ($currentMusic): ?>
<!-- 全屏播放器 -->
<div class="min-h-screen flex flex-col relative">
    <!-- 背景模糊封面 -->
    <div class="fixed inset-0 z-0">
        <img src="<?php echo $currentMusic['cover'] ? e($currentMusic['cover']) : 'assets/images/default-cover.svg'; ?>"
             class="w-full h-full object-cover opacity-30 blur-3xl scale-110">
        <div class="absolute inset-0 bg-gradient-to-b from-purple-900/60 via-pink-900/50 to-rose-900/70"></div>
    </div>

    <!-- 顶部栏 -->
    <div class="relative z-10 flex items-center justify-between px-5 py-5">
        <a href="<?php echo $_SERVER['HTTP_REFERER'] ?? 'index.php'; ?>" class="w-10 h-10 rounded-full bg-white/10 backdrop-blur flex items-center justify-center text-white">
            <i class="ri ri-arrow-down-s-line text-xl"></i>
        </a>
        <div class="text-center text-white">
            <p class="text-xs text-white/60">正在播放</p>
            <p class="text-sm font-medium truncate max-w-[180px]"><?php echo e($currentMusic['album'] ?: '未知专辑'); ?></p>
        </div>
        <button class="w-10 h-10 rounded-full bg-white/10 backdrop-blur flex items-center justify-center text-white">
            <i class="ri ri-share-forward-line"></i>
        </button>
    </div>

    <!-- 封面区 -->
    <div class="relative z-10 flex-1 flex flex-col items-center justify-center px-8">
        <div class="relative">
            <div id="coverWrap" class="w-64 h-64 md:w-80 md:h-80 rounded-full overflow-hidden border-[12px] border-white/10 shadow-2xl animate-spin-slow">
                <img id="coverImg" src="<?php echo $currentMusic['cover'] ? e($currentMusic['cover']) : 'assets/images/default-cover.svg'; ?>"
                     class="w-full h-full object-cover">
            </div>
            <div class="absolute inset-0 flex items-center justify-center pointer-events-none">
                <div class="w-16 h-16 rounded-full bg-black/40 border-4 border-white/20"></div>
            </div>
        </div>
    </div>

    <!-- 歌曲信息 -->
    <div class="relative z-10 text-center px-6 mt-4">
        <h1 id="songTitle" class="text-2xl md:text-3xl font-bold text-white mb-1.5 truncate"><?php echo e($currentMusic['title']); ?></h1>
        <p id="songArtist" class="text-base text-white/70"><?php echo e($currentMusic['artist_name'] ?: '未知歌手'); ?></p>
    </div>

    <!-- 进度条 -->
    <div class="relative z-10 flex items-center gap-3 px-6 mt-6">
        <span id="currentTime" class="text-xs text-white/60 font-mono w-10">00:00</span>
        <div class="flex-1 h-1 bg-white/20 rounded-full cursor-pointer" id="progressBar">
            <div id="progressFill" class="h-full bg-white rounded-full relative" style="width:0%">
                <div class="absolute right-0 top-1/2 -translate-y-1/2 w-3 h-3 rounded-full bg-white shadow"></div>
            </div>
        </div>
        <span id="duration" class="text-xs text-white/60 font-mono w-10 text-right"><?php echo formatDuration((int)$currentMusic['duration']); ?></span>
    </div>

    <!-- 控制按钮 -->
    <div class="relative z-10 flex items-center justify-center gap-10 px-6 py-8">
        <button onclick="toggleShuffle(this)" id="shuffleBtn" class="w-10 h-10 flex items-center justify-center text-white/60 hover:text-white transition">
            <i class="ri ri-shuffle-line text-xl"></i>
        </button>
        <button onclick="prevTrack()" class="w-12 h-12 flex items-center justify-center text-white hover:scale-110 transition">
            <i class="ri ri-skip-back-fill text-3xl"></i>
        </button>
        <button onclick="togglePlay()" id="playBtn" class="w-20 h-20 rounded-full bg-white text-pink-600 shadow-2xl hover:scale-105 transition flex items-center justify-center">
            <i class="ri ri-play-fill text-4xl ml-1"></i>
        </button>
        <button onclick="nextTrack()" class="w-12 h-12 flex items-center justify-center text-white hover:scale-110 transition">
            <i class="ri ri-skip-forward-fill text-3xl"></i>
        </button>
        <button onclick="toggleRepeat(this)" id="repeatBtn" class="w-10 h-10 flex items-center justify-center text-white/60 hover:text-white transition">
            <i class="ri ri-repeat-line text-xl"></i>
        </button>
    </div>

    <!-- 底部功能 -->
    <div class="relative z-10 flex items-center justify-around px-6 pb-8 text-white/70">
        <button onclick="toggleLike(this)" class="flex flex-col items-center gap-1 hover:text-pink-300 transition">
            <i class="ri ri-heart-line text-xl"></i>
            <span class="text-[10px]">喜欢</span>
        </button>
        <a href="<?php echo e($currentMusic['file_path']); ?>" download class="flex flex-col items-center gap-1 hover:text-pink-300 transition">
            <i class="ri ri-download-line text-xl"></i>
            <span class="text-[10px]">下载</span>
        </a>
        <button class="flex flex-col items-center gap-1 hover:text-pink-300 transition">
            <i class="ri ri-chat-3-line text-xl"></i>
            <span class="text-[10px]">评论</span>
        </button>
        <button onclick="togglePlaylist()" class="flex flex-col items-center gap-1 hover:text-pink-300 transition">
            <i class="ri ri-list-unordered text-xl"></i>
            <span class="text-[10px]">列表</span>
        </button>
    </div>

    <audio id="audioPlayer" src="<?php echo e($currentMusic['file_path']); ?>" preload="metadata" autoplay></audio>
</div>

<!-- 播放列表面板（从底部滑出） -->
<div id="playlistMask" class="fixed inset-0 bg-black/50 z-40 hidden" onclick="togglePlaylist()"></div>
<div id="playlistPanel" class="fixed bottom-0 left-0 right-0 z-50 bg-gradient-to-b from-purple-900 to-pink-900 rounded-t-3xl max-h-[60vh] overflow-hidden transform translate-y-full transition-transform duration-300">
    <div class="flex items-center justify-between px-5 py-4 border-b border-white/10">
        <h3 class="font-bold text-white"><i class="ri ri-list-ordered text-pink-300 mr-2"></i>播放列表</h3>
        <button onclick="togglePlaylist()" class="text-white/60 hover:text-white">
            <i class="ri ri-close-line text-xl"></i>
        </button>
    </div>
    <div class="overflow-y-auto max-h-[calc(60vh-60px)] px-3 py-2">
        <?php foreach ($playlist as $i => $m): ?>
            <div class="flex items-center gap-3 p-2.5 rounded-xl hover:bg-white/10 cursor-pointer transition
                        <?php echo $currentMusic['id'] == $m['id'] ? 'bg-white/10' : ''; ?>"
                 onclick="loadTrack(<?php echo $m['id']; ?>)">
                <span class="w-6 text-center text-xs text-white/40"><?php echo $i+1; ?></span>
                <img src="<?php echo $m['cover'] ? e($m['cover']) : 'assets/images/default-cover.svg'; ?>"
                     class="w-10 h-10 rounded-lg object-cover">
                <div class="flex-1 min-w-0">
                    <div class="text-sm font-medium text-white truncate"><?php echo e($m['title']); ?></div>
                    <div class="text-xs text-white/50 truncate"><?php echo e($m['artist_name'] ?: '未知'); ?></div>
                </div>
                <?php if ($currentMusic['id'] == $m['id']): ?>
                    <i class="ri ri-volume-up-line text-pink-300 text-sm"></i>
                <?php endif; ?>
            </div>
        <?php endforeach; ?>
    </div>
</div>

<script>
const audio = document.getElementById('audioPlayer');
const playBtn = document.getElementById('playBtn');
const progressBar = document.getElementById('progressBar');
const progressFill = document.getElementById('progressFill');
const currentTimeEl = document.getElementById('currentTime');
const durationEl = document.getElementById('duration');

const playlist = <?php echo json_encode(array_map(function($m){
    return [
        'id' => $m['id'],
        'title' => $m['title'],
        'artist' => $m['artist_name'],
        'cover' => $m['cover'] ? $m['cover'] : 'assets/images/default-cover.svg',
        'src' => $m['file_path'],
    ];
}, $playlist), JSON_UNESCAPED_UNICODE); ?>;

let currentIndex = playlist.findIndex(t => t.id === <?php echo $currentMusic['id']; ?>);
let isShuffle = false;
let repeatMode = 0; // 0=列表循环, 1=单曲循环

function updatePlayButton() {
    playBtn.innerHTML = audio.paused ? '<i class="ri ri-play-fill text-4xl ml-1"></i>' : '<i class="ri ri-pause-fill text-4xl"></i>';
}
function togglePlay() { if (audio.paused) audio.play(); else audio.pause(); }

audio.addEventListener('play', updatePlayButton);
audio.addEventListener('pause', updatePlayButton);
audio.addEventListener('loadedmetadata', () => { durationEl.textContent = formatTime(audio.duration); });
audio.addEventListener('timeupdate', () => {
    const pct = (audio.currentTime / audio.duration) * 100;
    progressFill.style.width = pct + '%';
    currentTimeEl.textContent = formatTime(audio.currentTime);
});
audio.addEventListener('ended', () => {
    if (repeatMode === 1) {
        audio.currentTime = 0;
        audio.play();
    } else {
        nextTrack();
    }
});

progressBar.addEventListener('click', e => {
    const rect = progressBar.getBoundingClientRect();
    audio.currentTime = ((e.clientX - rect.left) / rect.width) * audio.duration;
});

function formatTime(s) {
    if (isNaN(s)) return '00:00';
    return String(Math.floor(s/60)).padStart(2,'0') + ':' + String(Math.floor(s%60)).padStart(2,'0');
}

function loadTrack(id) {
    const idx = playlist.findIndex(t => t.id === id);
    if (idx >= 0) {
        currentIndex = idx;
        const t = playlist[idx];
        audio.src = t.src;
        document.getElementById('songTitle').textContent = t.title;
        document.getElementById('songArtist').textContent = t.artist || '未知歌手';
        document.getElementById('coverImg').src = t.cover;
        // 同步到 sessionStorage，供迷你播放器使用
        sessionStorage.setItem('mini_current', JSON.stringify({
            id: t.id, title: t.title, artist: t.artist, file: t.src, cover: t.cover
        }));
        sessionStorage.setItem('mini_position', 0);
        audio.play();
    }
}

function nextTrack() {
    if (isShuffle) {
        currentIndex = Math.floor(Math.random() * playlist.length);
    } else {
        currentIndex = (currentIndex + 1) % playlist.length;
    }
    loadTrack(playlist[currentIndex].id);
}

function prevTrack() {
    currentIndex = (currentIndex - 1 + playlist.length) % playlist.length;
    loadTrack(playlist[currentIndex].id);
}

function togglePlaylist() {
    const panel = document.getElementById('playlistPanel');
    const mask = document.getElementById('playlistMask');
    const isHidden = panel.classList.contains('translate-y-full');
    if (isHidden) {
        panel.classList.remove('translate-y-full');
        mask.classList.remove('hidden');
    } else {
        panel.classList.add('translate-y-full');
        mask.classList.add('hidden');
    }
}

function toggleLike(btn) {
    const icon = btn.querySelector('i');
    icon.classList.toggle('ri-heart-line');
    icon.classList.toggle('ri-heart-fill');
    btn.classList.toggle('text-pink-300');
    btn.classList.toggle('text-white/70');
}

function toggleShuffle(btn) {
    isShuffle = !isShuffle;
    btn.classList.toggle('text-pink-300');
    btn.classList.toggle('text-white/60');
}

function toggleRepeat(btn) {
    repeatMode = (repeatMode + 1) % 2;
    const icon = btn.querySelector('i');
    if (repeatMode === 1) {
        icon.classList.remove('ri-repeat-line');
        icon.classList.add('ri-repeat-one-line');
        btn.classList.add('text-pink-300');
        btn.classList.remove('text-white/60');
    } else {
        icon.classList.remove('ri-repeat-one-line');
        icon.classList.add('ri-repeat-line');
        btn.classList.remove('text-pink-300');
        btn.classList.add('text-white/60');
    }
}
</script>

<?php else: ?>
<div class="min-h-screen flex flex-col items-center justify-center text-white px-6">
    <i class="ri ri-music-line text-7xl mb-6 text-white/40"></i>
    <h1 class="text-2xl font-bold mb-2">暂无音乐</h1>
    <p class="mb-6 text-white/60">请先上传音乐</p>
    <?php if (isLoggedIn()): ?>
        <a href="upload.php" class="px-8 py-3 rounded-full bg-white text-pink-600 font-semibold shadow-lg">上传音乐</a>
    <?php else: ?>
        <a href="login.php" class="px-8 py-3 rounded-full bg-white text-pink-600 font-semibold shadow-lg">登录</a>
    <?php endif; ?>
</div>
<?php endif; ?>

</body>
</html>
