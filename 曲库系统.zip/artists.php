<?php
require_once __DIR__ . '/includes/auth.php';
$pageTitle = '歌手 - 甜音曲库';

$pdo = Database::getConnection();
$artistId = isset($_GET['id']) ? (int)$_GET['id'] : 0;

if ($artistId > 0) {
    // 歌手详情：头像优先用 artists.avatar，为空则回退到用户头像
    $stmt = $pdo->prepare("SELECT a.*, COALESCE(NULLIF(a.avatar,''), u.avatar) AS display_avatar
                           FROM artists a LEFT JOIN users u ON a.created_by = u.id
                           WHERE a.id = ?");
    $stmt->execute([$artistId]);
    $artist = $stmt->fetch();
    if (!$artist) redirect('artists.php');
    $stmt = $pdo->prepare("SELECT m.*, a.name AS artist_name, u.username AS uploader_name FROM music m
                           LEFT JOIN artists a ON m.artist_id = a.id
                           LEFT JOIN users u ON m.uploader_id = u.id
                           WHERE m.artist_id = ? ORDER BY m.created_at DESC");
    $stmt->execute([$artistId]);
    $musicList = $stmt->fetchAll();
} else {
    $keyword = trim($_GET['q'] ?? '');
    // 歌手列表：头像优先用 artists.avatar，为空则回退到用户头像
    $sql = "SELECT a.*, COALESCE(NULLIF(a.avatar,''), u.avatar) AS display_avatar,
                   COUNT(m.id) AS music_count
            FROM artists a
            LEFT JOIN music m ON a.id = m.artist_id
            LEFT JOIN users u ON a.created_by = u.id
            WHERE 1=1";
    $params = [];
    if ($keyword) { $sql .= " AND a.name LIKE ?"; $params[] = "%{$keyword}%"; }
    $sql .= " GROUP BY a.id ORDER BY music_count DESC, a.id DESC LIMIT 200";
    $stmt = $pdo->prepare($sql);
    $stmt->execute($params);
    $artists = $stmt->fetchAll();
}

include __DIR__ . '/includes/header.php';
?>

<div class="pb-24">
<?php if ($artistId > 0): ?>
    <!-- 歌手详情 -->
    <div class="artist-banner relative -mx-4 -mt-6">
        <div class="absolute inset-0 bg-gradient-to-r from-purple-500/80 via-pink-500/80 to-rose-500/80"></div>
        <div class="relative z-10 p-6 text-white">
            <div class="flex items-center gap-2 mb-6">
                <a href="artists.php" class="w-9 h-9 rounded-full bg-white/20 flex items-center justify-center">
                    <i class="ri ri-arrow-left-s-line text-sm"></i>
                </a>
                <span class="font-medium">歌手</span>
            </div>
            <div class="flex flex-col items-center text-center">
                <img src="<?php echo $artist['display_avatar'] ? e($artist['display_avatar']) : 'assets/images/default-artist.svg'; ?>"
                     class="w-28 h-28 rounded-full object-cover border-4 border-white/40 shadow-2xl mb-4">
                <h1 class="text-3xl font-bold mb-1"><?php echo e($artist['name']); ?></h1>
                <p class="text-white/80 text-sm mb-4 max-w-md"><?php echo e($artist['bio'] ?: '暂无简介'); ?></p>
                <div class="flex gap-6 text-sm">
                    <div><span class="text-2xl font-bold"><?php echo count($musicList); ?></span><br><span class="text-white/70 text-xs">歌曲</span></div>
                    <div><span class="text-2xl font-bold"><?php echo $artist['music_count'] ?? 0; ?></span><br><span class="text-white/70 text-xs">专辑</span></div>
                </div>
            </div>
        </div>
    </div>

    <!-- 歌曲列表 -->
    <div class="mt-6">
        <div class="flex items-center justify-between mb-3 px-1">
            <h2 class="font-bold text-gray-800">全部歌曲</h2>
            <span class="text-xs text-gray-400"><?php echo count($musicList); ?> 首</span>
        </div>
        <?php if (empty($musicList)): ?>
            <div class="text-center py-16 text-gray-400">
                <i class="ri ri-music-line text-4xl mb-3 text-pink-200"></i>
                <p>该歌手暂无歌曲</p>
                <?php if (isLoggedIn()): ?>
                    <a href="upload.php?artist=<?php echo $artist['id']; ?>" class="btn-primary inline-block mt-4 px-5 py-2 rounded-full text-sm">上传歌曲</a>
                <?php endif; ?>
            </div>
        <?php else: ?>
            <div class="space-y-1">
                <?php foreach ($musicList as $i => $m): ?>
                    <div class="flex items-center gap-3 p-2.5 rounded-xl hover:bg-pink-50/60 transition group">
                        <span class="w-6 text-center text-sm text-gray-400 font-mono flex-shrink-0"><?php echo $i + 1; ?></span>
                        <img src="<?php echo $m['cover'] ? e($m['cover']) : 'assets/images/default-cover.svg'; ?>"
                             class="w-11 h-11 rounded-lg object-cover flex-shrink-0">
                        <?php
                        $playArgs = htmlspecialchars(json_encode([
                            $m['id'],
                            $m['title'],
                            $m['artist_name'] ?: '未知歌手',
                            $m['file_path'],
                            $m['cover'] ?: 'assets/images/default-cover.svg'
                        ], JSON_UNESCAPED_UNICODE), ENT_QUOTES);
                        ?>
                        <div class="flex-1 min-w-0 cursor-pointer" onclick="playMusic(<?php echo $playArgs; ?>)">
                            <div class="font-medium text-gray-800 truncate"><?php echo e($m['title']); ?></div>
                            <div class="text-xs text-gray-400 truncate"><?php echo e($m['album'] ?: '未知专辑'); ?></div>
                        </div>
                        <span class="text-xs text-gray-400 hidden sm:block"><?php echo formatDuration((int)$m['duration']); ?></span>
                        <button onclick="playMusic(<?php echo $playArgs; ?>)" class="w-8 h-8 flex items-center justify-center text-pink-400 opacity-0 group-hover:opacity-100 transition">
                            <i class="ri ri-play-line text-xs"></i>
                        </button>
                    </div>
                <?php endforeach; ?>
            </div>
        <?php endif; ?>
    </div>

<?php else: ?>
    <!-- 歌手列表 -->
    <div class="flex items-center justify-between mb-4">
        <h1 class="text-xl font-bold text-gray-800">歌手</h1>
    </div>

    <form method="get" class="mb-5">
        <div class="relative">
            <i class="ri ri-search-line absolute left-4 top-1/2 -translate-y-1/2 text-pink-400"></i>
            <input type="text" name="q" value="<?php echo e($keyword ?? ''); ?>" placeholder="搜索歌手..."
                   class="w-full pl-11 pr-4 py-2.5 rounded-full bg-white/70 text-sm focus:bg-white transition">
        </div>
    </form>

    <?php if (empty($artists)): ?>
        <div class="text-center py-16 text-gray-400">
            <i class="ri ri-mic-line text-5xl mb-4 text-pink-200"></i>
            <p>暂无歌手</p>
        </div>
    <?php else: ?>
        <div class="grid grid-cols-3 sm:grid-cols-4 md:grid-cols-6 gap-4">
            <?php foreach ($artists as $a): ?>
                <a href="artists.php?id=<?php echo $a['id']; ?>" class="text-center group">
                    <div class="relative mx-auto w-16 h-16 md:w-20 md:h-20 rounded-full overflow-hidden border-2 border-pink-100 group-hover:border-pink-300 transition">
                        <img src="<?php echo $a['display_avatar'] ? e($a['display_avatar']) : 'assets/images/default-artist.svg'; ?>"
                             class="w-full h-full object-cover">
                    </div>
                    <h3 class="mt-2 text-sm font-medium text-gray-700 truncate"><?php echo e($a['name']); ?></h3>
                    <p class="text-xs text-gray-400"><?php echo $a['music_count']; ?> 首</p>
                </a>
            <?php endforeach; ?>
        </div>
    <?php endif; ?>
<?php endif; ?>
</div>

<!-- 底部导航栏 -->
<nav class="fixed bottom-0 left-0 right-0 z-50 bg-white/90 backdrop-blur-lg border-t border-pink-100 md:hidden">
    <div class="grid grid-cols-5 py-2">
        <a href="index.php" class="flex flex-col items-center gap-0.5 text-gray-400">
            <i class="ri ri-home-line text-lg"></i><span class="text-[10px]">首页</span>
        </a>
        <a href="#" class="flex flex-col items-center gap-0.5 text-gray-400">
            <i class="ri ri-video-line text-lg"></i><span class="text-[10px]">视频</span>
        </a>
        <a href="player.php" class="flex flex-col items-center gap-0.5">
            <div class="w-12 h-12 rounded-full bg-gradient-to-br from-pink-500 to-rose-500 flex items-center justify-center text-white -mt-4 shadow-lg">
                <i class="ri ri-play-line ml-0.5"></i>
            </div>
        </a>
        <a href="#" class="flex flex-col items-center gap-0.5 text-gray-400">
            <i class="ri ri-star-line text-lg"></i><span class="text-[10px]">星光</span>
        </a>
        <a href="<?php echo isLoggedIn() ? 'profile.php' : 'login.php'; ?>" class="flex flex-col items-center gap-0.5 text-pink-500">
            <i class="ri ri-user-line text-lg"></i><span class="text-[10px]">我的</span>
        </a>
    </div>
</nav>

<?php include __DIR__ . '/includes/footer.php'; ?>
