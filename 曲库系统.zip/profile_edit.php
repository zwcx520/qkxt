<?php
require_once __DIR__ . '/includes/auth.php';
requireLogin();
$pageTitle = '资料编辑 - 甜音曲库';

$pdo = Database::getConnection();
$user = currentUser();
$error = '';
$success = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $username = trim($_POST['username'] ?? '');
    $nickname = trim($_POST['nickname'] ?? '');
    $email = trim($_POST['email'] ?? '');
    $newPassword = $_POST['new_password'] ?? '';
    $avatar = $user['avatar'];

    if (strlen($username) < 3) {
        $error = '用户名至少3个字符';
    } elseif (!preg_match('/^[\w\x{4e00}-\x{9fa5}]+$/u', $username)) {
        $error = '用户名只能包含字母、数字、下划线和中文';
    } elseif (mb_strlen($nickname) > 20) {
        $error = '昵称不能超过20个字符';
    } elseif (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
        $error = '邮箱格式不正确';
    } else {
        // 检查用户名/邮箱重复（排除自己）
        $stmt = $pdo->prepare("SELECT id FROM users WHERE (username = ? OR email = ?) AND id != ?");
        $stmt->execute([$username, $email, $user['id']]);
        if ($stmt->fetch()) {
            $error = '用户名或邮箱已被使用';
        } else {
            // 处理头像上传
            if (!empty($_FILES['avatar']['name']) && $_FILES['avatar']['error'] === UPLOAD_ERR_OK) {
                if ($_FILES['avatar']['size'] > 5 * 1024 * 1024) {
                    $error = '头像不能超过 5MB';
                } else {
                    $allowedImg = ['jpg', 'jpeg', 'png', 'gif', 'webp'];
                    $imgExt = strtolower(pathinfo($_FILES['avatar']['name'], PATHINFO_EXTENSION));
                    if (in_array($imgExt, $allowedImg)) {
                        $avatarRelDir = userSubDir($user['username'], 'avatars');
                        $avatarDir = __DIR__ . '/' . $avatarRelDir;
                        // 使用原始文件名，同名覆盖
                        $newAvatar = saveUploadedFile($_FILES['avatar'], $avatarDir, $avatarRelDir);
                        if ($newAvatar) {
                            // 删除旧头像（如果与新文件不同名）
                            if ($user['avatar'] && $user['avatar'] !== $newAvatar && file_exists(__DIR__ . '/' . $user['avatar'])) {
                                @unlink(__DIR__ . '/' . $user['avatar']);
                            }
                            $avatar = $newAvatar;
                        } else {
                            $error = '头像保存失败';
                        }
                    } else {
                        $error = '头像仅支持 JPG/PNG/GIF/WebP';
                    }
                }
            }

            if (!$error) {
                // 更新基本信息（用户名仅用于登录，昵称用于显示）
                $sql = "UPDATE users SET username = ?, nickname = ?, email = ?, avatar = ?";
                $params = [$username, $nickname ?: null, $email, $avatar];

                // 如果填写了新密码
                if (!empty($newPassword)) {
                    if (strlen($newPassword) < 6) {
                        $error = '新密码至少6位';
                    } else {
                        $sql .= ", password = ?";
                        $params[] = password_hash($newPassword, PASSWORD_DEFAULT);
                    }
                }

                if (!$error) {
                    $sql .= " WHERE id = ?";
                    $params[] = $user['id'];
                    $stmt = $pdo->prepare($sql);
                    $stmt->execute($params);

                    // 同步更新歌手名和头像：优先昵称，无昵称则用用户名
                    $artistName = $nickname ?: $username;
                    $stmt = $pdo->prepare("UPDATE artists SET name = ?, avatar = ? WHERE created_by = ?");
                    $stmt->execute([$artistName, $avatar, $user['id']]);

                    $success = '资料更新成功！';
                }
            }
        }
    }
}

// 获取最新用户信息
$stmt = $pdo->prepare("SELECT * FROM users WHERE id = ?");
$stmt->execute([$_SESSION['user_id']]);
$user = $stmt->fetch();

include __DIR__ . '/includes/header.php';
?>
<div class="max-w-2xl mx-auto pb-24">
    <div class="flex items-center gap-3 mb-5">
        <a href="profile.php" class="w-9 h-9 rounded-full bg-white/70 flex items-center justify-center text-gray-500">
            <i class="ri ri-arrow-left-s-line text-sm"></i>
        </a>
        <h1 class="text-xl font-bold text-gray-800">资料编辑</h1>
    </div>

    <div class="bg-white/60 backdrop-blur rounded-3xl p-6">
        <?php if ($error): ?>
            <div class="bg-red-50 text-red-600 px-4 py-3 rounded-xl mb-4 text-sm">
                <i class="ri ri-information-line mr-2"></i><?php echo e($error); ?>
            </div>
        <?php endif; ?>
        <?php if ($success): ?>
            <div class="bg-green-50 text-green-600 px-4 py-3 rounded-xl mb-4 text-sm">
                <i class="ri ri-checkbox-circle-line mr-2"></i><?php echo e($success); ?>
            </div>
        <?php endif; ?>

        <form method="post" enctype="multipart/form-data" class="space-y-4">
            <!-- 头像 -->
            <div class="flex flex-col items-center mb-2">
                <div id="avatarPreview" class="w-24 h-24 rounded-full bg-pink-50 border-4 border-pink-200 flex items-center justify-center overflow-hidden cursor-pointer shadow-lg" onclick="document.getElementById('avatarInput').click()">
                    <?php if ($user['avatar']): ?>
                        <img src="<?php echo e($user['avatar']); ?>" class="w-full h-full object-cover">
                    <?php else: ?>
                        <i class="ri ri-user-line text-pink-300 text-3xl"></i>
                    <?php endif; ?>
                </div>
                <input type="file" name="avatar" accept="image/*" id="avatarInput" class="hidden" onchange="previewAvatar(this)">
                <p class="text-xs text-gray-400 mt-2">点击更换头像（最大5MB）</p>
            </div>

            <div>
                <label class="block text-sm font-medium text-gray-700 mb-1">用户名 <span class="text-xs text-gray-400 font-normal">（仅用于登录）</span></label>
                <div class="relative">
                    <i class="ri ri-user-line absolute left-4 top-1/2 -translate-y-1/2 text-pink-400"></i>
                    <input type="text" name="username" required minlength="3" value="<?php echo e($user['username']); ?>" class="input-field pl-11">
                </div>
            </div>

            <div>
                <label class="block text-sm font-medium text-gray-700 mb-1">昵称 <span class="text-xs text-gray-400 font-normal">（用于显示及歌手名）</span></label>
                <div class="relative">
                    <i class="ri ri-emotion-happy-line absolute left-4 top-1/2 -translate-y-1/2 text-pink-400"></i>
                    <input type="text" name="nickname" maxlength="20" value="<?php echo e($user['nickname'] ?? ''); ?>" class="input-field pl-11" placeholder="留空则使用用户名">
                </div>
            </div>

            <div>
                <label class="block text-sm font-medium text-gray-700 mb-1">邮箱</label>
                <div class="relative">
                    <i class="ri ri-mail-line absolute left-4 top-1/2 -translate-y-1/2 text-pink-400"></i>
                    <input type="email" name="email" required value="<?php echo e($user['email']); ?>" class="input-field pl-11">
                </div>
            </div>

            <div>
                <label class="block text-sm font-medium text-gray-700 mb-1">新密码 <span class="text-gray-400 font-normal">（不修改请留空）</span></label>
                <div class="relative">
                    <i class="ri ri-lock-line absolute left-4 top-1/2 -translate-y-1/2 text-pink-400"></i>
                    <input type="password" name="new_password" class="input-field pl-11" placeholder="至少6位">
                </div>
            </div>

            <button type="submit" class="btn-primary w-full py-3 rounded-xl font-semibold">
                <i class="ri ri-save-line mr-2"></i>保存修改
            </button>
        </form>
    </div>
</div>

<!-- 底部导航栏 -->
<nav class="fixed bottom-0 left-0 right-0 z-50 bg-white/90 backdrop-blur-lg border-t border-pink-100 md:hidden">
    <div class="grid grid-cols-5 py-2">
        <a href="index.php" class="flex flex-col items-center gap-0.5 text-gray-400">
            <i class="ri ri-home-line text-lg"></i><span class="text-[10px]">首页</span>
        </a>
        <a href="#" class="flex flex-col items-center gap-0.5 text-gray-400">
            <i class="ri ri-video-line text-lg"></i><span class="text-[10px]">视频</span>
        </a>
        <a href="player.php" class="flex flex-col items-center gap-0.5">
            <div class="w-12 h-12 rounded-full bg-gradient-to-br from-pink-500 to-rose-500 flex items-center justify-center text-white -mt-4 shadow-lg">
                <i class="ri ri-play-line ml-0.5"></i>
            </div>
        </a>
        <a href="#" class="flex flex-col items-center gap-0.5 text-gray-400">
            <i class="ri ri-star-line text-lg"></i><span class="text-[10px]">星光</span>
        </a>
        <a href="profile.php" class="flex flex-col items-center gap-0.5 text-pink-500">
            <i class="ri ri-user-line text-lg"></i><span class="text-[10px]">我的</span>
        </a>
    </div>
</nav>

<script>
function previewAvatar(input) {
    const file = input.files[0];
    if (file) {
        if (file.size > 5 * 1024 * 1024) { alert('头像不能超过 5MB'); input.value = ''; return; }
        const reader = new FileReader();
        reader.onload = ev => {
            document.getElementById('avatarPreview').innerHTML = '<img src="' + ev.target.result + '" class="w-full h-full object-cover">';
        };
        reader.readAsDataURL(file);
    }
}
</script>
<?php include __DIR__ . '/includes/footer.php'; ?>
