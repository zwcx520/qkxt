<?php
require_once __DIR__ . '/includes/auth.php';

if (isLoggedIn()) redirect('index.php');

$error = '';
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $username = trim($_POST['username'] ?? '');
    $password = $_POST['password'] ?? '';

    if (empty($username) || empty($password)) {
        $error = '请输入用户名和密码';
    } else {
        $stmt = Database::getConnection()->prepare("SELECT * FROM users WHERE username = ? OR email = ?");
        $stmt->execute([$username, $username]);
        $user = $stmt->fetch();

        if ($user && password_verify($password, $user['password'])) {
            $_SESSION['user_id'] = $user['id'];
            redirect($user['role'] === 'admin' ? 'admin/index.php' : 'index.php');
        } else {
            $error = '用户名或密码错误';
        }
    }
}
?>
<!DOCTYPE html>
<html lang="zh-CN">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>登录 - 甜音曲库</title>
    <script src="https://cdn.tailwindcss.com"></script>
    <link rel="stylesheet" href="https://cdn.bootcdn.net/ajax/libs/remixicon/4.2.0/remixicon.css">
    <link rel="stylesheet" href="assets/css/style.css">
</head>
<body class="auth-bg min-h-screen flex items-center justify-center p-3 sm:p-4">
    <div class="glass-card w-full max-w-md p-5 sm:p-8">
        <div class="text-center mb-6">
            <!-- 头像预览 -->
            <div id="loginAvatar" class="inline-flex items-center justify-center w-20 h-20 rounded-full bg-gradient-to-br from-pink-400 to-rose-500 mb-4 shadow-lg overflow-hidden border-4 border-white">
                <i class="ri ri-music-line text-white text-3xl"></i>
            </div>
            <h1 class="text-xl sm:text-2xl font-bold text-gray-800">欢迎回来</h1>
            <p class="text-gray-500 text-xs sm:text-sm mt-1">登录甜音曲库，开启浪漫音乐之旅</p>
        </div>

        <?php if ($error): ?>
            <div class="bg-red-50 border border-red-200 text-red-600 px-4 py-3 rounded-xl mb-4 text-sm">
                <i class="ri ri-information-line mr-2"></i><?php echo e($error); ?>
            </div>
        <?php endif; ?>

        <form method="post" class="space-y-3 sm:space-y-4">
            <div>
                <label class="block text-xs sm:text-sm font-medium text-gray-700 mb-1">用户名 / 邮箱</label>
                <div class="relative">
                    <i class="ri ri-user-line absolute left-4 top-1/2 -translate-y-1/2 text-pink-400"></i>
                    <input type="text" name="username" id="loginUsername" required class="input-field pl-11" placeholder="输入用户名自动获取头像" autocomplete="username">
                </div>
            </div>
            <div>
                <label class="block text-xs sm:text-sm font-medium text-gray-700 mb-1">密码</label>
                <div class="relative">
                    <i class="ri ri-lock-line absolute left-4 top-1/2 -translate-y-1/2 text-pink-400"></i>
                    <input type="password" name="password" required class="input-field pl-11" placeholder="请输入密码" autocomplete="current-password">
                </div>
            </div>
            <button type="submit" class="btn-primary w-full py-2.5 sm:py-3 rounded-xl font-semibold text-sm sm:text-base">
                <i class="ri ri-login-box-line mr-1 sm:mr-2"></i>登录
            </button>
        </form>

        <p class="text-center text-gray-500 text-xs sm:text-sm mt-5 sm:mt-6">
            还没有账号？<a href="register.php" class="text-pink-500 font-medium hover:underline">立即注册</a>
        </p>
        <p class="text-center text-gray-400 text-xs mt-2 sm:mt-3">
            <a href="index.php" class="hover:text-pink-500"><i class="ri ri-arrow-left-line mr-1"></i>返回首页</a>
        </p>
    </div>
    <script>
    // 输入用户名时自动获取头像
    let avatarTimer = null;
    document.getElementById('loginUsername').addEventListener('input', function() {
        const val = this.value.trim();
        const avatarBox = document.getElementById('loginAvatar');
        clearTimeout(avatarTimer);
        if (!val) {
            avatarBox.innerHTML = '<i class="ri ri-music-line text-white text-3xl"></i>';
            return;
        }
        avatarTimer = setTimeout(() => {
            fetch('get_avatar.php?username=' + encodeURIComponent(val))
                .then(r => r.json())
                .then(data => {
                    if (data.found && data.avatar) {
                        avatarBox.innerHTML = '<img src="' + data.avatar + '" class="w-full h-full object-cover">';
                    } else if (data.found) {
                        avatarBox.innerHTML = '<i class="ri ri-user-line text-white text-3xl"></i>';
                    } else {
                        avatarBox.innerHTML = '<i class="ri ri-music-line text-white text-3xl"></i>';
                    }
                })
                .catch(() => {});
        }, 300);
    });
    </script>
</body>
</html>
