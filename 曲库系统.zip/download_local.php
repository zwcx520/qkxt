<?php
/**
 * 下载外部资源到本地
 * 使用方法：通过浏览器访问此文件（如 http://localhost/download_local.php）
 * 执行完成后请删除此文件
 */

$baseDir = __DIR__;
$assetsDir = $baseDir . '/assets';

function downloadFile($url, $savePath) {
    $dir = dirname($savePath);
    if (!is_dir($dir)) {
        mkdir($dir, 0777, true);
    }
    
    $ch = curl_init($url);
    curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
    curl_setopt($ch, CURLOPT_FOLLOWLOCATION, true);
    curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false);
    curl_setopt($ch, CURLOPT_USERAGENT, 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36');
    curl_setopt($ch, CURLOPT_TIMEOUT, 60);
    
    $content = curl_exec($ch);
    $httpCode = curl_getinfo($ch, CURLINFO_HTTP_CODE);
    curl_close($ch);
    
    if ($httpCode === 200 && $content !== false) {
        file_put_contents($savePath, $content);
        return true;
    }
    return false;
}

function downloadFileFallback($url, $savePath) {
    $dir = dirname($savePath);
    if (!is_dir($dir)) {
        mkdir($dir, 0777, true);
    }
    
    $ctx = stream_context_create([
        'http' => [
            'header' => "User-Agent: Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36\r\n",
            'timeout' => 60,
        ],
        'ssl' => [
            'verify_peer' => false,
            'verify_peer_name' => false,
        ],
    ]);
    
    $content = @file_get_contents($url, false, $ctx);
    if ($content !== false) {
        file_put_contents($savePath, $content);
        return true;
    }
    return false;
}

function smartDownload($url, $savePath) {
    if (function_exists('curl_init')) {
        return downloadFile($url, $savePath);
    }
    return downloadFileFallback($url, $savePath);
}

$results = [];

// 1. Tailwind CSS
$tailwindPath = $assetsDir . '/js/tailwind.min.js';
if (file_exists($tailwindPath) && filesize($tailwindPath) > 10000) {
    $results[] = ['type' => 'skip', 'name' => 'Tailwind CSS', 'msg' => '已存在 (' . round(filesize($tailwindPath)/1024, 1) . ' KB)'];
} else {
    if (smartDownload('https://cdn.tailwindcss.com', $tailwindPath)) {
        $size = filesize($tailwindPath);
        $results[] = ['type' => 'ok', 'name' => 'Tailwind CSS', 'msg' => '下载成功 (' . round($size/1024, 1) . ' KB)'];
    } else {
        $results[] = ['type' => 'fail', 'name' => 'Tailwind CSS', 'msg' => '下载失败，请检查网络或手动下载'];
    }
}

// 2. Remix Icon CSS
$riCssPath = $assetsDir . '/remixicon/remixicon.css';
if (file_exists($riCssPath)) {
    $results[] = ['type' => 'skip', 'name' => 'Remix Icon CSS', 'msg' => '已存在 (' . round(filesize($riCssPath)/1024, 1) . ' KB)'];
} else {
    if (smartDownload('https://cdn.bootcdn.net/ajax/libs/remixicon/4.2.0/remixicon.css', $riCssPath)) {
        $results[] = ['type' => 'ok', 'name' => 'Remix Icon CSS', 'msg' => '下载成功'];
    } else {
        $results[] = ['type' => 'fail', 'name' => 'Remix Icon CSS', 'msg' => '下载失败'];
    }
}

// 3. Remix Icon 字体文件
$riFontDir = $assetsDir . '/remixicon/fonts';
$fontCount = 0;
if (is_dir($riFontDir)) {
    $fontCount = count(glob($riFontDir . '/*.woff2'));
}
if ($fontCount >= 1) {
    $results[] = ['type' => 'skip', 'name' => 'Remix Icon 字体', 'msg' => '已存在'];
} else {
    $fontFormats = ['woff2', 'woff', 'ttf', 'eot', 'svg'];
    $downloaded = 0;
    foreach ($fontFormats as $fmt) {
        $fontUrl = 'https://cdn.bootcdn.net/ajax/libs/remixicon/4.2.0/fonts/remixicon.' . $fmt;
        $savePath = $riFontDir . '/remixicon.' . $fmt;
        if (!file_exists($savePath)) {
            if (smartDownload($fontUrl, $savePath)) {
                $downloaded++;
            }
        }
    }
    $results[] = ['type' => 'ok', 'name' => 'Remix Icon 字体', 'msg' => '下载了 ' . $downloaded . ' 个字体文件'];
}

// 4. 背景图检查
$images = [
    'hero-banner.jpg' => 'https://images.unsplash.com/photo-1511671782779-c97d3d27a1d4?w=1200',
    'player-hero.jpg' => 'https://images.unsplash.com/photo-1470225620780-dba8ba36b745?w=1200',
    'artist-banner.jpg' => 'https://images.unsplash.com/photo-1493225457124-a3eb161ffa5f?w=1200',
];
$imgDir = $assetsDir . '/images';
foreach ($images as $name => $url) {
    $imgPath = $imgDir . '/' . $name;
    if (file_exists($imgPath) && filesize($imgPath) > 10000) {
        $results[] = ['type' => 'skip', 'name' => '背景图: ' . $name, 'msg' => '已存在 (' . round(filesize($imgPath)/1024, 1) . ' KB)'];
    } else {
        if (smartDownload($url, $imgPath)) {
            $size = filesize($imgPath);
            $results[] = ['type' => 'ok', 'name' => '背景图: ' . $name, 'msg' => '下载成功 (' . round($size/1024, 1) . ' KB)'];
        } else {
            $results[] = ['type' => 'fail', 'name' => '背景图: ' . $name, 'msg' => '下载失败'];
        }
    }
}

// 检查替换状态
$phpFiles = glob_recursive($baseDir, '*.php');
$cdnFiles = [];
foreach ($phpFiles as $file) {
    if (strpos($file, 'download_local.php') !== false) continue;
    if (strpos($file, 'download_assets') !== false) continue;
    $content = file_get_contents($file);
    if (preg_match('/cdn\.bootcdn\.net|cdn\.tailwindcss\.com|images\.unsplash\.com/', $content)) {
        $cdnFiles[] = str_replace($baseDir . '/', '', $file);
    }
}

$cssFiles = glob_recursive($baseDir, '*.css');
foreach ($cssFiles as $file) {
    $content = file_get_contents($file);
    if (preg_match('/cdn\.bootcdn\.net|cdn\.tailwindcss\.com|images\.unsplash\.com/', $content)) {
        $cdnFiles[] = str_replace($baseDir . '/', '', $file);
    }
}

function glob_recursive($dir, $pattern) {
    $files = [];
    $items = glob($dir . '/' . $pattern);
    foreach ($items as $item) {
        $files[] = $item;
    }
    $dirs = glob($dir . '/*', GLOB_ONLYDIR);
    foreach ($dirs as $d) {
        if (basename($d) === 'uploads' || basename($d) === 'vendor') continue;
        $files = array_merge($files, glob_recursive($d, $pattern));
    }
    return $files;
}

$tailwindExists = file_exists($tailwindPath) && filesize($tailwindPath) > 10000;
?>
<!DOCTYPE html>
<html lang="zh-CN">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>资源本地化 - 甜音曲库</title>
    <link rel="stylesheet" href="https://cdn.bootcdn.net/ajax/libs/remixicon/4.2.0/remixicon.css">
    <?php if ($tailwindExists): ?>
        <script src="assets/js/tailwind.min.js"></script>
    <?php endif; ?>
    <style>
        * { margin: 0; padding: 0; box-sizing: border-box; }
        body {
            font-family: 'Segoe UI', 'PingFang SC', 'Microsoft YaHei', sans-serif;
            background: linear-gradient(135deg, #fce7f3 0%, #fbcfe8 50%, #f9a8d4 100%);
            min-height: 100vh;
            display: flex;
            align-items: center;
            justify-content: center;
            padding: 1rem;
        }
        .card {
            background: rgba(255,255,255,0.85);
            backdrop-filter: blur(20px);
            border-radius: 1.5rem;
            box-shadow: 0 25px 50px -12px rgba(236, 72, 153, 0.25);
            width: 100%;
            max-width: 600px;
            padding: 2rem;
        }
        .header { text-align: center; margin-bottom: 1.5rem; }
        .icon-circle {
            width: 4rem; height: 4rem;
            border-radius: 50%;
            background: linear-gradient(135deg, #f472b6, #e11d48);
            display: inline-flex;
            align-items: center;
            justify-content: center;
            margin-bottom: 1rem;
            box-shadow: 0 10px 25px rgba(236, 72, 153, 0.3);
        }
        .icon-circle i { color: white; font-size: 1.5rem; }
        h1 { font-size: 1.5rem; color: #1f2937; }
        .subtitle { color: #6b7280; font-size: 0.875rem; margin-top: 0.25rem; }
        .result-list { margin-bottom: 1.5rem; }
        .result-item {
            display: flex; align-items: center; gap: 0.75rem;
            padding: 0.75rem; border-radius: 0.75rem;
            margin-bottom: 0.5rem;
        }
        .result-item.ok { background: #ecfdf5; }
        .result-item.fail { background: #fef2f2; }
        .result-item.skip { background: #f9fafb; }
        .status-icon {
            width: 2rem; height: 2rem; border-radius: 50%;
            display: flex; align-items: center; justify-content center;
            flex-shrink: 0; font-size: 0.875rem;
        }
        .status-icon.ok { background: #d1fae5; color: #10b981; }
        .status-icon.fail { background: #fee2e2; color: #ef4444; }
        .status-icon.skip { background: #e5e7eb; color: #9ca3af; }
        .result-content { flex: 1; min-width: 0; }
        .result-name { font-weight: 500; color: #1f2937; font-size: 0.95rem; }
        .result-msg { font-size: 0.75rem; color: #6b7280; margin-top: 0.125rem; }
        .divider { height: 1px; background: #fce7f3; margin: 1rem 0; }
        .status-row {
            display: flex; align-items: center; justify-content: space-between;
            font-size: 0.875rem; margin-bottom: 1rem;
        }
        .status-label { color: #4b5563; }
        .status-value.ok { color: #10b981; font-weight: 500; }
        .status-value.warn { color: #f97316; font-weight: 500; }
        .warn-box {
            background: #fffbeb; border: 1px solid #fde68a;
            border-radius: 0.75rem; padding: 1rem;
            font-size: 0.875rem; color: #92400e;
            margin-bottom: 1rem;
        }
        .warn-box code {
            background: #fef3c7; padding: 0.125rem 0.5rem;
            border-radius: 0.25rem; font-family: monospace;
        }
        .btn-group { display: flex; gap: 0.75rem; }
        .btn-primary {
            flex: 1; text-align: center; padding: 0.875rem;
            border-radius: 0.75rem;
            background: linear-gradient(135deg, #ec4899, #f43f5e);
            color: white; font-weight: 500; text-decoration: none;
            box-shadow: 0 4px 15px rgba(236, 72, 153, 0.3);
            transition: all 0.2s; cursor: pointer; border: none;
            font-size: 0.95rem;
        }
        .btn-primary:hover { transform: translateY(-2px); box-shadow: 0 8px 25px rgba(236, 72, 153, 0.4); }
        .btn-secondary {
            padding: 0.875rem 1.5rem; border-radius: 0.75rem;
            border: 1px solid #fbcfe8; color: #ec4899;
            font-weight: 500; cursor: pointer;
            background: white; transition: all 0.2s;
            font-size: 0.95rem;
        }
        .btn-secondary:hover { background: #fdf2f8; }
        .file-list {
            font-size: 0.75rem; color: #f97316;
            margin-top: 0.5rem; font-family: monospace;
        }
    </style>
</head>
<body>
    <div class="card">
        <div class="header">
            <div class="icon-circle">
                <i class="ri ri-download-line"></i>
            </div>
            <h1>资源本地化结果</h1>
            <p class="subtitle">外部资源下载与本地替换状态一览</p>
        </div>

        <div class="result-list">
            <?php foreach ($results as $r): ?>
                <div class="result-item <?php echo $r['type']; ?>">
                    <div class="status-icon <?php echo $r['type']; ?>">
                        <i class="ri ri-<?php echo $r['type'] === 'ok' ? 'checkbox-circle-line' : ($r['type'] === 'fail' ? 'close-circle-line' : 'information-line'); ?>"></i>
                    </div>
                    <div class="result-content">
                        <div class="result-name"><?php echo $r['name']; ?></div>
                        <div class="result-msg"><?php echo $r['msg']; ?></div>
                    </div>
                </div>
            <?php endforeach; ?>
        </div>

        <div class="divider"></div>

        <div class="status-row">
            <span class="status-label">CDN 外链替换状态：</span>
            <span class="status-value <?php echo count($cdnFiles) === 0 ? 'ok' : 'warn'; ?>">
                <?php echo count($cdnFiles) === 0 ? '✓ 已全部替换为本地路径' : '还有 ' . count($cdnFiles) . ' 处引用'; ?>
            </span>
        </div>
        <?php if (!empty($cdnFiles)): ?>
            <div class="file-list">
                <?php foreach ($cdnFiles as $f): ?>
                    <div>• <?php echo $f; ?></div>
                <?php endforeach; ?>
            </div>
        <?php endif; ?>

        <div class="warn-box">
            <i class="ri ri-error-warning-line" style="margin-right:0.5rem;"></i>
            执行完成后，请删除 <code>download_local.php</code> 文件以确保安全。
        </div>

        <div class="btn-group">
            <a href="index.php" class="btn-primary">
                <i class="ri ri-home-line" style="margin-right:0.5rem;"></i>返回首页
            </a>
            <button onclick="location.reload()" class="btn-secondary">
                <i class="ri ri-refresh-line" style="margin-right:0.5rem;"></i>重新检查
            </button>
        </div>
    </div>
</body>
</html>
